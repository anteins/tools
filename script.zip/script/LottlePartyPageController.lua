require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "LottlePartyPageUI";
require "EventDelegate";
require "UIButton";
require "LogicStatic";
require "Eight__Framework__EIFrameWork";
require "GameUtility";
require "Eight__Framework__EIBoolEvent";
require "EightGame__Component__NetworkClient";
require "EightGame__Component__Statistical";
require "RewardMessageUtility";
require "EightGame__Logic__LevelUPDialogNode";
require "EightGame__Logic__TipStruct";
require "Eight__Framework__EIEvent";
require "LotteryGetRolePopupDialogNode";
require "AlarmManagerHelper";
require "AlarmManager";
require "ShowRewardUtil";
require "DetailOfSignleLottlePartyUICom";

LottlePartyPageController = {
	__new_object = function(...)
		return newobject(LottlePartyPageController, nil, nil, ...);
	end,
	__define_class = function()
		local static = LottlePartyPageController;

		local static_methods = {
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			Init = function(this)
				this._isClick = false;
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.MyLottlePage, nil) then
					this.MyLottlePage = this:GetComponent(LottlePartyPageUI);
				end;
				EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.MyLottlePage.BuyLottleBt.onClick, (function()
					this:OnBuyLottle();
				end));
				EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.MyLottlePage.BuyAllBt.onClick, (function()
					this:OnBuyAllIn();
				end));
				EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.MyLottlePage.SpecialActivityTex.gameObject:GetComponent(UIButton).onClick, (function()
					this:OnClickSpeciaActive();
				end));
				EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.MyLottlePage.SpecialShowTex.gameObject:GetComponent(UIButton).onClick, (function()
					this:OnCloseShowTex();
				end));
			end,
			OnClickSpeciaActive = function(this)
				if this._isClick then
					return ;
				end;
				this._isClick = true;
--SpecialShowTex.alpha = 0.1f;
				local OpenObj; OpenObj = this.MyLottlePage.SpecialShowTex.gameObject;
				OpenObj:SetActive(true);
				LeanTween.cancel(OpenObj);
--		LTDescr descr02 = LeanTween.alpha (OpenObj, 1f, 0.5f);
				local descr02; descr02 = LeanTween.value(OpenObj, (function(upval)
					this.MyLottlePage.SpecialShowTex.alpha = upval;
				end), 0.10, 1.00, 0.30);
				descr02:setEase(20);
				descr02:setOnComplete((function()
					this._isClick = false;
				end));
			end,
			OnCloseShowTex = function(this)
				local CloseObj; CloseObj = this.MyLottlePage.SpecialShowTex.gameObject;
				LeanTween.cancel(CloseObj);
				this.MyLottlePage.SpecialShowTex.alpha = 1;
				local descr02; descr02 = LeanTween.value(CloseObj, (function(obj)
					this.MyLottlePage.SpecialShowTex.alpha = obj;
				end), 1.00, 0.10, 0.40);
--		LTDescr descr02 = LeanTween.alpha (CloseObj, 0.1f, 0.2f);
--		descr02.setFrom (1f);
				descr02:setEase(20);
				descr02:setOnComplete((function(obj)
					local go; go = typeas(obj, UnityEngine.GameObject, false);
					go:SetActive(false);
					this._isClick = false;
				end));
				descr02:setOnCompleteParam(CloseObj);
			end,
			SetAllScale = function(this)
				local broadstr; broadstr = "";
				if (not this._mypa.isserver) then
					local _sp; _sp = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.sd_party), this._mypa.branchid);
					if (_sp ~= nil) then
						broadstr = _sp.activity_image;
					end;
				end;
				broadstr = condexp(System.String.IsNullOrEmpty(broadstr), true, "icon_party_15", false, (function() return broadstr; end));
				Eight.Framework.EIFrameWork.StartCoroutine(GameUtility.LoadDynamicPic(broadstr, (function(obj)
					this.MyLottlePage.BroadTex.mainTexture = obj;
				end), "png"), false);
				local i; i = 0;
				while (i < this.MyLottlePage.RewardList.Count) do
					getexterninstanceindexer(this.MyLottlePage.RewardList, nil, "get_Item", i).Item.transform.localScale = invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", UnityEngine.Vector3.one, 0.75);
					getexterninstanceindexer(this.MyLottlePage.RewardList, nil, "get_Item", i).TakeOverObj.transform.localScale = invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", UnityEngine.Vector3.one, 1.22);
--EffecList [i].transform.localScale *= 0.75f;
					if (this.MyLottlePage.ShowBetterObjs.Count > 0) then
						local _temp; _temp = this.MyLottlePage.ShowBetterObjs:Find((function(x) return (invokeforbasicvalue(x.name, false, System.String, "Replace", "Eff", "") == ( invokeforbasicvalue(( invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32) ), false, System.Int32, "ToString") )); end));
						if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", _temp, nil) then
							getexterninstanceindexer(this.MyLottlePage.RewardList, nil, "get_Item", i).Item.transform.localScale = UnityEngine.Vector3.one;
--EffecList [i].transform.localScale = Vector3.one;
						end;
					end;
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
			end,
			OnExit = function(this)
				Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIBoolEvent, "ctor__System_String__System_Boolean", nil, "SET_SUB_CLOSE_ACTIVE", false));
			end,
			OnBuyLottle = function(this)
				if this._isClick then
					return ;
				end;
				this._isClick = true;
				Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIBoolEvent, "ctor__System_String__System_Boolean", nil, "SET_BRANCH_BUTTONS_ACTIVE", false));
				this.waittime = 0.08;
				local action; action = EightGame.Data.Server.ServerService.BuylottlepartyMethod(getexterninstanceindexer(this._mypa.partydetail, nil, "get_Item", 0).id, this._mypa.isserver, this._mypa.detailtype, this._mypa.id);
				Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):NetworkRequest(action, (function(returnCode, response)
					local rep; rep = typeas(response, EightGame.Data.Server.BuyLottlePartyResponse, false);
					if (returnCode < 1000) then
						Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.Statistical):RecordLottleParty(typecast(this._mypa.detailtype, EightGame.Data.Server.se_party_type, true), invokeintegeroperator(3, "-", this.lengNum, 1, System.Int32, System.Int32), System.Int32.Parse(this.MyLottlePage.BuyLottleLab.text));
						this.MyLottlePage.BuyAllBt.gameObject:SetActive((not ( (getexterninstanceindexer(this._pcs, nil, "get_Item", invokeintegeroperator(3, "-", this.lengNum, 1, System.Int32, System.Int32)).cost > 0) )));
						this.targeindex = ( invokeintegeroperator(3, "-", rep.id, 1, System.Int32, System.Int32) );
						local tempint; tempint = this.targeindex;
						local _skinrsg; _skinrsg = rep.rewardMsg:Find((function(x) return (x.rewardType == se_rewardtype.SE_REWARDTYPE_ROLESKIN); end));
						if (_skinrsg ~= nil) then
							local sdskin; sdskin = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.sd_role_skin), _skinrsg.staticid);
							if (sdskin ~= nil) then
								Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.Statistical):RecordGetRoleSkinConsum(invokeintegeroperator(3, "-", this.lengNum, 1, System.Int32, System.Int32), sdskin.skin_name);
							end;
							GameUtility.ShowNewSkin(rep.rewardMsg, (function()
								this:StartLottle(99, (function()
									RewardMessageUtility.AnalysisRewardMessage(rep.rewardMsg);
									local newSerdata; newSerdata = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetDataByCls__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
									local oldSerdata; oldSerdata = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetHistoryDataByCls__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
									if ((newSerdata ~= nil) and (oldSerdata ~= nil)) then
										if (newSerdata.level > oldSerdata.level) then
											EightGame.Logic.LevelUPDialogNode.Open(nil, nil);
										end;
									end;
								end));
							end));
						else
							this:StartLottle(99, (function()
								RewardMessageUtility.AnalysisRewardMessage(rep.rewardMsg);
								local newSerdata; newSerdata = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetDataByCls__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
								local oldSerdata; oldSerdata = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetHistoryDataByCls__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
								if ((newSerdata ~= nil) and (oldSerdata ~= nil)) then
									if (newSerdata.level > oldSerdata.level) then
										EightGame.Logic.LevelUPDialogNode.Open(nil, nil);
									end;
								end;
							end));
						end;
					else
						if ((returnCode == 1163) or (returnCode == 1188)) then
							GameUtility.BuyDiamondTips(returnCode);
						else
							local _tips; _tips = EightGame.Component.NetCode.GetDesc(returnCode);
							local param; param = newobject(EightGame.Logic.TipStruct, "ctor", nil, _tips, 0.50);
							Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIEvent, "ctor__System_String__Eight_Framework_EIEvent_ReturnCallBack__System_Object__System_Single", nil, "UI_FLOATING_TIPS", nil, param, 0.00));
						end;
						Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIBoolEvent, "ctor__System_String__System_Boolean", nil, "SET_BRANCH_BUTTONS_ACTIVE", true));
						this._isClick = false;
					end;
				end), true, false);
			end,
			OnBuyAllIn = function(this)
				if this._isClick then
					return ;
				end;
				this._isClick = true;
				Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIBoolEvent, "ctor__System_String__System_Boolean", nil, "SET_BRANCH_BUTTONS_ACTIVE", false));
				this.waittime = 0.08;
				local action; action = EightGame.Data.Server.ServerService.BuyalllottlepartyMethod(getexterninstanceindexer(this._mypa.partydetail, nil, "get_Item", 0).id, this._mypa.isserver, this._mypa.detailtype, this._mypa.id);
				Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):NetworkRequest(action, (function(returnCode, response)
					local rep; rep = typeas(response, EightGame.Data.Server.BuyAllLottlePartyResponse, false);
					if (returnCode < 1000) then
						Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.Statistical):RecordLottleParty(typecast(this._mypa.detailtype, EightGame.Data.Server.se_party_type, true), 99, System.Int32.Parse(this.MyLottlePage.AllInLab.text));
						this.MyLottlePage.BuyAllBt.gameObject:SetActive(false);
						this.MyLottlePage.BuyLottleBt.gameObject:SetActive(false);
						this.MyLottlePage.MaxTipsObj:SetActive(true);
						RewardMessageUtility.AnalysisRewardMessage(rep.rewardMsg);
						local newSerdata; newSerdata = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetDataByCls__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
						local oldSerdata; oldSerdata = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetHistoryDataByCls__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
						if ((newSerdata ~= nil) and (oldSerdata ~= nil)) then
							if (newSerdata.level > oldSerdata.level) then
								EightGame.Logic.LevelUPDialogNode.Open(nil, nil);
							end;
						end;
						local _skinrsg; _skinrsg = rep.rewardMsg:Find((function(x) return (x.rewardType == se_rewardtype.SE_REWARDTYPE_ROLESKIN); end));
						if (_skinrsg ~= nil) then
							local sdskin; sdskin = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.sd_role_skin), _skinrsg.staticid);
							if (sdskin ~= nil) then
								Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.Statistical):RecordGetRoleSkinConsum(99, sdskin.skin_name);
							end;
							this.isCheck = true;
							GameUtility.ShowNewSkin(rep.rewardMsg, (function()
								this.isCheck = false;
								Eight.Framework.EIFrameWork.StartCoroutine(this:StartAllinLottle(nil), false);
							end));
						else
							Eight.Framework.EIFrameWork.StartCoroutine(this:StartAllinLottle(nil), false);
						end;
					else
						if ((returnCode == 1163) or (returnCode == 1188)) then
							GameUtility.BuyDiamondTips(returnCode);
						else
							local _tips; _tips = EightGame.Component.NetCode.GetDesc(returnCode);
							local param; param = newobject(EightGame.Logic.TipStruct, "ctor", nil, _tips, 0.50);
							Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIEvent, "ctor__System_String__Eight_Framework_EIEvent_ReturnCallBack__System_Object__System_Single", nil, "UI_FLOATING_TIPS", nil, param, 0.00));
						end;
						Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIBoolEvent, "ctor__System_String__System_Boolean", nil, "SET_BRANCH_BUTTONS_ACTIVE", true));
						this._isClick = false;
					end;
				end), true, false);
			end,
			CheckShowRole = function(this, _rlist, index, _callback)
				if (getexterninstanceindexer(getexterninstanceindexer(_rlist, nil, "get_Item", index), nil, "get_Item", 2) == 7) then
					local _item; _item = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_item_item), getexterninstanceindexer(getexterninstanceindexer(_rlist, nil, "get_Item", index), nil, "get_Item", 0));
					local rewardRoleid; rewardRoleid = getexterninstanceindexer(_item.getrole, nil, "get_Item", 0);
					local _oldf; _oldf = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetHistoryDataByCls__System_Predicate_T(typeof(EightGame.Data.Server.FighterSerData), (function(x) return (x.staticId == rewardRoleid); end));
					Eight.Framework.EIFrameWork.StartCoroutine(this:WaitShowThings(rewardRoleid, (_oldf ~= nil), _callback), false);
				else
					if externdelegationcomparewithnil(false, false, "LottlePartyPageController:_callback", _callback, nil, nil, false) then
						_callback();
					end;
				end;
			end,
			WaitShowThings = function(this, rewardRoleid, ishave, _callback)
--等待角色展示完成.
				while this.isShowingRole do
					wrapyield(nil, false, false);
				end;
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, 1.20), false, true);
				if (rewardRoleid == 0) then
					return nil;
				end;
				this.gameObject:SetActive(false);
				this.isShowingRole = true;
				local role; role = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_role_role), rewardRoleid);
				LotteryGetRolePopupDialogNode.Open(role, ishave);
				delegationset(false, true, "LotteryGetRolePopupDialogNode:ondismiss", LotteryGetRolePopupDialogNode, nil, "ondismiss", (function()
					this.isShowingRole = false;
					this.gameObject:SetActive(true);
					if externdelegationcomparewithnil(false, false, "LottlePartyPageController:_callback", _callback, nil, nil, false) then
						_callback();
					end;
				end));
			end),
			SetUpData = function(this, _pas, _showTime)
				Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIBoolEvent, "ctor__System_String__System_Boolean", nil, "SET_SUB_CLOSE_ACTIVE", true));
				if ((this._mypa == nil) or (getexterninstanceindexer(this._mypa.partydetail, nil, "get_Item", 0).id ~= getexterninstanceindexer(_pas.partydetail, nil, "get_Item", 0).id)) then
					this:SetDataUpDo(_pas);
					this:SpcialShowDo(_pas);
				end;
				this.MyLottlePage.TimeLab.transform.parent.gameObject:SetActive(_showTime);
				this.MyLottlePage.GetTimeLab.transform.parent.gameObject:SetActive(_showTime);
				if _showTime then
					this:SetTime(_pas);
				end;
			end,
			SpcialShowDo = function(this, _pas)
				if _pas.isserver then
					if (not System.String.IsNullOrEmpty(_pas.activeicon)) then
						this.MyLottlePage.ShowActiveLab.text = _pas.desc;
						Eight.Framework.EIFrameWork.StartCoroutine(GameUtility.LoadDynamicPic(_pas.activeicon, (function(obj)
							this.MyLottlePage.SpecialActivityTex.mainTexture = obj;
						end), "png"), false);
					end;
					if (not System.String.IsNullOrEmpty(_pas.tipicon)) then
						Eight.Framework.EIFrameWork.StartCoroutine(GameUtility.LoadDynamicPic(_pas.tipicon, (function(obj)
							this.MyLottlePage.SpecialShowTex.mainTexture = obj;
						end), "jpg"), false);
					end;
				else
					local _sdp; _sdp = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.sd_party), this._mypa.branchid);
					if (not System.String.IsNullOrEmpty(_sdp.lottle_party_active_icon)) then
						this.MyLottlePage.ShowActiveLab.text = _sdp.desc;
						Eight.Framework.EIFrameWork.StartCoroutine(GameUtility.LoadDynamicPic(_sdp.lottle_party_active_icon, (function(obj)
							this.MyLottlePage.SpecialActivityTex.mainTexture = obj;
						end), "png"), false);
					end;
					if (not System.String.IsNullOrEmpty(_sdp.lottle_party_tip_icon)) then
						Eight.Framework.EIFrameWork.StartCoroutine(GameUtility.LoadDynamicPic(_sdp.lottle_party_tip_icon, (function(obj)
							this.MyLottlePage.SpecialShowTex.mainTexture = obj;
						end), "jpg"), false);
					end;
					this.MyLottlePage.SpecialShowPanel:SetActive(((not System.String.IsNullOrEmpty(_sdp.lottle_party_active_icon)) and (not System.String.IsNullOrEmpty(_sdp.lottle_party_tip_icon))));
				end;
--EIDebuger.Log("_mypa.partydetail[0].id : " + _mypa.partydetail[0].id);
--if ( rewardOtherList.Count >0)
--//if (_mypa.detailtype == (int)se_party_type.SE_PARTY_TYPE_DIAL_RAFFLE_ROLE_PARTY && rewardOtherList.Count > 0)
--{
--     sd_role_skin _sdrk =null;
--    if( rewardOtherList[0][2] == (int)se_rewardtype.SE_REWARDTYPE_ROLESKIN ){
--       _sdrk = LogicStatic.Get<sd_role_skin>(rewardOtherList[0][0]);
--    }
--    else if (rewardOtherList[0][2] == (int)se_rewardtype.SE_REWARDTYPE_ROLE )
--    {
--        sd_item_item _roleitem = LogicStatic.Get<sd_item_item>(rewardOtherList[0][0]);
--        _sdrk = LogicStatic.Get<sd_role_skin>(x => x.role_id == _roleitem.getrole[0]);
--    }
--    if (_sdrk != null && !string.IsNullOrEmpty(_sdrk.lottle_party_active_icon))
--    {
--        MyLottlePage.ShowActiveLab.text = ActiveStr();
--        EIFrameWork.StartCoroutine(GameUtility.LoadDynamicPic(_sdrk.lottle_party_active_icon, delegate(Texture obj)
--        {
--            MyLottlePage.SpecialActivityTex.mainTexture = obj;
--        }, "png"));
--        EIFrameWork.StartCoroutine(GameUtility.LoadDynamicPic(_sdrk.lottle_party_tip_icon, delegate(Texture obj)
--        {
--            MyLottlePage.SpecialShowTex.mainTexture = obj;
--        }, "jpg"));
--        //EIFrameWork.StartCoroutine(RoleInfoUtil.LoadAsynImage(SystemHelper.ICON_PATH + _sdrk.lottle_party_active_icon, "png",
--        //                                                      SystemHelper.ICON_PATH + _sdrk.lottle_party_active_icon, "png",delegate(Texture obj) {
--        //    SpecialActivityTex.mainTexture = obj;
--        //}));
--        //EIFrameWork.StartCoroutine(RoleInfoUtil.LoadAsynImage(SystemHelper.ICON_PATH + _sdrk.lottle_party_tip_icon, "jpg",
--        //                                                      SystemHelper.ICON_PATH + _sdrk.lottle_party_tip_icon, "jpg",delegate(Texture obj) {
--        //    SpecialShowTex.mainTexture = obj;
--        //}));
--        MyLottlePage.SpecialShowPanel.SetActive(true);
--    }
--}
			end,
			SetTime = function(this, paserdata)
				local _starttime; _starttime = AlarmManagerHelper.UnixTimeToDateTime(paserdata.starttime);
				local _endtime; _endtime = AlarmManagerHelper.UnixTimeToDateTime(paserdata.endtime);
				this.MyLottlePage.TimeLab.text = System.String.Format("结束时间: {0}月{1}日06时", _endtime.Month, _endtime.Day);
				local _overUnixtime; _overUnixtime = invokeintegeroperator(3, "-", paserdata.endtime, AlarmManager.Instance:currentTimeMillis(), System.Int64, System.Int64);
				AlarmManager.Instance:set("partyovertime", paserdata.endtime, (function(start, cur, __compiler_lua_end)
					local remainTime; remainTime = ( invokeintegeroperator(3, "-", __compiler_lua_end, cur, System.Int64, System.Int64) );
					this.MyLottlePage.GetTimeLab.text = this:ConvertCountDownToTime(remainTime);
				end), (function()
					this.MyLottlePage.GetTimeLab.text = "[ff6434]活动已结束[-]";
				end));
			end,
			ConvertCountDownToTime = function(this, Milliseconds)
				local span; span = System.TimeSpan.FromMilliseconds(Milliseconds);
				local timeStr; timeStr = System.String.Format("{0}天{1}时{2}分", span.Days, span.Hours, span.Minutes);
				if (span.Days < 1) then
					timeStr = (("[ff6434]" + timeStr) + "[-]");
				end;
				return timeStr;
			end,
			SetDataUpDo = function(this, _pas)
				this:ResetPage();
				this._mypa = _pas;
				local bgindex; bgindex = 0;
				local _ptex; _ptex = "";
				if this._mypa.isserver then
					local _sdp; _sdp = LogicStatic.Get__System_Predicate_T(typeof(EightGame.Data.Server.ServerDetailParty), (function(x) return (x.spartyid == this._mypa.staticid); end));
					if (_sdp == nil) then
						return ;
					end;
					this.detailid = _sdp.id;
					this.MyLottlePage.AllInLab.text = invokeforbasicvalue(_sdp.condition2, false, System.Int32, "ToString");
					local rlist; rlist = ShowRewardUtil.GetJSDataToList(_sdp.rewards);
					Eight.Framework.EIDebuger.Log("SetDataUpDo  服务器目前不支持图片设置 ");
					this.rewardList = rlist;
				else
					this.detailid = getexterninstanceindexer(this._mypa.partydetail, nil, "get_Item", 0).id;
					local pd; pd = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.sd_party_detail), this.detailid);
					if (pd == nil) then
						return ;
					end;
					local _stP; _stP = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.sd_party), this._mypa.branchid);
					local pathlist; pathlist = invokeforbasicvalue(_stP.bg, false, System.String, "Split", unpack(wraparray{wrapchar(',', 0x02C)}));
					if (pathlist.Length ~= _stP.tableid.Count) then
						_ptex = pathlist[1];
					else
						bgindex = _stP.tableid:FindIndex((function(x) return (x == typecast(this.detailid, System.Int32, false)); end));
						_ptex = pathlist[bgindex + 1];
					end;
					this.MyLottlePage.AllInLab.text = invokeforbasicvalue(pd.condition2, false, System.Int32, "ToString");
					this.rewardList:Clear();
					this.rewardOtherList:Clear();
					local i; i = 0;
					while (i < pd.showreward.Count) do
						local _innerList; _innerList = newexternlist(System.Collections.Generic.List_System.Int32, "System.Collections.Generic.List_System.Int32", "ctor", {});
						_innerList:Add(getexterninstanceindexer(pd.showreward, nil, "get_Item", i).key);
						_innerList:Add(getexterninstanceindexer(pd.showreward, nil, "get_Item", i).value);
						_innerList:Add(getexterninstanceindexer(pd.rewardtype, nil, "get_Item", i));
						if (i < 16) then
							this.rewardList:Add(_innerList);
						else
							this.rewardOtherList:Add(_innerList);
						end;
					i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
					end;
				end;
				if (this.rewardList.Count >= this.MyLottlePage.RewardList.Count) then
					this:SetItemDatas();
				end;
				_ptex = condexp(( System.String.IsNullOrEmpty(_ptex) ), true, "party_bg_15", false, (function() return _ptex; end));
				if (this.MyLottlePage.BGTex.name ~= _ptex) then
					local texpath; texpath = _ptex;
					Eight.Framework.EIFrameWork.StartCoroutine(GameUtility.LoadDynamicPic(texpath, (function(obj)
						this.MyLottlePage.BGTex.mainTexture = obj;
						this.MyLottlePage.BGTex.name = _ptex;
					end), "jpg"), false);
				end;
				this:SetAllScale();
			end,
			ResetPage = function(this)
				this.MyLottlePage.ShowBetterObjs:ForEach((function(x) return x:SetActive(true); end));
				this.MarkRewardList:Clear();
				local i; i = 0;
				while (i < this.MyLottlePage.RewardListObj.childCount) do
					local _temp; _temp = this.MyLottlePage.RewardListObj:GetChild(i):GetComponent(DetailOfSignleLottlePartyUICom);
					this.MarkRewardList:Add(_temp);
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
				this.MarkRewardList:Reverse();
				this.MarkEffecList:Clear();
				local i; i = 0;
				while (i < this.MyLottlePage.EffecListObj.childCount) do
					this.MarkEffecList:Add(this.MyLottlePage.EffecListObj:GetChild(i).gameObject);
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
				this.MyLottlePage.RewardList = this.MarkRewardList;
				this.MyLottlePage.EffecList = this.MarkEffecList;
				Eight.Framework.EIDebuger.Log(("ResetPage  RewardList : " + this.MyLottlePage.RewardList.Count));
				local i; i = 0;
				while (i < this.MyLottlePage.RewardList.Count) do
--RewardList[i].gameObject.SetActive(true);
					getexterninstanceindexer(this.MyLottlePage.RewardList, nil, "get_Item", i):ResetObj();
					getexterninstanceindexer(this.MyLottlePage.EffecList, nil, "get_Item", i):SetActive(false);
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
				this.MyLottlePage.SpecialShowPanel:SetActive(false);
			end,
			SetItemDatas = function(this)
				this._pcs = LogicStatic.GetList(typeof(EightGame.Data.Server.sd_party_dialraffle), (function(x) return (typecast(x.type, System.Int32, false) == this._mypa.detailtype); end));
				this.MaxStNum = this._pcs.Count;
				local _r; _r = LogicStatic.Get__System_Predicate_T(typeof(EightGame.Data.Server.RechargeInfoSerData), nil);
				local lpinfo; lpinfo = _r.alllottleids:Find((function(x) return (x.id == getexterninstanceindexer(this._mypa.partydetail, nil, "get_Item", 0).id); end));
				local isNull; isNull = (lpinfo == nil);
				local i; i = invokeintegeroperator(3, "-", this.MyLottlePage.RewardList.Count, 1, System.Int32, System.Int32);
				while (i >= 0) do
					getexterninstanceindexer(this.MyLottlePage.RewardList, nil, "get_Item", i):Init(getexterninstanceindexer(getexterninstanceindexer(this.rewardList, nil, "get_Item", i), nil, "get_Item", 0), getexterninstanceindexer(getexterninstanceindexer(this.rewardList, nil, "get_Item", i), nil, "get_Item", 1));
					if (not isNull) then
						if lpinfo.lottleids:Contains(( invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32) )) then
							getexterninstanceindexer(this.MyLottlePage.RewardList, nil, "get_Item", i):SetOver();
							this.MyLottlePage.RewardList:RemoveAt(i);
							this.MyLottlePage.EffecList:RemoveAt(i);
							this.rewardList:RemoveAt(i);
							this:CancleShowBetter(invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32));
						end;
					end;
				i = invokeintegeroperator(3, "-", i, 1, System.Int32, System.Int32);
				end;
--if(!isNull && lpinfo.lottleids.Count>0){AllInLab.gameObject.SetActive(false);}
				local _lidsCount; _lidsCount = UnityEngine.Mathf.Clamp(( condexp(isNull, true, 0, false, (function() return lpinfo.lottleids.Count; end)) ), 0, 16);
				if (_lidsCount < this.MaxStNum) then
					this.lengNum = invokeintegeroperator(2, "+", _lidsCount, 1, System.Int32, System.Int32);
					local _cost; _cost = getexterninstanceindexer(this._pcs, nil, "get_Item", invokeintegeroperator(3, "-", this.lengNum, 1, System.Int32, System.Int32)).cost;
					this.MyLottlePage.BuyLottleBt.gameObject:SetActive(true);
					this.MyLottlePage.BuyLottleLab.text = invokeforbasicvalue(_cost, false, System.Int32, "ToString");
					this.MyLottlePage.CostObj:SetActive((_cost ~= 0));
					this.MyLottlePage.FreeObj:SetActive((_cost == 0));
					this.MyLottlePage.MaxTipsObj:SetActive(false);
				else
					this.MyLottlePage.BuyLottleLab.text = "";
					this.MyLottlePage.BuyLottleBt.gameObject:SetActive(false);
					this.MyLottlePage.BuyAllBt.gameObject:SetActive(false);
					this.MyLottlePage.BuyOver:SetActive(false);
					this.MyLottlePage.MaxTipsObj:SetActive(true);
				end;
--BuyAllBt.gameObject.SetActive (!(_lidsCount == 0));
				this.MyLottlePage.BuyAllBt.gameObject:SetActive((( (not ( ((_lidsCount > 0) and (getexterninstanceindexer(this._pcs, nil, "get_Item", invokeintegeroperator(3, "-", _lidsCount, 1, System.Int32, System.Int32)).cost > 0)) )) ) or (_lidsCount == 0)));
			end,
			CancleShowBetter = function(this, nameid)
				if (nameid == 99) then
					this.MyLottlePage.ShowBetterObjs:ForEach((function(x) return x:SetActive(false); end));
				else
					local _obj; _obj = this.MyLottlePage.ShowBetterObjs:Find((function(x) return invokeforbasicvalue(x.name, false, System.String, "Contains", invokeforbasicvalue(nameid, false, System.Int32, "ToString")); end));
					if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", _obj, nil) then
						_obj:SetActive(false);
					end;
				end;
			end,
			FreshResetPageUI = function(this)
				if (this._mypa.detailtype == 14) then
					local action; action = EightGame.Data.Server.ServerService.AllpartiesfeshMethod();
					Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):NetworkRequest(action, (function(returnCode, response)
						local _pas02; _pas02 = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.PartyActiveSerData), this._mypa.id);
						this:SetDataUpDo(_pas02);
						Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIEvent, "ctor__System_String__Eight_Framework_EIEvent_ReturnCallBack__System_Object__System_Single", nil, "FRESH_CUR_BRANCH", nil, nil, 0.00));
					end), true, false);
				end;
			end,
			OutPage = function(this)
				this.gameObject:SetActive(false);
				Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIBoolEvent, "ctor__System_String__System_Boolean", nil, "SET_SUB_CLOSE_ACTIVE", false));
			end,
			StartAllinLottle = function(this, _callback)
				this.waittime = 0.08;
				this.waittime = this.waittime / 4;
				local i; i = invokeintegeroperator(3, "-", this.rewardList.Count, 1, System.Int32, System.Int32);
				while (i >= 0) do
					this.targeindex = i;
					this:CurTime(i, true);
				i = invokeintegeroperator(3, "-", i, 1, System.Int32, System.Int32);
				end;
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, (this.waittime * 10.00)), false, true);
				if externdelegationcomparewithnil(false, false, "LottlePartyPageController:_callback", _callback, nil, nil, false) then
					_callback();
				end;
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, (this.waittime * 20.00)), false, true);
				local timeCount; timeCount = 0;
				local j; j = invokeintegeroperator(3, "-", this.rewardList.Count, 1, System.Int32, System.Int32);
				while (j >= 0) do
					while this.isCheck do
						wrapyield(nil, false, false);
					end;
					this.isCheck = true;
					local _curj; _curj = j;
					this:CheckShowRole(this.rewardList, _curj, (function()
--SetOver(_curj);
						getexterninstanceindexer(this.MyLottlePage.RewardList, nil, "get_Item", _curj):SetOver();
						this.isCheck = false;
						this:NormalTime(_curj);
						this.MyLottlePage.RewardList:RemoveAt(_curj);
						this.MyLottlePage.EffecList:RemoveAt(_curj);
						this.rewardList:RemoveAt(_curj);
						this:CancleShowBetter(invokeintegeroperator(2, "+", _curj, 1, System.Int32, System.Int32));
						timeCount = invokeintegeroperator(2, "+", timeCount, 1, System.Int32, System.Int32);
--								_isClick = false;
--								EIFrameWork.Instance.DispatchEvent(new EIBoolEvent(  PartyMessageType.SET_BRANCH_BUTTONS_ACTIVE ,false ));
					end));
				j = invokeintegeroperator(3, "-", j, 1, System.Int32, System.Int32);
				end;
				while (timeCount < this.rewardList.Count) do
					wrapyield(nil, false, false);
				end;
				Eight.Framework.EIFrameWork.StartCoroutine(this:GetRemainRewards(), false);
				this:FreshResetPageUI();
				Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIBoolEvent, "ctor__System_String__System_Boolean", nil, "SET_BRANCH_BUTTONS_ACTIVE", true));
				this._isClick = false;
			end),
			GetRemainRewards = function(this)
				local timeCount; timeCount = 0;
				local i; i = 0;
				while (i < this.rewardOtherList.Count) do
					this:CheckShowRole(this.rewardOtherList, i, (function()
						timeCount = invokeintegeroperator(2, "+", timeCount, 1, System.Int32, System.Int32);
					end));
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
				while (timeCount < this.rewardList.Count) do
					wrapyield(nil, false, false);
				end;
			end),
			StartLottle = function(this, _cnum, _callback)
				if ((this.MyLottlePage.RewardList ~= nil) and (this.MyLottlePage.RewardList.Count > 0)) then
					if (_cnum > 4) then
						this.circleNum = UnityEngine.Random.Range(2, 4);
					else
						this.circleNum = _cnum;
					end;
					Eight.Framework.EIFrameWork.StartCoroutine(this:LottleShowEffec(_callback), false);
				end;
			end,
			LottleShowEffec = function(this, _callback)
				local nowcircle; nowcircle = 0;
				local curwtime; curwtime = this.waittime;
				while (nowcircle < this.circleNum) do
					local i; i = 0;
					while (i < this.MyLottlePage.RewardList.Count) do
						this:CurTime(i, false);
						wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, curwtime), false, true);
						this:NormalTime(i);
					i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
					end;
					nowcircle = invokeintegeroperator(2, "+", nowcircle, 1, System.Int32, System.Int32);
				end;
				curwtime = curwtime * 3.00;
				local _getitem; _getitem = newobject(DetailOfSignleLottlePartyUICom, "ctor", nil);
				local CurEff; CurEff = 0;
				local j; j = 0;
				while (j < this.MyLottlePage.RewardList.Count) do
					if (invokeintegeroperator(3, "-", this.targeindex, j, System.Int32, System.Int32) <= 2) then
						curwtime = curwtime * 2.00;
					end;
					if (j == this.targeindex) then
						CurEff = this.targeindex;
						_getitem = getexterninstanceindexer(this.MyLottlePage.RewardList, nil, "get_Item", this.targeindex);
						if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", _getitem, nil) then
							Eight.Framework.EIDebuger.GameLog(((((("RewardList.Count :" + this.MyLottlePage.RewardList.Count) + "j:") + j) + ",targeindex : ") + this.targeindex));
						end;
						break;
					else
						this:CurTime(j, false);
						wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, curwtime), false, true);
						this:NormalTime(j);
					end;
				j = invokeintegeroperator(2, "+", j, 1, System.Int32, System.Int32);
				end;
--yield return null;
--curwtime*=2;
				this:CurTime(CurEff, true);
				_getitem:SetOver();
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, curwtime), false, true);
--Debug.Log("缺奖励提示表现 ");
				if externdelegationcomparewithnil(false, false, "LottlePartyPageController:_callback", _callback, nil, nil, false) then
					_callback();
				end;
				this:SetOver(CurEff);
				this:CheckShowRole(this.rewardList, CurEff, (function()
					this:NormalTime(CurEff);
					this.MyLottlePage.RewardList:RemoveAt(CurEff);
					this.MyLottlePage.EffecList:RemoveAt(CurEff);
					this.rewardList:RemoveAt(CurEff);
					this:CancleShowBetter(invokeintegeroperator(2, "+", CurEff, 1, System.Int32, System.Int32));
					if (this.rewardList.Count <= 0) then
						Eight.Framework.EIFrameWork.StartCoroutine(this:GetRemainRewards(), false);
					end;
					this._isClick = false;
					Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIBoolEvent, "ctor__System_String__System_Boolean", nil, "SET_BRANCH_BUTTONS_ACTIVE", true));
				end));
			end),
			SetOver = function(this, _index)
--		EIDebuger.Log ("SetOver :  _index " +_index);
				this.lengNum = invokeintegeroperator(2, "+", this.lengNum, 1, System.Int32, System.Int32);
				local _dprlsit; _dprlsit = LogicStatic.GetList(typeof(EightGame.Data.Server.sd_party_dialraffle), (function(x) return (typecast(x.type, System.Int32, false) == this._mypa.detailtype); end));
				local isMax; isMax = (this.lengNum > _dprlsit.Count);
				this.MyLottlePage.BuyLottleBt.gameObject:SetActive((not isMax));
				this.MyLottlePage.MaxTipsObj:SetActive(isMax);
				if (not isMax) then
					if (this.lengNum < 3) then
						local action; action = EightGame.Data.Server.ServerService.AllpartiesfeshMethod();
						Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):NetworkRequest(action, (function(returnCode, response)
							Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIEvent, "ctor__System_String__Eight_Framework_EIEvent_ReturnCallBack__System_Object__System_Single", nil, "FRESH_CUR_BRANCH", nil, nil, 0.00));
						end), true, false);
					end;
					local _cost; _cost = getexterninstanceindexer(_dprlsit, nil, "get_Item", invokeintegeroperator(3, "-", this.lengNum, 1, System.Int32, System.Int32)).cost;
					this.MyLottlePage.BuyLottleLab.text = invokeforbasicvalue(_cost, false, System.Int32, "ToString");
					this.MyLottlePage.CostObj:SetActive((_cost ~= 0));
					this.MyLottlePage.FreeObj:SetActive((_cost == 0));
				else
					this.MyLottlePage.BuyLottleLab.text = "";
					this:FreshResetPageUI();
				end;
			end,
			CurTime = function(this, _index, _showEff)
				getexterninstanceindexer(this.MyLottlePage.EffecList, nil, "get_Item", _index).transform:GetChild(1).gameObject:SetActive(_showEff);
				getexterninstanceindexer(this.MyLottlePage.EffecList, nil, "get_Item", _index):SetActive(true);
			end,
			NormalTime = function(this, _index)
				getexterninstanceindexer(this.MyLottlePage.EffecList, nil, "get_Item", _index):SetActive(false);
			end,
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				MyLottlePage = __cs2lua_nil_field_value,
				_mypa = __cs2lua_nil_field_value,
				detailid = 0,
				rewardList = newexternlist(System.Collections.Generic.List_System.Collections.Generic.List_System.Int32, "System.Collections.Generic.List_System.Collections.Generic.List_System.Int32", "ctor", {}),
				rewardOtherList = newexternlist(System.Collections.Generic.List_System.Collections.Generic.List_System.Int32, "System.Collections.Generic.List_System.Collections.Generic.List_System.Int32", "ctor", {}),
				lengNum = 0,
				MaxStNum = 0,
				_isClick = false,
				_pcs = newexternlist(System.Collections.Generic.List_EightGame.Data.Server.sd_party_dialraffle, "System.Collections.Generic.List_EightGame.Data.Server.sd_party_dialraffle", "ctor", {}),
				circleNum = 1,
				waittime = 0.08,
				targeindex = 0,
				isShowingRole = false,
				isCheck = false,
				MarkRewardList = newexternlist(System.Collections.Generic.List_DetailOfSignleLottlePartyUICom, "System.Collections.Generic.List_DetailOfSignleLottlePartyUICom", "ctor", {}),
				MarkEffecList = newexternlist(System.Collections.Generic.List_UnityEngine.GameObject, "System.Collections.Generic.List_UnityEngine.GameObject", "ctor", {}),
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(UnityEngine.MonoBehaviour, "LottlePartyPageController", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LottlePartyPageController.__define_class();
