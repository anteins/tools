-- //  **********************************************************************
-- //  Copyright  2016  EIGHT Team . All rights reserved.
-- //  File     : LotteryDotsCom.cs
-- //  Author   : wolforce
-- //  Created  : 2016/2/17  18:42 
-- //  Purpose  : 圆点列表.
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "GameUtility";
require "LotteryDotModelCom";
require "LotteryCheckAvailable";

LotteryDotsCom = {
	__new_object = function(...)
		return newobject(LotteryDotsCom, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotteryDotsCom;

		local static_methods = {
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			Init = function(this, sdList)
				this._sdList = sdList;
				this._dotList:Clear();
				this:DestroyChildren(this.DotsGrid.transform);
				local i; i = 0;
				while (i < sdList.Count) do
					local go; go = GameUtility.InstantiateGameObject(this.DotModel.gameObject, this.DotsGrid.gameObject, ("dot_" + i), nil, nil, nil);
					go:SetActive(true);
					this._dotList:Add(go:GetComponent(LotteryDotModelCom));
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
				this.DotsGrid:Reposition();
--更新感叹号.
				LotteryCheckAvailable.UpdateAvailableInfo();
				this:UpdateDotNotice();
			end,
			UpdateUI = function(this)
				this:UpdateDotNotice();
			end,
			SetDotIndex = function(this, index)
				if ((index < 0) or (index >= this._dotList.Count)) then
					return ;
				end;
				this._curIndex = index;
				local i; i = 0;
				while (i < this._dotList.Count) do
					getexterninstanceindexer(this._dotList, nil, "get_Item", i):SetHihglight((index == i));
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
			end,
			UpdateDotNotice = function(this)
				if (this._sdList == nil) then
					return ;
				end;
				local dic; dic = LotteryCheckAvailable.GetDic();
				local i; i = 0;
				while (i < this._dotList.Count) do
					local info; info = getexterninstanceindexer(dic, nil, "get_Item", getexterninstanceindexer(this._sdList, nil, "get_Item", i).id);
					local isHighlight; isHighlight = (this._curIndex == i);
					local isNotice; isNotice = ((info.isOneHaveFreeChance or info.isTenCouponEnough) or info.isTenFriendPointEnough);
					getexterninstanceindexer(this._dotList, nil, "get_Item", i):UpdateUI(isHighlight, isNotice);
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
			end,
			DestroyChildren = function(this, trans)
				local children; children = newexternlist(System.Collections.Generic.List_UnityEngine.GameObject, "System.Collections.Generic.List_UnityEngine.GameObject", "ctor", {});
				for child in getiterator(trans) do
					children:Add(child.gameObject);
				end;
				trans:DetachChildren();
				children:ForEach((function(child) return UnityEngine.Object.Destroy(child); end));
			end,
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				DotModel = __cs2lua_nil_field_value,
				DotsGrid = __cs2lua_nil_field_value,
				_sdList = newexternlist(System.Collections.Generic.List_EightGame.Data.Server.sd_conscribe, "System.Collections.Generic.List_EightGame.Data.Server.sd_conscribe", "ctor", {}),
				_dotList = newexternlist(System.Collections.Generic.List_LotteryDotModelCom, "System.Collections.Generic.List_LotteryDotModelCom", "ctor", {}),
				_curIndex = 0,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(UnityEngine.MonoBehaviour, "LotteryDotsCom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryDotsCom.__define_class();
