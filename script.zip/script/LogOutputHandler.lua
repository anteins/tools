require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "NGUITools";

LogOutputHandler = {
	__new_object = function(...)
		return newobject(LogOutputHandler, nil, nil, ...);
	end,
	__define_class = function()
		local static = LogOutputHandler;

		local static_methods = {
			get_Instance = function()
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", LogOutputHandler._instance, nil) then
					local go; go = newexternobject(UnityEngine.GameObject, "UnityEngine.GameObject", "ctor", nil, "LogOutputHandler");
					LogOutputHandler._instance = NGUITools.AddMissingComponent(go, LogOutputHandler);
					UnityEngine.Object.DontDestroyOnLoad(go);
				end;
				return LogOutputHandler._instance;
			end,
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				_instance = __cs2lua_nil_field_value,
			};
			return static_fields;
		end;

		local static_props = {
			Instance = {
				get = static_methods.get_Instance,
			},
		};

		local static_events = nil;

		local instance_methods = {
			Init = function(this)
			end,
			OnEnable = function(this)
				UnityEngine.Application.RegisterLogCallback((function() local __compiler_delegation_32 = (function(logString, stackTrace, type) this:HandleLog(logString, stackTrace, type); end); setdelegationkey(__compiler_delegation_32, "LogOutputHandler:HandleLog", this, this.HandleLog); return __compiler_delegation_32; end)());
			end,
			OnDisable = function(this)
				UnityEngine.Application.RegisterLogCallback(nil);
			end,
			HandleLog = function(this, logString, stackTrace, type)
				if ((type ~= 0) or (type ~= 4)) then
					return ;
				end;
				local parameters; parameters = "";
				parameters = (parameters + ("Level=" + UnityEngine.WWW.EscapeURL(type:ToString())));
				parameters = (parameters + "&");
				parameters = (parameters + ("Message=" + UnityEngine.WWW.EscapeURL(logString)));
				parameters = (parameters + "&");
				parameters = (parameters + ("Stack_Trace=" + UnityEngine.WWW.EscapeURL(stackTrace)));
				parameters = (parameters + "&");
--Add any User, Game, or Device MetaData that would be useful to finding issues later
				parameters = (parameters + ("Device_Model=" + UnityEngine.WWW.EscapeURL(UnityEngine.SystemInfo.deviceModel)));
				local url; url = ((((((("http://" + this.project) + ".") + this.serviceAddr) + "/logstores/") + this.logstore) + "/track?APIVersion=0.6.0&") + parameters);
--StartCoroutine(SendData(url));
			end,
			SendData = function(this, url)
				local sendLog; sendLog = newexternobject(UnityEngine.WWW, "UnityEngine.WWW", "ctor", nil, url);
				wrapyield(sendLog, false, false);
			end),
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				project = "your project name",
				logstore = "your logstore name",
				serviceAddr = "http address of your log service project",
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(UnityEngine.MonoBehaviour, "LogOutputHandler", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LogOutputHandler.__define_class();
