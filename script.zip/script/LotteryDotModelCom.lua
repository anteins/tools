-- //  **********************************************************************
-- //  Copyright  2016  EIGHT Team . All rights reserved.
-- //  File     : LotteryDotModelCom.cs
-- //  Author   : wolforce
-- //  Created  : 2016/2/17  17:47 
-- //  Purpose  : 分页圆点按钮.
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";

LotteryDotModelCom = {
	__new_object = function(...)
		return newobject(LotteryDotModelCom, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotteryDotModelCom;

		local static_methods = {
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			SetHihglight = function(this, isHighlight)
				this.DotHighlight:SetActive(isHighlight);
			end,
			SetNotice = function(this, isNotice)
				this.DotNotice:SetActive(isNotice);
			end,
			UpdateUI = function(this, isHightlight, isNotice)
				this:SetHihglight(isHightlight);
				this:SetNotice(((not isHightlight) and isNotice));
			end,
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				DotBg = __cs2lua_nil_field_value,
				DotHighlight = __cs2lua_nil_field_value,
				DotNotice = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(UnityEngine.MonoBehaviour, "LotteryDotModelCom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryDotModelCom.__define_class();
