-- //  **********************************************************************
-- //  Copyright  2015  EIGHT Team . All rights reserved.
-- //  File     : LotterySceneCom.cs
-- //  Author   : wolforce
-- //  Created  : 2015/5/12  20:10 
-- //  Purpose  : 
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIUIBehaviour";

LotterySceneCom = {
	__new_object = function(...)
		return newobject(LotterySceneCom, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotterySceneCom;

		local static_methods = {
			cctor = function()
				EIUIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				animator = __cs2lua_nil_field_value,
				fxCamera = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIUIBehaviour, "LotterySceneCom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotterySceneCom.__define_class();
