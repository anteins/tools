-- //  **********************************************************************
-- //  Copyright  2016  EIGHT Team . All rights reserved.
-- //  File     : LotteryUtil.cs
-- //  Author   : wolforce
-- //  Created  : 2016/2/23  18:14 
-- //  Purpose  : .
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "AlarmManager";

LotteryUtil = {
	__new_object = function(...)
		return newobject(LotteryUtil, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotteryUtil;

		local static_methods = {
			GetCountDown = function(destUnixTime)
				local countDown; countDown = typecast(( invokeintegeroperator(3, "-", destUnixTime, AlarmManager.Instance:currentTimeMillis(), System.Int64, System.Int64) ), System.Int32, false);
				if (countDown < 0) then
					countDown = 0;
				end;
				countDown = invokeintegeroperator(0, "/", countDown, 1000, System.Int32, System.Int32);
				return countDown;
			end,
			GetCostCurrencyColor = function(player, costtype, cost)
				local red; red = "DA3838";
--string color = GetCostTypeField(player, costtype) >= cost ? GetCostTypeColor(costtype) : red;
				local color; color = LotteryUtil.GetCostTypeColor(costtype);
				return color;
			end,
			GetCostTypeField = function(player, costtype)
				local field; field = 0;
				if (1 == costtype) then
					field = player.gold;
				elseif (2 == costtype) then
					field = player.diamond;
				elseif (4 == costtype) then
					field = player.marnacrystal;
				elseif (5 == costtype) then
					field = player.friendPoint;
				end;
				return field;
			end,
			GetCostTypeColor = function(costtype)
				local white; white = "FFFFFF";
				local golden; golden = "FFD45D";
				local blue; blue = "74FDFC";
				local green; green = "9DFFBB";
				local pink; pink = "FFBE97";
				local color; color = white;
				if (1 == costtype) then
					color = golden;
				elseif (2 == costtype) then
					color = blue;
				elseif (4 == costtype) then
					color = green;
				elseif (5 == costtype) then
					color = pink;
				end;
				return color;
			end,
			GetCostTypeBtnBg = function(costtype)
				local red; red = "btn_red_lite";
				local blue; blue = "btn_blue_lite";
				local bg; bg = blue;
				if (1 == costtype) then
					bg = blue;
				elseif (2 == costtype) then
					bg = blue;
				elseif (4 == costtype) then
					bg = blue;
				elseif (5 == costtype) then
					bg = red;
				end;
				return bg;
			end,
			GetCostTypeCurrencyIcon = function(costtype)
				local diamond; diamond = "icon_diamond";
				local heart; heart = "icon_heart";
				local bg; bg = diamond;
				if (1 == costtype) then
					bg = diamond;
				elseif (2 == costtype) then
					bg = diamond;
				elseif (4 == costtype) then
					bg = diamond;
				elseif (5 == costtype) then
					bg = heart;
				end;
				return bg;
			end,
			GetCostTypeNotEnoughNetcodeMsg = function(costtype)
				local msg; msg = "货币不足";
				if (1 == costtype) then
					msg = EightGame.Component.NetCode.GetDesc(1003);
				elseif (2 == costtype) then
					msg = EightGame.Component.NetCode.GetDesc(1004);
				elseif (4 == costtype) then
					msg = EightGame.Component.NetCode.GetDesc(1005);
				elseif (5 == costtype) then
					msg = EightGame.Component.NetCode.GetDesc(1006);
				end;
				return msg;
			end,
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(System.Object, "LotteryUtil", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryUtil.__define_class();
