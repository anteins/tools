require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";

BaseDialogueEffect = {
	__new_object = function(...)
		return newobject(BaseDialogueEffect, nil, nil, ...);
	end,
	__define_class = function()
		local static = BaseDialogueEffect;

		local static_methods = {
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			Step = function(this, dt)
				this:OnStep(dt);
			end,
			get_IsFinish = function(this)
				return false;
			end,
			Reset = function(this)
			end,
			FinishThis = function(this)
			end,
			OnStep = function(this, dt)
			end,
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				mText = __cs2lua_nil_field_value,
				mDelay = 0,
			};
			return instance_fields;
		end;

		local instance_props = {
			IsFinish = {
				get = instance_methods.get_IsFinish,
			},
		};

		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(System.Object, "BaseDialogueEffect", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



BaseDialogueEffect.__define_class();
