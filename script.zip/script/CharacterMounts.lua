--  **********************************************************************
--  Copyright   2014  EIGHT Team . All rights reserved.
--  File     :  MountsCom.cs
--  Author   : wenlin
--  Created  : 2014/10/30  8:05 
--  Purpose  : 人物锚点综合
--  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIBehaviour";

CharacterMounts = {
	__new_object = function(...)
		return newobject(CharacterMounts, nil, nil, ...);
	end,
	__define_class = function()
		local static = CharacterMounts;

		local static_methods = {
			cctor = function()
				EIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			Start = function(this)
				if (this.mounts == nil) then
					return ;
				end;
				this._mountsDict = newexterndictionary(System.Collections.Generic.Dictionary_System.String_UnityEngine.Transform, "System.Collections.Generic.Dictionary_System.String_UnityEngine.Transform", "ctor", {});
				local i; i = 0;
				while (i < this.mounts.Length) do
				repeat
					if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.mounts[i + 1], nil) then
						break;
					end;
					if (not this._mountsDict:ContainsKey(this.mounts[i + 1].name)) then
						this._mountsDict:Add(this.mounts[i + 1].name, this.mounts[i + 1].transform);
					else
						Eight.Framework.EIDebuger.Log(System.String.Format("Character of {0} has the same mount {1}", this.name, this.mounts[i + 1].name));
					end;
				until true;
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
			end,
			GetMounts = function(this, mountName)
				if ((this._mountsDict ~= nil) and this._mountsDict:ContainsKey(mountName)) then
					return getexterninstanceindexer(this._mountsDict, nil, "get_Item", mountName);
				end;
				return nil;
			end,
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				mounts = __cs2lua_nil_field_value,
				_mountsDict = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIBehaviour, "CharacterMounts", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



CharacterMounts.__define_class();
