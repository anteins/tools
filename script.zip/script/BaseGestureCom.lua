-- **********************************************************************
--  Copyright   2014  EIGHT Team . All rights reserved.
--  File     	:  BaseGestureCom.cs
--  Author   	: qbkira
--  Created  	: 2014/11/3  上11:23 
--  Purpose  	: 
--  **********************************************************************
require "cs2lua__utility";
require "cs2lua__attributes";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIBehaviour";
require "UICamera";

BaseGestureCom = {
	__new_object = function(...)
		return newobject(BaseGestureCom, nil, nil, ...);
	end,
	__define_class = function()
		local static = BaseGestureCom;

		local static_methods = {
			cctor = function()
				EIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				__attributes = BaseGestureCom__Attrs,
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			OnGestureStart = function(this)
			end,
			OnGestureRelease = function(this)
			end,
			OnTouchDown = function(this, pos)
				this._touchEnable = true;
			end,
			OnTouchUp = function(this, pos)
			end,
			OnTouchUpdate = function(this, pos, prePos)
			end,
			TouchToLocalPosition = function(this, touchPos)
				local touchWorldPos; touchWorldPos = invokeexternoperator(CS.UnityEngine.Vector2, "op_Implicit", UICamera.currentCamera:ScreenToWorldPoint(invokeexternoperator(CS.UnityEngine.Vector2, "op_Implicit", touchPos)));
				local locPos; locPos = invokeexternoperator(CS.UnityEngine.Vector2, "op_Subtraction", touchWorldPos, newexternobject(UnityEngine.Vector2, "UnityEngine.Vector2", "ctor", nil, this.trans.position.x, this.trans.position.y));
				return locPos;
			end,
			OnPress = function(this, isPressed)
				local touchPosition; touchPosition = UnityEngine.Vector2.zero;
				touchPosition = invokeexternoperator(CS.UnityEngine.Vector2, "op_Implicit", UnityEngine.Input.mousePosition);
				local pos; pos = this:TouchToLocalPosition(touchPosition);
				if isPressed then
					this._touchEnable = true;
					this:OnTouchDown(pos);
				else
					this._touchEnable = false;
					this:OnTouchUp(pos);
				end;
				this._prePosition = pos;
			end,
			FixedUpdate = function(this)
				if (not this._touchEnable) then
					return ;
				end;
				local touchPosition; touchPosition = UnityEngine.Vector2.zero;
				touchPosition = invokeexternoperator(CS.UnityEngine.Vector2, "op_Implicit", UnityEngine.Input.mousePosition);
				local pos; pos = this:TouchToLocalPosition(touchPosition);
				this:OnTouchUpdate(pos, this._prePosition);
				this._prePosition = pos;
			end,
			ctor = function(this)
				this.base.ctor(this);
				this:__ctor();
			end,
			__ctor = function(this)
				if this.__ctor_called then
					return;
				else
					this.__ctor_called = true;
				end
				this._currentPosition = newexternobject(UnityEngine.Vector2, "UnityEngine.Vector2", nil, nil);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				_currentPosition = defaultvalue(UnityEngine.Vector2, "UnityEngine.Vector2", true),
				_dragPath = __cs2lua_nil_field_value,
				_touchEnable = false,
				_prePosition = UnityEngine.Vector2.zero,
				__attributes = BaseGestureCom__Attrs,
				__ctor_called = false,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIBehaviour, "BaseGestureCom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



BaseGestureCom.__define_class();
