-- //  **********************************************************************
-- //  Copyright  2016  EIGHT Team . All rights reserved.
-- //  File     : LotteryRareIconCom.cs
-- //  Author   : wolforce
-- //  Created  : 2016/5/18  15:15 
-- //  Purpose  : 抽卡奖励物品的稀有度标示.
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";

LotteryRareIconCom = {
	__new_object = function(...)
		return newobject(LotteryRareIconCom, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotteryRareIconCom;

		local static_methods = {
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			Init = function(this, cardLabelType, isOneCard)
				this.rareIcon01:SetActive(false);
				this.rareIcon02:SetActive(false);
				this.rareIcon01:SetActive((cardLabelType == se_cardlabeltype.SE_CARDLABELTYPE_RARE));
				this.rareIcon02:SetActive((cardLabelType == se_cardlabeltype.SE_CARDLABELTYPE_SUPERRARE));
				local pos; pos = UnityEngine.Vector3.zero;
				if isOneCard then
					pos = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, 0.00, 108.00, 0.00);
				else
					pos = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, 0.00, 74.00, 0.00);
				end;
				this.transform.localPosition = pos;
			end,
			Start = function(this)
			end,
			Update = function(this)
			end,
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				rareIcon01 = __cs2lua_nil_field_value,
				rareIcon02 = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(UnityEngine.MonoBehaviour, "LotteryRareIconCom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryRareIconCom.__define_class();
