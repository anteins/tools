-- ************
-- //  Copyright   2015  EIGHT Team . All rights reserved.
-- //  File     :   BaseExplainTipUI.cs
-- //  Author   : ${lp}
-- //  Created  : 2015/6/4  21:45 
-- //  Purpose  : 
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EightGame__Logic__UINode";
require "KnapsackUtility";
require "Eight__Framework__EIFrameWork";
require "EightGame__Component__GameResources";
require "GameUtility";
require "RoleInfoUtil";
require "LogicStatic";

BaseExplainTipUI = {
	__new_object = function(...)
		return newobject(BaseExplainTipUI, nil, nil, ...);
	end,
	__define_class = function()
		local static = BaseExplainTipUI;

		local static_methods = {
			cctor = function()
				EightGame.Logic.UINode.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				TipType_Monster = 11,
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			SetExplainTipCom = function(this, tipCom)
				this._tipCom = tipCom;
			end,
			Dispose = function(this)
--FIMME: DISPOSE 释放引用  by breen dispose
				this._tipCom = nil;
				return this.base:Dispose();
			end,
			SetQuailtySprite = function(this, spriteName)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this._tipCom._qualitySprite, nil) then
					this._tipCom._qualitySprite.spriteName = spriteName;
				end;
			end,
			SetIconTexture = function(this, icon, maskMaterial)
				if (invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._iconTexture, nil) or System.String.IsNullOrEmpty(icon)) then
					return ;
				end;
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", maskMaterial, nil) then
					this._tipCom._iconTexture.material = maskMaterial;
				end;
				this:StartCoroutine(this:LoadTexture(icon));
			end,
			SetItemRankBgSprite = function(this, rank, itemtype)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._itemRankBgSprite, nil) then
					return ;
				end;
				this._tipCom._itemRankBgSprite.spriteName = KnapsackUtility.GetBgSpriteNameFromRank(rank, typecast(itemtype, System.Int32, false));
			end,
			LoadTexture = function(this, path)
				local c; c = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.GameResources):LoadAsyn(path, "png", true);
				wrapyield(c.coroutine, false, true);
				local tex; tex = typeas(c.res, UnityEngine.Texture2D, false);
				this._tipCom._iconTexture.mainTexture = tex;
			end),
			SetName = function(this, nameStr)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._nameLbl, nil) then
					return ;
				end;
				this._tipCom._nameLbl.text = nameStr;
			end,
			SetNameNextLbl = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._nameNextLbl, nil) then
					return ;
				end;
				this._tipCom._nameNextLbl.text = str;
			end,
			SetDescribe = function(this, des)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._tipLbl, nil) then
					return ;
				end;
				this._tipCom._tipLbl.text = GameUtility.Unescape(des);
				this:SetBgHeight();
			end,
			SetBgHeight = function(this)
				local BG_ORI_HEIGHT; BG_ORI_HEIGHT = 304;
				local LABEL_ORI_HEIGHT; LABEL_ORI_HEIGHT = 56;
				local curH; curH = this._tipCom._tipLbl.height;
				local destBgHeight; destBgHeight = BG_ORI_HEIGHT;
--改变.
				if (curH > LABEL_ORI_HEIGHT) then
					local offset; offset = invokeintegeroperator(3, "-", curH, LABEL_ORI_HEIGHT, System.Int32, System.Int32);
					destBgHeight = invokeintegeroperator(2, "+", BG_ORI_HEIGHT, offset, System.Int32, System.Int32);
				end;
				this._tipCom._hadIconBG.height = destBgHeight;
			end,
			SetNoIconDescribe = function(this, des)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._noIconDescribe, nil) then
					return ;
				end;
				this._tipCom._noIconDescribe.text = GameUtility.Unescape(des);
				this._tipCom._noIconBgSprite:SetDimensions(472, invokeintegeroperator(2, "+", this._tipCom._noIconDescribe.height, 100, System.Int32, System.Int32));
			end,
			SetNoIconAddDescribe = function(this, des)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._noIconAddLbl, nil) then
					return ;
				end;
				this._tipCom._noIconAddLbl.text = des;
			end,
			SetGoodsLbl = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._goodOwnLbl, nil) then
					return ;
				end;
				this._tipCom._goodOwnLbl.text = str;
			end,
			SetRoleStar = function(this, starCount)
				this:SetRoleGroupActive(true);
				local index; index = 0;
				while (index < this._tipCom._roleStarList.Count) do
					if (index < starCount) then
						getexterninstanceindexer(this._tipCom._roleStarList, nil, "get_Item", index).gameObject:SetActive(true);
						getexterninstanceindexer(this._tipCom._roleStarList, nil, "get_Item", index).spriteName = "start";
					else
						getexterninstanceindexer(this._tipCom._roleStarList, nil, "get_Item", index).gameObject:SetActive(false);
						getexterninstanceindexer(this._tipCom._roleStarList, nil, "get_Item", index).spriteName = "star__bg";
					end;
				index = invokeintegeroperator(2, "+", index, 1, System.Int32, System.Int32);
				end;
			end,
			SetRoleProperty = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._propertySprite, nil) then
					return ;
				end;
				this._tipCom._propertySprite.spriteName = str;
			end,
			SetMonsterProperty = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._monsterProperty, nil) then
					return ;
				end;
				this._tipCom._monsterProperty.spriteName = str;
			end,
			SetMonsterResist = function(this, enemy)
				this:SetMonsterResistSub(this._tipCom._resistGroundLbl, this._tipCom._resistGroundSprite, enemy, se_elementtype.SE_ELEMENTTYPE_GROUND);
				this:SetMonsterResistSub(this._tipCom._resistWaterLbl, this._tipCom._resistWaterSprite, enemy, se_elementtype.SE_ELEMENTTYPE_WATER);
				this:SetMonsterResistSub(this._tipCom._resistFireLbl, this._tipCom._resistFireSprite, enemy, se_elementtype.SE_ELEMENTTYPE_FIRE);
				this:SetMonsterResistSub(this._tipCom._resistWindLbl, this._tipCom._resistWindSprite, enemy, se_elementtype.SE_ELEMENTTYPE_WIND);
			end,
			SetMonsterResistSub = function(this, label, sprite, enemy, ele)
				local val; val = 0;
				local __compiler_switch_169 = ele;
				if __compiler_switch_169 == se_elementtype.SE_ELEMENTTYPE_GROUND then
					val = enemy.ground_resist;
				elseif __compiler_switch_169 == se_elementtype.SE_ELEMENTTYPE_WATER then
					val = enemy.water_resist;
				elseif __compiler_switch_169 == se_elementtype.SE_ELEMENTTYPE_FIRE then
					val = enemy.fire_resist;
				elseif __compiler_switch_169 == se_elementtype.SE_ELEMENTTYPE_WIND then
					val = enemy.wind_resist;
				end;
				local color; color = "FFFFFF";
				local spriteName; spriteName = "";
				if (val > 10000) then
					color = "89FF75";
--绿色.
					spriteName = "resist_arrow_up";
				end;
				if (val == 10000) then
					color = "FFFFFF";
					spriteName = "";
				end;
				if ((0 < val) and (val < 10000)) then
					color = "FF5555";
--红色.
					spriteName = "resist_arrow_down_01";
				end;
				if (val <= 0) then
					color = "AEAEAE";
--灰色.
					spriteName = "resist_arrow_down_02";
				end;
--设置UI.
				local percent; percent = invokeintegeroperator(0, "/", val, 100, System.Int32, System.Int32);
				if invokeexternoperator(CS.UnityEngine.Object, "op_Implicit", label) then
					label.text = System.String.Format("[{0}]{1}%[-]", color, percent);
				end;
				if invokeexternoperator(CS.UnityEngine.Object, "op_Implicit", sprite) then
					sprite.gameObject:SetActive((val ~= 10000));
					sprite.spriteName = spriteName;
--根据文字长度改变箭头的位移.
					local pos; pos = sprite.transform.localPosition;
					pos.x = invokeintegeroperator(4, "*", ( invokeintegeroperator(2, "+", getforbasicvalue(invokeforbasicvalue(percent, false, System.Int32, "ToString"), false, System.String, "Length"), 1, System.Int32, System.Int32) ), 10, System.Int32, System.Int32);
					sprite.transform.localPosition = pos;
				end;
			end,
			SetSkillIcon = function(this, skillIcon)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._skillIcon, nil) then
					return ;
				end;
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._skillIcon, nil) then
					return ;
				end;
				this._tipCom._skillIcon.gameObject:SetActive(true);
--set image.
				Eight.Framework.EIFrameWork.StartCoroutine(RoleInfoUtil.LoadAsynImage(("GameAssets/Textures/Icon/" + skillIcon), "png", nil, nil, (function(tex)
					this._tipCom._skillIcon.mainTexture = tex;
				end)), false);
			end,
			SetSkillNameLbl = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._skillNameLbl, nil) then
					return ;
				end;
				this._tipCom._skillNameLbl.text = str;
			end,
			SetSkillDescLbl = function(this, str)
				if (invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._skillDescLbl, nil) or invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._skillBgSprite, nil)) then
					return ;
				end;
				this._tipCom._skillDescLbl.text = GameUtility.Unescape(str);
				local height; height = condexp((this._tipCom._skillDescLbl.height > 30), false, (function() return invokeintegeroperator(2, "+", this._tipCom._skillDescLbl.height, 180, System.Int32, System.Int32); end), true, 250);
				this._tipCom._skillBgSprite:SetDimensions(this._tipCom._skillBgSprite.width, height);
			end,
			SetSkillTypeLbl = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._skillTypeLbl, nil) then
					return ;
				end;
				this._tipCom._skillTypeLbl.text = str;
			end,
			SetAllGroupFalse = function(this)
				this._tipCom._itemRankBgSprite.gameObject:SetActive(false);
				this:SetRoleGroupActive(false);
				this:SetGoodGroupActive(false);
				this:SetRoleChipGroupActive(false);
				this:SetMonsterGroupActive(false);
				this:SetSoldGroupActive(false);
				this:SetSkillGroupActive(false);
			end,
			SetRoleGroupActive = function(this, b)
				this._tipCom._roleGroup:SetActive(b);
			end,
			SetGoodGroupActive = function(this, b)
				this._tipCom._goodGroup:SetActive(b);
			end,
			SetRoleChipGroupActive = function(this, b)
				this._tipCom._roleChipGroup:SetActive(b);
			end,
			SetMonsterGroupActive = function(this, b)
				this._tipCom._monsterGroup:SetActive(b);
			end,
			SetSoldGroupActive = function(this, b)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._soldLbl, nil) then
					return ;
				end;
				this._tipCom._soldLbl.transform.parent.gameObject:SetActive(b);
			end,
			SetSkillGroupActive = function(this, b)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._skillGroup, nil) then
					return ;
				end;
				this._tipCom._skillGroup:SetActive(b);
			end,
			SetSoldPrice = function(this, price)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._soldLbl, nil) then
					return ;
				end;
				this:SetSoldGroupActive(true);
				this._tipCom._soldLbl.text = invokeforbasicvalue(price, false, System.Int32, "ToString");
			end,
			SetMonsterInfo = function(this, lvStr, shield)
				this:SetMonsterGroupActive(true);
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._tipCom._monsterLvLbl, nil) then
					return ;
				end;
				this._tipCom._monsterLvLbl.text = lvStr;
				this._tipCom._dunList:ForEach((function(obj)
					obj.gameObject:SetActive(false);
				end));
				local shieldtable; shieldtable = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_shield), shield);
				if (shieldtable == nil) then
					return ;
				end;
				if (shieldtable.shieldtype.Count > 0) then
					local keyvalue; keyvalue = getexterninstanceindexer(shieldtable.shieldtype, nil, "get_Item", 0);
					if (keyvalue.key == 1000) then
						this._tipCom._dunList:ForEach((function(obj)
							obj.gameObject:SetActive(true);
						end));
					else
						if (this._tipCom._dunList.Count > invokeintegeroperator(3, "-", keyvalue.key, 1, System.Int32, System.Int32)) then
							getexterninstanceindexer(this._tipCom._dunList, nil, "get_Item", invokeintegeroperator(3, "-", keyvalue.key, 1, System.Int32, System.Int32)).gameObject:SetActive(true);
						end;
					end;
				end;
				this._tipCom._dunGrid.repositionNow = true;
			end,
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				_tipCom = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = {
			"System.Collections.IEnumerable",
		};

		local interface_map = {
			IEnumerable_GetEnumerator = "EINode_GetEnumerator",
		};


		return defineclass(EightGame.Logic.UINode, "BaseExplainTipUI", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



BaseExplainTipUI.__define_class();
