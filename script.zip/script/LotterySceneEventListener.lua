-- //  **********************************************************************
-- //  Copyright  2016  EIGHT Team . All rights reserved.
-- //  File     : LotterySceneEventListener.cs
-- //  Author   : wolforce
-- //  Created  : 2016/2/25  14:23 
-- //  Purpose  : 转发动画事件.
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIBehaviour";

LotterySceneEventListener = {
	__new_object = function(...)
		return newobject(LotterySceneEventListener, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotterySceneEventListener;

		local static_methods = {
			cctor = function()
				EIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			MotionHandle = function(this, e)
				if externdelegationcomparewithnil(false, false, "LotterySceneEventListener:onAniMotion", this, nil, "onAniMotion", false) then
					this.onAniMotion(e);
				end;
			end,
			EffectHandle = function(this, eventId)
			end,
			Start = function(this)
			end,
			Update = function(this)
			end,
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				onAniMotion = delegationwrap(),
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = {
			"IUnityEventHandler",
		};

		local interface_map = {
			IUnityEventHandler_MotionHandle = "MotionHandle",
			IUnityEventHandler_EffectHandle = "EffectHandle",
		};


		return defineclass(EIBehaviour, "LotterySceneEventListener", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotterySceneEventListener.__define_class();
