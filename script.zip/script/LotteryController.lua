-- //  **********************************************************************
-- //  Copyright  2016  EIGHT Team . All rights reserved.
-- //  File     : LotteryController.cs
-- //  Author   : wolforce
-- //  Created  : 2016/2/17  18:51 
-- //  Purpose  : 分页的整体交互控制.
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";

LotteryController = {
	__new_object = function(...)
		return newobject(LotteryController, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotteryController;

		local static_methods = {
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			Init = function(this, pageCount)
				local isShow; isShow = (pageCount > 1);
				this.LeftBtn.gameObject:SetActive(isShow);
				this.RightBtn.gameObject:SetActive(isShow);
			end,
			Start = function(this)
			end,
			Update = function(this)
			end,
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				LeftBtn = __cs2lua_nil_field_value,
				RightBtn = __cs2lua_nil_field_value,
				SwipeEventHandleBg = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(UnityEngine.MonoBehaviour, "LotteryController", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryController.__define_class();
