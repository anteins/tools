-- //  **********************************************************************
-- //  Copyright  2015  EIGHT Team . All rights reserved.
-- //  File     : LotteryBtnEffect.cs
-- //  Author   : wolforce
-- //  Created  : 2015/7/13  17:00 
-- //  Purpose  : 按钮点击效果.
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIBehaviour";
require "UIEventListener";
require "GuideManager";

LotteryBtnEffect = {
	__new_object = function(...)
		return newobject(LotteryBtnEffect, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotteryBtnEffect;

		local static_methods = {
			cctor = function()
				EIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			Start = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.target, nil) then
					this.target = this.gameObject;
				end;
				this._oriPos = this.target.transform.localPosition;
				delegationadd(false, false, "UIEventListener:onPress", UIEventListener.Get(this.gameObject), nil, "onPress", (function(go, state)
					if (not GuideManager.Instance:IsRunning()) then
						if this.enableOffset then
							this.target.transform.localPosition = condexp(state, false, (function() return newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, this._oriPos.x, (this._oriPos.y + this.offsetY), this._oriPos.z); end), false, (function() return this._oriPos; end));
						end;
						if this.enableScale then
							this.target.transform.localScale = condexp(state, false, (function() return invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", UnityEngine.Vector3.one, this.scale); end), false, (function() return UnityEngine.Vector3.one; end));
						end;
					end;
				end));
			end,
			Update = function(this)
			end,
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				offsetY = -15.00,
				scale = 0.90,
				enableOffset = false,
				enableScale = true,
				target = __cs2lua_nil_field_value,
				_oriPos = UnityEngine.Vector3.zero,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIBehaviour, "LotteryBtnEffect", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryBtnEffect.__define_class();
