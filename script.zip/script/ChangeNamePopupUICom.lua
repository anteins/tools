require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIEntityBehaviour";
require "Eight__Framework__EIFrameWork";
require "EightGame__Component__NetworkClient";

ChangeNamePopupUICom = {
	__new_object = function(...)
		return newobject(ChangeNamePopupUICom, nil, nil, ...);
	end,
	__define_class = function()
		local static = ChangeNamePopupUICom;

		local static_methods = {
			cctor = function()
				EIEntityBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			Start = function(this)
			end,
			Update = function(this)
			end,
			OnEnable = function(this)
				this:SwitchCostTip();
			end,
			SwitchCostTip = function(this)
				local player; player = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetDataByCls__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
				local isHaveNameHistory; isHaveNameHistory = false;
				if (player.namehistory ~= nil) then
					local nameHistory; nameHistory = System.Text.Encoding.UTF8:GetString(player.namehistory);
					if (getforbasicvalue(nameHistory, false, System.String, "Length") > 0) then
						local nameHistoryList; nameHistoryList = typeas(MiniJSON.Json.Deserialize(nameHistory), System.Collections.Generic.List_System.Object, false);
						if (nameHistoryList.Count > 0) then
							isHaveNameHistory = true;
						end;
					end;
				end;
				this.costTipGO:SetActive(isHaveNameHistory);
				this.freeTipGO:SetActive((not isHaveNameHistory));
			end,
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				nameInput = __cs2lua_nil_field_value,
				costTipGO = __cs2lua_nil_field_value,
				freeTipGO = __cs2lua_nil_field_value,
				errorTipLabel = __cs2lua_nil_field_value,
				costTipAmountLbl = __cs2lua_nil_field_value,
				okBtn = __cs2lua_nil_field_value,
				cancelBtn = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIEntityBehaviour, "ChangeNamePopupUICom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



ChangeNamePopupUICom.__define_class();
