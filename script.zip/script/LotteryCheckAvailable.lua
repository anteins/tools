-- //  **********************************************************************
-- //  Copyright  2015  EIGHT Team . All rights reserved.
-- //  File     : LotteryCheckAvailable.cs
-- //  Author   : wolforce
-- //  Created  : 2015/10/05  16:41 
-- //  Purpose  : 检查是否有金币或钻石的免费抽奖机会.
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "LogicStatic";
require "LotteryUtil";
require "KnapsackUtility";

LotteryCheckAvailable = {
	__new_object = function(...)
		return newobject(LotteryCheckAvailable, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotteryCheckAvailable;

		local static_methods = {
			UpdateAvailableInfo = function()
				LotteryCheckAvailable._dic:Clear();
				local dyList; dyList = LogicStatic.GetList(typeof(EightGame.Data.Server.LotterySerData), nil);
				local sdList; sdList = LogicStatic.GetList(typeof(EightGame.Data.Server.sd_conscribe), nil);
				local i; i = 0;
				while (i < sdList.Count) do
					local sd; sd = getexterninstanceindexer(sdList, nil, "get_Item", i);
					local dy; dy = nil;
					if (dyList ~= nil) then
						dy = dyList:Find((function(x) return (x.luckid == sd.id); end));
					end;
					local isOneHaveFreeChance; isOneHaveFreeChance = LotteryCheckAvailable.CheckHaveFreeChance(sd, dy);
					local isOneCouponEnough; isOneCouponEnough = LotteryCheckAvailable.CheckCouponEnough(sd.costitem);
					local isTenCouponEnough; isTenCouponEnough = LotteryCheckAvailable.CheckCouponEnough(sd.costtenitem);
					local isTenFriendPointEnough; isTenFriendPointEnough = LotteryCheckAvailable.CheckFriendPointEnough(typecast(sd.costtype, EightGame.Data.Server.se_currency, true), sd.costten);
					LotteryCheckAvailable._dic:Add(sd.id, newobject(LotteryCheckAvailable.Info, "ctor", nil, isOneHaveFreeChance, isOneCouponEnough, isTenCouponEnough, isTenFriendPointEnough));
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
			end,
			GetDic = function()
				return LotteryCheckAvailable._dic;
			end,
			CheckHaveFreeChance = function(sd, dy)
				local flag; flag = false;
				local isHaveFree; isHaveFree = sd.free;
				local isDailyReset; isDailyReset = (isHaveFree and (sd.max > -1));
				local isHaveFreeChance; isHaveFreeChance = (isHaveFree and ( ((dy == nil) or (dy.todayfreecount < sd.max)) ));
				local isCD; isCD = (isHaveFree and ( ((dy == nil) or (LotteryUtil.GetCountDown(dy.destunixtime) <= 0)) ));
				if (( (((isHaveFree and isDailyReset) and isHaveFreeChance) and isCD) ) or ( ((isHaveFree and (not isDailyReset)) and isCD) )) then
					flag = true;
				end;
				return flag;
			end,
			CheckCouponEnough = function(costitem)
				local flag; flag = false;
				local isHaveCoupon; isHaveCoupon = (costitem.key ~= 0);
				flag = (isHaveCoupon and (KnapsackUtility.GetTotalNumByStaticId(costitem.key) >= costitem.value));
				return flag;
			end,
			CheckFriendPointEnough = function(costtype, costAmount)
				local flag; flag = false;
				local player; player = LogicStatic.Get__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
				if (player == nil) then
					return flag;
				end;
				local isFriendPoint; isFriendPoint = (costtype == se_currency.SE_CURRENCY_FRIENDPOINT);
				flag = (isFriendPoint and (player.friendPoint >= costAmount));
				return flag;
			end,
			IsHaveAvailable = function()
				LotteryCheckAvailable.UpdateAvailableInfo();
				for kv in getiterator(LotteryCheckAvailable._dic) do
					local info; info = kv.Value;
					if info.isOneHaveFreeChance then
						return true;
					end;
--if (info.isOneCouponEnough)      return true;
					if info.isTenCouponEnough then
						return true;
					end;
					if info.isTenFriendPointEnough then
						return true;
					end;
				end;
				return false;
			end,
			IsOneHaveFreeChance = function()
				for kv in getiterator(LotteryCheckAvailable._dic) do
					if kv.Value.isOneHaveFreeChance then
						return true;
					end;
				end;
				return false;
			end,
			IsOneCouponEnough = function()
				for kv in getiterator(LotteryCheckAvailable._dic) do
					if kv.Value.isOneCouponEnough then
						return true;
					end;
				end;
				return false;
			end,
			IsTenCouponEnough = function()
				for kv in getiterator(LotteryCheckAvailable._dic) do
					if kv.Value.isTenCouponEnough then
						return true;
					end;
				end;
				return false;
			end,
			IsTenFriendPointEnough = function()
				for kv in getiterator(LotteryCheckAvailable._dic) do
					if kv.Value.isTenFriendPointEnough then
						return true;
					end;
				end;
				return false;
			end,
			ResetStaticVar = function()
				LotteryCheckAvailable._dic = newexterndictionary(System.Collections.Generic.Dictionary_System.Int32_LotteryCheckAvailable.Info, "System.Collections.Generic.Dictionary_System.Int32_LotteryCheckAvailable.Info", "ctor", {});
			end,
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				_dic = newexterndictionary(System.Collections.Generic.Dictionary_System.Int32_LotteryCheckAvailable.Info, "System.Collections.Generic.Dictionary_System.Int32_LotteryCheckAvailable.Info", "ctor", {}),
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(System.Object, "LotteryCheckAvailable", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};




LotteryCheckAvailable.Info = {
	__new_object = function(...)
		return newobject(LotteryCheckAvailable.Info, "ctor", nil, ...);
	end,
	__define_class = function()
		local static = LotteryCheckAvailable.Info;

		local static_methods = {
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			ctor = function(this, isOneHaveFreeChance, isOneCouponEnough, isTenCouponEnough, isTenFriendPointEnough)
				this.isOneHaveFreeChance = isOneHaveFreeChance;
				this.isOneCouponEnough = isOneCouponEnough;
				this.isTenCouponEnough = isTenCouponEnough;
				this.isTenFriendPointEnough = isTenFriendPointEnough;
				return this;
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				isOneHaveFreeChance = false,
				isOneCouponEnough = false,
				isTenCouponEnough = false,
				isTenFriendPointEnough = false,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(System.Object, "LotteryCheckAvailable.Info", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryCheckAvailable.Info.__define_class();
LotteryCheckAvailable.__define_class();
