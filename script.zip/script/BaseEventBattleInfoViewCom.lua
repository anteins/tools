-- ************
-- //  Copyright   2015  EIGHT Team . All rights reserved.
-- //  File     :   BaseEventBattleInfoViewCom.cs
-- //  Author   : ${lp}
-- //  Created  : 2015/4/29  11:38 
-- //  Purpose  : 
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIUIBehaviour";
require "Eight__Framework__EIFrameWork";
require "EightGame__Component__GameResources";
require "GameUtility";
require "ItemFirstPassCom";
require "UIScrollView";
require "EightGame__Component__NetworkClient";
require "ItemDataWhithFirstIdentify";
require "BattleRankListUIcom";

BaseEventBattleInfoViewCom = {
	__new_object = function(...)
		return newobject(BaseEventBattleInfoViewCom, nil, nil, ...);
	end,
	__define_class = function()
		local static = BaseEventBattleInfoViewCom;

		local static_methods = {
			cctor = function()
				EIUIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				_enemyIconPath = "GameAssets/Textures/Icon/",
				_enemyDefaultIcon = "001",
				_itemPath = "Common/UI_Show_FirstPass_Item",
				_rankingListPath = "BattleRankUI/BattleRankPanel",
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			SetInfo = function(this, eventIdParam, callbackBeginBattle)
				this._eventIdParam = eventIdParam;
				delegationset(false, false, "BaseEventBattleInfoViewCom:_callbackBeginBattle", this, nil, "_callbackBeginBattle", callbackBeginBattle);
				this:StartCoroutine(this:InitRankingList());
			end,
			OnClickBattleButton = function(this)
				if externdelegationcomparewithnil(false, false, "BaseEventBattleInfoViewCom:_callbackBeginBattle", this, nil, "_callbackBeginBattle", false) then
					this._callbackBeginBattle(this._eventIdParam);
				end;
--EIIntEvent e = new EIIntEvent(WorldMessageType.WORLD_BATTLE_FORMATION_SELECT, this.Info.BattleInfoId);
--entity.DispatchEvent(e);
			end,
			SetDesc = function(this, desc)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Implicit", this.LabelDesc) then
					this.LabelDesc.text = desc;
				end;
			end,
			SetEnemies = function(this, enemies)
				if (enemies.Count > 4) then
					local sindex; sindex = 0;
					local index; index = ( invokeintegeroperator(3, "-", enemies.Count, 4, System.Int32, System.Int32) );
					local imax; imax = enemies.Count;
					while (index < imax) do
						getexterninstanceindexer(this.SpriteEnemies, nil, "get_Item", sindex).gameObject:SetActive(true);
						if (sindex == 3) then
							getexterninstanceindexer(this.SpriteEnemies, nil, "get_Item", sindex).transform.localScale = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, 1.20, 1.20, 0);
						else
							getexterninstanceindexer(this.SpriteEnemies, nil, "get_Item", sindex).transform.localScale = UnityEngine.Vector3.one;
						end;
						getexterninstanceindexer(this.SpriteEnemies, nil, "get_Item", sindex):SetValue(getexterninstanceindexer(enemies, nil, "get_Item", index), true);
						sindex = invokeintegeroperator(2, "+", sindex, 1, System.Int32, System.Int32);
					index = invokeintegeroperator(2, "+", index, 1, System.Int32, System.Int32);
					end;
				else
					local index; index = 0;
					local imax; imax = 4;
					while (index < imax) do
						if (index < enemies.Count) then
							getexterninstanceindexer(this.SpriteEnemies, nil, "get_Item", index).gameObject:SetActive(true);
							if (index == invokeintegeroperator(3, "-", enemies.Count, 1, System.Int32, System.Int32)) then
								getexterninstanceindexer(this.SpriteEnemies, nil, "get_Item", index).transform.localScale = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, 1.20, 1.20, 0);
							else
								getexterninstanceindexer(this.SpriteEnemies, nil, "get_Item", index).transform.localScale = UnityEngine.Vector3.one;
							end;
							getexterninstanceindexer(this.SpriteEnemies, nil, "get_Item", index):SetValue(getexterninstanceindexer(enemies, nil, "get_Item", index), true);
						else
							getexterninstanceindexer(this.SpriteEnemies, nil, "get_Item", index).gameObject:SetActive(false);
						end;
					index = invokeintegeroperator(2, "+", index, 1, System.Int32, System.Int32);
					end;
				end;
				this._enemisTable.repositionNow = true;
			end,
			SetItems = function(this, items)
				this:StartCoroutine(this:InitItemPrefab(items));
--_itemGrid.repositionNow = true;
			end,
			InitItemPrefab = function(this, items)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._itemFirstModelPrefab, nil) then
					local c; c = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.GameResources):LoadAsyn(("GameAssets/Prefabs/UI/" + BaseEventBattleInfoViewCom._itemPath), "prefab", false);
					wrapyield(c.coroutine, false, true);
					this._itemFirstModelPrefab = typeas(c.res, UnityEngine.GameObject, false);
				end;
				if (this._cachItemoComList == nil) then
					this._cachItemoComList = newexternlist(System.Collections.Generic.List_ItemFirstPassCom, "System.Collections.Generic.List_ItemFirstPassCom", "ctor", {});
				end;
				if (items.Count < this._cachItemoComList.Count) then
					local index; index = 0;
					while (index < this._cachItemoComList.Count) do
						if (index < items.Count) then
							getexterninstanceindexer(this._cachItemoComList, nil, "get_Item", index).gameObject:SetActive(true);
							getexterninstanceindexer(this._cachItemoComList, nil, "get_Item", index):SetItemInfo__System_Boolean__EightGame_Data_Server_sd_item_item(getexterninstanceindexer(items, nil, "get_Item", index).identify, getexterninstanceindexer(items, nil, "get_Item", index).item);
							getexterninstanceindexer(this._cachItemoComList, nil, "get_Item", index).transform.localPosition = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, (index * this._distancFloat), 0, 0);
--ItemModelUtility.UpdateView(_cachItemoComList[ index ] , items[ index ]  );
						else
							getexterninstanceindexer(this._cachItemoComList, nil, "get_Item", index).gameObject:SetActive(false);
						end;
					index = invokeintegeroperator(2, "+", index, 1, System.Int32, System.Int32);
					end;
				else
					local index; index = 0;
					while (index < items.Count) do
						if (index < this._cachItemoComList.Count) then
							getexterninstanceindexer(this._cachItemoComList, nil, "get_Item", index).gameObject:SetActive(true);
							getexterninstanceindexer(this._cachItemoComList, nil, "get_Item", index):SetItemInfo__System_Boolean__EightGame_Data_Server_sd_item_item(getexterninstanceindexer(items, nil, "get_Item", index).identify, getexterninstanceindexer(items, nil, "get_Item", index).item);
							getexterninstanceindexer(this._cachItemoComList, nil, "get_Item", index).transform.localPosition = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, (index * this._distancFloat), 0, 0);
						else
							local go; go = GameUtility.InstantiateGameObject(this._itemFirstModelPrefab, this._itemGrid.gameObject, "itemcell", nil, nil, nil);
							local firstpassCom; firstpassCom = go:GetComponent(ItemFirstPassCom);
							firstpassCom:SetItemInfo__System_Boolean__EightGame_Data_Server_sd_item_item(getexterninstanceindexer(items, nil, "get_Item", index).identify, getexterninstanceindexer(items, nil, "get_Item", index).item);
							this._cachItemoComList:Add(firstpassCom);
							go.transform.localPosition = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, (index * this._distancFloat), 0, 0);
						end;
					index = invokeintegeroperator(2, "+", index, 1, System.Int32, System.Int32);
					end;
				end;
				this:StartCoroutine(this:ResetPanelPosition());
--_itemGrid.transform.localPosition = new Vector3( -179f ,_itemGrid.transform.localPosition.y, _itemGrid.transform.localPosition.z );
			end),
			ResetPanelPosition = function(this)
				local scrollView; scrollView = this._itemGrid.transform.parent:GetComponent(UIScrollView);
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", scrollView, nil) then
					return nil;
				end;
				wrapyield(nil, false, false);
				scrollView:ResetPosition();
			end),
			SetApCost = function(this, ap)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Implicit", this.LabelApCost) then
					this.LabelApCost.text = invokeforbasicvalue(ap, false, System.Int32, "ToString");
				end;
			end,
			SetCount = function(this, countStr)
--if (LabelCount) LabelCount.text = cur.ToString() + "/" + max.ToString();
				if invokeexternoperator(CS.UnityEngine.Object, "op_Implicit", this.LabelCount) then
					this.LabelCount.text = countStr;
				end;
				if System.String.IsNullOrEmpty(countStr) then
					this.LabelCount.transform.parent.gameObject:SetActive(false);
				else
					this.LabelCount.transform.parent.gameObject:SetActive(true);
				end;
			end,
			GetEnemiesListByBattleGroupId = function(this, battleinfo)
				local enemies; enemies = newexternlist(System.Collections.Generic.List_EightGame.Data.Server.sd_enemy, "System.Collections.Generic.List_EightGame.Data.Server.sd_enemy", "ctor", {});
				local index; index = 0;
				while (index < battleinfo.showmonster.Count) do
					local e; e = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetDataByCls__System_Int32(typeof(EightGame.Data.Server.sd_enemy), getexterninstanceindexer(battleinfo.showmonster, nil, "get_Item", index));
					if (e ~= nil) then
						enemies:Add(e);
					end;
				index = invokeintegeroperator(2, "+", index, 1, System.Int32, System.Int32);
				end;
				return enemies;
			end,
			GetIListByIdList = function(this, T, idList)
				local ret; ret = newexternlist(System.Collections.Generic.List_T, "System.Collections.Generic.List_T", "ctor", {});
				for id in getiterator(idList) do
					local d; d = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetDataByCls__System_Int32(T, id);
					ret:Add(d);
				end;
				return ret;
			end,
			GetItemDataWithIdentifyByList = function(this, indentify, itemList)
				local tempList; tempList = newexternlist(System.Collections.Generic.List_ItemDataWhithFirstIdentify, "System.Collections.Generic.List_ItemDataWhithFirstIdentify", "ctor", {});
				local index; index = 0;
				while (index < itemList.Count) do
					local newIndentify; newIndentify = newobject(ItemDataWhithFirstIdentify, "ctor", nil, indentify, getexterninstanceindexer(itemList, nil, "get_Item", index));
					tempList:Add(newIndentify);
				index = invokeintegeroperator(2, "+", index, 1, System.Int32, System.Int32);
				end;
				return tempList;
			end,
			InitRankingList = function(this)
				if ((this._eventIdParam.eventType == se_battletype.SE_BATTLETYPE_NORMAL ) or (this._eventIdParam.eventType == se_battletype.SE_BATTLETYPE_TRIAL )) then
					if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._battleRankListCom, nil) then
						local c; c = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.GameResources):LoadAsyn(("GameAssets/Prefabs/UI/" + BaseEventBattleInfoViewCom._rankingListPath), "prefab", false);
						wrapyield(c.coroutine, false, true);
						local prefab; prefab = typeas(c.res, UnityEngine.GameObject, false);
						if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", prefab, nil) then
							Eight.Framework.EIDebuger.LogError("[NormalBattleInfoPanel] load RankingList error");
							return nil;
						end;
						local go; go = GameUtility.InstantiateGameObject(prefab, this.gameObject, "RankingListPanel", nil, nil, nil);
						this._battleRankListCom = go:GetComponent(BattleRankListUIcom);
					end;
					this._battleRankListCom:SetUp(this._eventIdParam.eventId);
				end;
				return nil;
			end),
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				LabelDesc = __cs2lua_nil_field_value,
				SpriteEnemies = __cs2lua_nil_field_value,
				_itemGrid = __cs2lua_nil_field_value,
				_enemisTable = __cs2lua_nil_field_value,
				LabelApCost = __cs2lua_nil_field_value,
				LabelCount = __cs2lua_nil_field_value,
				_eventIdParam = __cs2lua_nil_field_value,
				_cachItemoComList = __cs2lua_nil_field_value,
				_callbackBeginBattle = delegationwrap(),
				_battleRankListCom = __cs2lua_nil_field_value,
				_itemFirstModelPrefab = __cs2lua_nil_field_value,
				_distancFloat = 120.00,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIUIBehaviour, "BaseEventBattleInfoViewCom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



BaseEventBattleInfoViewCom.__define_class();
