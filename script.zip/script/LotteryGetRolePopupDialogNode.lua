require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EightGame__Logic__UIDialogNode";
require "EightGame__Logic__DialogUI";
require "Eight__Framework__EIFrameWork";
require "EightGame__Component__GameResources";
require "NGUITools";
require "LotteryGetRolePopupUICom";
require "Eight__Framework__EIEvent";
require "GameAudioSoundParam";
require "EventDelegate";

LotteryGetRolePopupDialogNode = {
	__new_object = function(...)
		return newobject(LotteryGetRolePopupDialogNode, "ctor", nil, ...);
	end,
	__define_class = function()
		local static = LotteryGetRolePopupDialogNode;

		local static_methods = {
			Open = function(role, isAlreadyHave)
				LotteryGetRolePopupDialogNode._role = role;
				LotteryGetRolePopupDialogNode._isAlreadyHave = isAlreadyHave;
				if (LotteryGetRolePopupDialogNode._lastDialogID == -1) then
					EightGame.Logic.UIDialogNode.OpenIt(LotteryGetRolePopupDialogNode, nil, (function() local __compiler_delegation_31 = (function(data) LotteryGetRolePopupDialogNode._Private_OnOpen(data); end); setdelegationkey(__compiler_delegation_31, "LotteryGetRolePopupDialogNode:_Private_OnOpen", LotteryGetRolePopupDialogNode, LotteryGetRolePopupDialogNode._Private_OnOpen); return __compiler_delegation_31; end)());
				end;
			end,
			Hide = function()
				if (LotteryGetRolePopupDialogNode._lastDialogID ~= -1) then
					EightGame.Logic.UIDialogNode.HideIt(LotteryGetRolePopupDialogNode, LotteryGetRolePopupDialogNode._lastDialogID, (function() local __compiler_delegation_40 = (function(data) LotteryGetRolePopupDialogNode._Private_OnHide(data); end); setdelegationkey(__compiler_delegation_40, "LotteryGetRolePopupDialogNode:_Private_OnHide", LotteryGetRolePopupDialogNode, LotteryGetRolePopupDialogNode._Private_OnHide); return __compiler_delegation_40; end)());
				end;
			end,
			Close = function()
				if ((LotteryGetRolePopupDialogNode._lastDialogID ~= -1) and (not EightGame.Logic.DialogUI.currentDialogUI.IsLock)) then
					EightGame.Logic.UIDialogNode.CloseIt(LotteryGetRolePopupDialogNode, LotteryGetRolePopupDialogNode._lastDialogID, (function() local __compiler_delegation_49 = (function(data) LotteryGetRolePopupDialogNode._Private_OnClose(data); end); setdelegationkey(__compiler_delegation_49, "LotteryGetRolePopupDialogNode:_Private_OnClose", LotteryGetRolePopupDialogNode, LotteryGetRolePopupDialogNode._Private_OnClose); return __compiler_delegation_49; end)());
					LotteryGetRolePopupDialogNode._lastDialogID = -1;
				end;
			end,
			_Private_OnOpen = function(data)
				LotteryGetRolePopupDialogNode._lastDialogID = typecast(data, System.Int32, false);
			end,
			_Private_OnHide = function(data)
			end,
			_Private_OnClose = function(data)
				if externdelegationcomparewithnil(false, true, "LotteryGetRolePopupDialogNode:ondismiss", LotteryGetRolePopupDialogNode, nil, "ondismiss", false) then
					LotteryGetRolePopupDialogNode.ondismiss();
					delegationset(false, true, "LotteryGetRolePopupDialogNode:ondismiss", LotteryGetRolePopupDialogNode, nil, "ondismiss", nil);
				end;
			end,
			cctor = function()
				EightGame.Logic.UIDialogNode.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				_role = __cs2lua_nil_field_value,
				_isAlreadyHave = false,
				ondismiss = delegationwrap(),
				_lastDialogID = -1,
				ASSET_PATH = "Lottery/ui_lottery_getrole_popup",
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			ctor = function(this)
				this.base.ctor(this);
				this._isReady = false;
				this:StartCoroutine(this:CreateAssets());
				return this;
			end,
			CreateAssets = function(this)
--下面是一段资源创建的示例, 请修改成你自己的//
				local coroutine; coroutine = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.GameResources):LoadAsyn("GameAssets/Prefabs/UI/Lottery/ui_lottery_getrole_popup", "prefab", false);
				wrapyield(coroutine.coroutine, false, true);
				local prefab; prefab = typeas(coroutine.res, UnityEngine.GameObject, false);
				local obj; obj = NGUITools.AddChild__UnityEngine_GameObject__UnityEngine_GameObject(NGUITools, this.dialogParent.gameObject, prefab);
				this.popup = obj:GetComponent(LotteryGetRolePopupUICom);
				this:BindUIEvents();
				this.popup:Init(LotteryGetRolePopupDialogNode._role, LotteryGetRolePopupDialogNode._isAlreadyHave);
				this.popup:StartFadeIn();
				delegationset(false, false, "LotteryGetRolePopupUICom:onCardTrunOn", this.popup, nil, "onCardTrunOn", (function()
					this:DispatchEvent(newobject(Eight.Framework.EIEvent, "ctor__System_String__Eight_Framework_EIEvent_ReturnCallBack__System_Object__System_Single", nil, "AUDIO_PLAY_SOUND", nil, newobject(GameAudioSoundParam, "ctor", nil, "sound_skilleff_reply_02"), 0.00));
				end));
				this:BindComponent__EIEntityBehaviour(this.popup);
--这里可以你自己的逻辑//
				this._isReady = true;
				return nil;
			end),
			OnEnter = function(this, data)
--在这里初始化你的gameobject脚本//
				return nil;
			end),
			OnExit = function(this)
				return nil;
			end),
			Dispose = function(this)
				LotteryGetRolePopupDialogNode._lastDialogID = -1;
				this.popup = nil;
				return this.base:Dispose();
			end,
			BindUIEvents = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.popup, nil) then
					return ;
				end;
				EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.popup.DismissBG.onClick, (function() local __compiler_delegation_136 = (function() this:OnDissmissPopup(); end); setdelegationkey(__compiler_delegation_136, "LotteryGetRolePopupDialogNode:OnDissmissPopup", this, this.OnDissmissPopup); return __compiler_delegation_136; end)());
			end,
			OnDissmissPopup = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this.popup, nil) then
					UnityEngine.Object.Destroy(this.popup.gameObject);
				end;
				LotteryGetRolePopupDialogNode.Close();
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				popup = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = {
			"System.Collections.IEnumerable",
		};

		local interface_map = {
			IEnumerable_GetEnumerator = "EINode_GetEnumerator",
		};


		return defineclass(EightGame.Logic.UIDialogNode, "LotteryGetRolePopupDialogNode", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryGetRolePopupDialogNode.__define_class();
