-- //  **********************************************************************
-- //  Copyright   2015  EIGHT Team . All rights reserved.
-- //  File     :   BaseDialogModule.cs
-- //  Author   : Breen
-- //  Created  : 2015/12/28  20:42 
-- //  Purpose  : 
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIBehaviour";

BaseDialogModule = {
	__new_object = function(...)
		return newobject(BaseDialogModule, nil, nil, ...);
	end,
	__define_class = function()
		local static = BaseDialogModule;

		local static_methods = {
			cctor = function()
				EIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			SetupParam = function(this, param)
			end,
			SetActive = function(this, enable)
				this.gameObject:SetActive(enable);
			end,
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIBehaviour, "BaseDialogModule", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



BaseDialogModule.__define_class();
