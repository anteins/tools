-- //  **********************************************************************
-- //  Copyright  2016  EIGHT Team . All rights reserved.
-- //  File     : LotteryRewards.cs
-- //  Author   : wolforce
-- //  Created  : 2016/2/26  11:45 
-- //  Purpose  : 控制奖品展示界面.
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";

LotteryRewards = {
	__new_object = function(...)
		return newobject(LotteryRewards, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotteryRewards;

		local static_methods = {
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			ClearContainer = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.container, nil) then
					return ;
				end;
				this:DestroyChildren(this.container.transform);
			end,
			DestroyChildren = function(this, trans)
				local children; children = newexternlist(System.Collections.Generic.List_UnityEngine.GameObject, "System.Collections.Generic.List_UnityEngine.GameObject", "ctor", {});
				for child in getiterator(trans) do
					children:Add(child.gameObject);
				end;
				trans:DetachChildren();
				children:ForEach((function(child) return UnityEngine.Object.Destroy(child); end));
			end,
			Start = function(this)
			end,
			Update = function(this)
			end,
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				container = __cs2lua_nil_field_value,
				dissmisBg = __cs2lua_nil_field_value,
				topBlockBg = __cs2lua_nil_field_value,
				skipBtn = __cs2lua_nil_field_value,
				rewardRareIconModel = __cs2lua_nil_field_value,
				rewardItemModel = __cs2lua_nil_field_value,
				rewardRoleModel = __cs2lua_nil_field_value,
				rewardRoleItemModel = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(UnityEngine.MonoBehaviour, "LotteryRewards", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryRewards.__define_class();
