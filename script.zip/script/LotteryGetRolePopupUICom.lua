-- //  **********************************************************************
-- //  Copyright  2015  EIGHT Team . All rights reserved.
-- //  File     : LotteryGetRolePopupUICom.cs
-- //  Author   : wolforce
-- //  Created  : 2015/7/1  11:04 
-- //  Purpose  : 
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIEntityBehaviour";
require "GameUtility";
require "Eight__Framework__EIFrameWork";
require "Eight__Framework__EIEvent";
require "GameAudioSoundParam";
require "RoleInfoUtil";
require "UITexture";
require "LogicStatic";
require "EventDelegate";

LotteryGetRolePopupUICom = {
	__new_object = function(...)
		return newobject(LotteryGetRolePopupUICom, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotteryGetRolePopupUICom;

		local static_methods = {
			cctor = function()
				EIEntityBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				_rolePortraitPath = "GameAssets/Textures/Icon/icon_hero_portrait_",
				_defaultIcon = "000",
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			StartFadeIn = function(this)
				this.DismissBG.gameObject:SetActive(false);
				this:StopFadeIn();
				this._fadeInCoroutine = this:FadeIn();
				this:StartCoroutine(this._fadeInCoroutine);
			end,
			StopFadeIn = function(this)
				if (this._fadeInCoroutine ~= nil) then
					this:StopCoroutine(this._fadeInCoroutine);
				end;
			end,
			FadeIn = function(this)
				this:ResetAll();
				this.taWhiteBg.gameObject:SetActive(true);
				this.taWhiteBg:PlayForward();
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, this.taWhiteBg.duration), false, true);
				this.TextureMainBg.gameObject:SetActive(true);
				this.SpriteBlackBg.gameObject:SetActive(true);
				this.taWhiteBg:PlayReverse();
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, (this.taWhiteBg.duration + 0.10)), false, true);
				this.TextureRoleWhite.gameObject:SetActive(true);
				this.PanelRole.gameObject:SetActive(true);
--必须和影子同时出现，否则会有BUG.
				this.PanelRole.alpha = 0.01;
				this.tsRoleBG:PlayForward();
				if externdelegationcomparewithnil(false, false, "LotteryGetRolePopupUICom:onCardTrunOn", this, nil, "onCardTrunOn", false) then
					this.onCardTrunOn();
				end;
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, this.tsRoleBG.duration), false, true);
				this.taRole:PlayForward();
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, this.taRole.duration), false, true);
				this.DefinitionGroup.gameObject:SetActive(true);
				this.DefinitionGroup.alpha = 0.01;
				this.taRoleDefinition:PlayForward();
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, this.taRoleDefinition.duration), false, true);
--播放获得英雄时的音效
				if (this._cache_role ~= nil) then
					local skin; skin = GameUtility.GetRoleSkin(this._cache_role.skin, this._cache_role.id);
					local bgm; bgm = skin.sound_get;
					Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIEvent, "ctor__System_String__Eight_Framework_EIEvent_ReturnCallBack__System_Object__System_Single", nil, "AUDIO_PLAY_SOUND", nil, newobject(GameAudioSoundParam, "ctor", nil, bgm), 0.00));
				end;
				this.GiftGroup.gameObject:SetActive(true);
				this.GiftGroup.alpha = 0.01;
				this.taGift:PlayForward();
				this.GroupNewRole:SetActive((not this._isAlreadyHave));
				this.GroupHaveRole:SetActive(this._isAlreadyHave);
				this.taBlackBg:PlayForward();
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, this.taBlackBg.duration), false, true);
				this.DismissBG.gameObject:SetActive(true);
			end),
			ResetAll = function(this)
				this.SpriteWhiteBg.gameObject:SetActive(false);
				this.TextureMainBg.gameObject:SetActive(false);
				this.SpriteBlackBg.gameObject:SetActive(false);
				this.TextureRoleWhite.gameObject:SetActive(false);
				this.PanelRole.gameObject:SetActive(false);
				this.DefinitionGroup.gameObject:SetActive(false);
				this.GiftGroup.gameObject:SetActive(false);
				this.SpriteWhiteBg.alpha = 0.00;
--texAvatar.alpha = 0.001f;
--taWhiteBg.ResetToBeginning();
				this.taRole:ResetToBeginning();
				this.tsRoleBG:ResetToBeginning();
				this.taBlackBg:ResetToBeginning();
				this.taRoleDefinition:ResetToBeginning();
				this.taGift:ResetToBeginning();
				this.GroupHaveRole:SetActive(false);
				this.GroupNewRole:SetActive(false);
			end,
			Init = function(this, role, isAlreadyHave)
				this._cache_role = role;
				this:SetRole(role.icon);
				this:SetRoleBg(role.element);
				this:SetJob(role.job);
				this:SetElement(role.element);
				this:SetDefinitionIcon(role.definition);
				this:SetDefinitionDesc(role.definidesc);
				this:SetStar(role.star);
				this:SetName(role.rolename, role.rank);
				this:SetSpriteRare(role.rolelabeltype);
				this:SetGift(role.job, role.talentsskill);
				this._isAlreadyHave = isAlreadyHave;
			end,
			SetRole = function(this, icon)
				do
					this:StartCoroutine(RoleInfoUtil.LoadAsynImage(("GameAssets/Textures/Icon/icon_hero_portrait_" + icon), "png", "GameAssets/Textures/Icon/icon_hero_portrait_000", "png", (function(tex)
						this.TextureRole.mainTexture = tex;
					end)));
				end;
			end,
			SetRoleBg = function(this, ele)
				local eleId; eleId = typecast(ele, System.Int32, false);
				Eight.Framework.EIFrameWork.StartCoroutine(RoleInfoUtil.LoadAsynImage(("GameAssets/Textures/Role/avatar_get_role_bg_" + eleId), "png", "GameAssets/Textures/Role/avatar_get_role_bg_1", "png", (function(tex)
					this.tsRoleBG:GetComponent(UITexture).mainTexture = tex;
					this.TextureRoleBg.mainTexture = tex;
				end)), false);
			end,
			SetName = function(this, roleName, quality)
				this.LabelName.text = roleName;
				this.LabelName.color = RoleInfoUtil.GetQualityColor(quality);
			end,
			SetSpriteRare = function(this, rareType)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.SpriteRare, nil) then
					return ;
				end;
				this.SpriteRare.spriteName = System.String.Format("role_rare_{0}", typecast(rareType, System.Int32, false));
			end,
			SetStar = function(this, starlv)
				starlv = UnityEngine.Mathf.Clamp(starlv, 0, this.starList.Length);
				for go in getiterator(this.starList) do
					go:SetActive(false);
				end;
				local i; i = 0;
				while (i < starlv) do
					this.starList[i + 1]:SetActive(true);
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
				this.starGrid:Reposition();
			end,
			SetJob = function(this, job)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.SpriteJob, nil) then
					return ;
				end;
				this.SpriteJob.spriteName = System.String.Format("icon_job_black_{0}", typecast(job, System.Int32, false));
			end,
			SetElement = function(this, ele)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.SpriteElement, nil) then
					return ;
				end;
				this.SpriteElement.spriteName = System.String.Format("element_big_{0}", typecast(ele, System.Int32, false));
			end,
			SetDefinitionIcon = function(this, definition)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.SpriteDefinition, nil) then
					return ;
				end;
				this.SpriteDefinition.spriteName = System.String.Format("text_role_definition_{0}", typecast(definition, System.Int32, false));
			end,
			SetDefinitionDesc = function(this, desc)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.LabelDefiniDesc, nil) then
					return ;
				end;
				this.LabelDefiniDesc.text = desc;
			end,
			SetGift = function(this, job, skillId)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.SkillGift, nil) then
					return ;
				end;
				local skill; skill = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_skill_skill), skillId);
				local icon; icon = System.String.Format("icon_gift_{0}", typecast(job, System.Int32, false));
				this.SkillGift:Reset();
				this.SkillGift:SetSkillIcon(icon, 1, 1, true);
				this.LabelSkillName.text = System.String.Format("[FACB93]天赋：[-]{0}", skill.name);
				this.LabelSkillDesc.text = GameUtility.Unescape(skill.desc);
			end,
			SetSkillSub = function(this, skillCom, skillId, job, curExp, curRank, openRank)
				local skill; skill = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_skill_skill), skillId);
				if (skill == nil) then
					skillCom.gameObject:SetActive(false);
					return ;
				end;
				skillCom:SetSkillIcon(skill.icon, curRank, openRank, true);
				skillCom:SetSkillName(skill.name, true);
			end,
			Start = function(this)
				EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.TestBtn.onClick, (function() local __compiler_delegation_296 = (function() this:StartFadeIn(); end); setdelegationkey(__compiler_delegation_296, "LotteryGetRolePopupUICom:StartFadeIn", this, this.StartFadeIn); return __compiler_delegation_296; end)());
			end,
			Update = function(this)
			end,
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				TestBtn = __cs2lua_nil_field_value,
				SpriteWhiteBg = __cs2lua_nil_field_value,
				TextureMainBg = __cs2lua_nil_field_value,
				SpriteBlackBg = __cs2lua_nil_field_value,
				TextureRoleWhite = __cs2lua_nil_field_value,
				TextureRole = __cs2lua_nil_field_value,
				TextureRoleBg = __cs2lua_nil_field_value,
				PanelRole = __cs2lua_nil_field_value,
				DefinitionGroup = __cs2lua_nil_field_value,
				GiftGroup = __cs2lua_nil_field_value,
				taWhiteBg = __cs2lua_nil_field_value,
				taBlackBg = __cs2lua_nil_field_value,
				taRole = __cs2lua_nil_field_value,
				tsRoleBG = __cs2lua_nil_field_value,
				taRoleDefinition = __cs2lua_nil_field_value,
				taGift = __cs2lua_nil_field_value,
				_isAlreadyHave = false,
				DismissBG = __cs2lua_nil_field_value,
				SpriteJob = __cs2lua_nil_field_value,
				SpriteElement = __cs2lua_nil_field_value,
				SpriteDefinition = __cs2lua_nil_field_value,
				LabelDefiniDesc = __cs2lua_nil_field_value,
				LabelName = __cs2lua_nil_field_value,
				SpriteRare = __cs2lua_nil_field_value,
				starGrid = __cs2lua_nil_field_value,
				starList = __cs2lua_nil_field_value,
				SkillGift = __cs2lua_nil_field_value,
				LabelSkillName = __cs2lua_nil_field_value,
				LabelSkillDesc = __cs2lua_nil_field_value,
				GroupNewRole = __cs2lua_nil_field_value,
				GroupHaveRole = __cs2lua_nil_field_value,
				onCardTrunOn = delegationwrap(),
				_fadeInCoroutine = __cs2lua_nil_field_value,
				_cache_role = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIEntityBehaviour, "LotteryGetRolePopupUICom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryGetRolePopupUICom.__define_class();
