-- //  **********************************************************************
-- //  Copyright  2015  EIGHT Team . All rights reserved.
-- //  File     : LongPressButton.cs
-- //  Author   : wolforce
-- //  Created  : 2015/7/16  11:40 
-- //  Purpose  : 长按按钮，实现按钮的单击和长按连续触发功能.
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIBehaviour";

LongPressButton = {
	__new_object = function(...)
		return newobject(LongPressButton, nil, nil, ...);
	end,
	__define_class = function()
		local static = LongPressButton;

		local static_methods = {
			cctor = function()
				EIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			OnPress = function(this, isPress)
				if (this._pressCoroutine ~= nil) then
					this:StopCoroutine(this._pressCoroutine);
				end;
				if isPress then
--计时进入长按状态.
					this._pressCoroutine = this:TriggerLongPressMode();
					this:StartCoroutine(this._pressCoroutine);
				else
--退出长按状态.
					if (this._isEnteredPressMode and externdelegationcomparewithnil(false, false, "LongPressButton:onExitLongPress", this, nil, "onExitLongPress", false)) then
						this.onExitLongPress();
					end;
--触发单击.
					if ((not this._isEnteredPressMode) and externdelegationcomparewithnil(false, false, "LongPressButton:onClick", this, nil, "onClick", false)) then
						this.onClick();
					end;
				end;
			end,
			TriggerLongPressMode = function(this)
				this._isEnteredPressMode = false;
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, this.pressEnterTime), false, true);
				this._isEnteredPressMode = true;
				if externdelegationcomparewithnil(false, false, "LongPressButton:onEnterLongPress", this, nil, "onEnterLongPress", false) then
					this.onEnterLongPress();
				end;
				while true do
					wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, this.triggerGapTime), false, true);
					if externdelegationcomparewithnil(false, false, "LongPressButton:onTurboTrigger", this, nil, "onTurboTrigger", false) then
						this.onTurboTrigger();
					end;
				end;
			end),
			Start = function(this)
			end,
			Update = function(this)
			end,
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				pressEnterTime = 1.00,
				triggerGapTime = 0.10,
				onClick = delegationwrap(),
				onEnterLongPress = delegationwrap(),
				onExitLongPress = delegationwrap(),
				onTurboTrigger = delegationwrap(),
				_pressCoroutine = __cs2lua_nil_field_value,
				_isEnteredPressMode = false,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIBehaviour, "LongPressButton", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LongPressButton.__define_class();
