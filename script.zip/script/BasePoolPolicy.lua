require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "ListExtension";
require "AssetManager";

BasePoolPolicy = {
	__new_object = function(...)
		return newobject(BasePoolPolicy, nil, nil, ...);
	end,
	__define_class = function()
		local static = BasePoolPolicy;

		local static_methods = {
			SendDespawnMessage = function(instance)
--if(instance is GameObject)
--{
--	(instance as GameObject).SendMessage("OnDespawn", SendMessageOptions.DontRequireReceiver);
--}
			end,
			SendSpawnMessage = function(instance)
--if(instance is GameObject)
--{
--	(instance as GameObject).SendMessage("OnSpawn", SendMessageOptions.DontRequireReceiver);
--}
			end,
			Reparent = function(instance, parent)
				if typeis(instance, UnityEngine.GameObject, false) then
					( typeas(instance, UnityEngine.GameObject, false) ).transform:SetParent(parent, false);
				end;
			end,
			SetActive = function(instance, active)
				if typeis(instance, UnityEngine.GameObject, false) then
					( typeas(instance, UnityEngine.GameObject, false) ):SetActive(active);
				end;
			end,
			Destroy__UnityEngine_Object = function(obj)
				UnityEngine.Object.Destroy(obj);
			end,
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				DestroyDelayTime = 5.00,
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			get_BaseMaximum = function(this)
				return this._baseMaximum;
			end,
			set_BaseMaximum = function(this, value)
				if (this._baseMaximum ~= value) then
					local min; min = invokeintegeroperator(3, "-", invokeintegeroperator(2, "+", this._pool.Count, this._spawned.Count, System.Int32, System.Int32), this._extendedSpace, System.Int32, System.Int32);
					if (value < min) then
						value = min;
					end;
					this._baseMaximum = value;
				end;
			end,
			get_ExtendedSpace = function(this)
				return this._extendedSpace;
			end,
			set_ExtendedSpace = function(this, value)
				if (this._extendedSpace ~= value) then
					local min; min = invokeintegeroperator(3, "-", invokeintegeroperator(2, "+", this._pool.Count, this._spawned.Count, System.Int32, System.Int32), this._baseMaximum, System.Int32, System.Int32);
					if (value < min) then
						value = min;
					end;
					this._extendedSpace = value;
				end;
			end,
			get_Flags = function(this)
				return this._flags;
			end,
			Update = function(this)
				if (( invokeintegeroperator(7, "&", this._flags, 1, AssetMemoryFlags, AssetMemoryFlags) ) ~= 0) then
					this._startTime = 0.00;
					return ;
				end;
				if (( invokeintegeroperator(7, "&", this._flags, 2, AssetMemoryFlags, AssetMemoryFlags) ) ~= 0) then
					if (this._startTime > 0.00) then
						if (( (UnityEngine.Time.realtimeSinceStartup - this._startTime) ) >= 5.00) then
							this._flags = invokeintegeroperator(7, "&", this._flags, -3, AssetMemoryFlags, AssetMemoryFlags);
							this._startTime = 0.00;
						end;
					else
						this._startTime = UnityEngine.Time.realtimeSinceStartup;
					end;
				end;
			end,
			IsNeedDestroy = function(this)
				return ((this._spawned.Count == 0) and (this._flags == 0));
			end,
			Destroy = function(this)
--删除//
				for obj in getiterator(this._pool) do
					UnityEngine.Object.Destroy(obj);
				end;
				for obj in getiterator(this._spawned) do
					UnityEngine.Debug.LogError(("未归还的对象被强制删除:" + obj.name));
					UnityEngine.Object.Destroy(obj);
				end;
--清除引用//
				this._pool:Clear();
				this._spawned:Clear();
--清除prefab//
				do
					UnityEngine.Resources.UnloadAsset(this._prefab);
				end;
				do
					this._prefab = nil;
				end;
			end,
			IsReadWriteEnabled = function(this)
				return true;
			end,
			Init = function(this, prefab_)
				this._prefab = prefab_;
				this._flags = 1;
				this:OnInit();
			end,
			OnInit = function(this)
				this._baseMaximum = 10;
				this._extendedSpace = 5;
			end,
			Spawn = function(this)
--池中有未使用的//
				if (this._pool.Count > 0) then
					local pooled; pooled = ListExtension.Dequeue(this._pool, typeof(UnityEngine.Object));
					this:SpawnInstance(pooled);
					return pooled;
				end;
--池子已经空了, 需要判断是否扩充//
--获得总共clone了多少对象//
--池子已经空了, 需要判断是否扩充//
--获得总共clone了多少对象//
				local totalCount; totalCount = invokeintegeroperator(2, "+", this._pool.Count, this._spawned.Count, System.Int32, System.Int32);
--额外//
				local extraLimitedMax; extraLimitedMax = invokeintegeroperator(2, "+", this._baseMaximum, this._extendedSpace, System.Int32, System.Int32);
--如果所开辟的总数已经到达了[额外最大上限], 应该返回null//
				if (totalCount >= extraLimitedMax) then
					return nil;
				end;
--如果未超过最大上限, 就开辟新的对象出来//
				local instantiated; instantiated = this:Instantiate();
				this:SpawnInstance(instantiated);
				return instantiated;
			end,
			Despawn = function(this, instance)
--要放回的对象 之前就不属于这个缓冲池//
				if (not this._spawned:Remove(instance)) then
					return ;
				end;
--回收对象//
				BasePoolPolicy.SendDespawnMessage(instance);
--隐藏对象//
				BasePoolPolicy.SetActive(instance, false);
-- 放回池子 //
				ListExtension.Enqueue(this._pool, typeof(UnityEngine.Object), instance);
--重新Reparent//
				BasePoolPolicy.Reparent(instance, AssetManager.Instance.PoolParent);
			end,
			ManualRelease = function(this)
				this._flags = invokeintegeroperator(7, "&", this._flags, -2, AssetMemoryFlags, AssetMemoryFlags);
			end,
			Instantiate = function(this)
				local instance; instance = UnityEngine.Object.Instantiate(this._prefab);
				instance.name = this._prefab.name;
				BasePoolPolicy.Reparent(instance, AssetManager.Instance.PoolParent);
				return instance;
			end,
			SpawnInstance = function(this, instance)
--把克隆对象放到spawned中//
				ListExtension.Enqueue(this._spawned, typeof(UnityEngine.Object), instance);
--发送消息//
--SendSpawnMessage( instance );
			end,
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				_prefab = __cs2lua_nil_field_value,
				_pool = newexternlist(System.Collections.Generic.List_UnityEngine.Object, "System.Collections.Generic.List_UnityEngine.Object", "ctor", {}),
				_spawned = newexternlist(System.Collections.Generic.List_UnityEngine.Object, "System.Collections.Generic.List_UnityEngine.Object", "ctor", {}),
				_baseMaximum = 0,
				_extendedSpace = 0,
				_flags = 0,
				_startTime = 0.00,
			};
			return instance_fields;
		end;

		local instance_props = {
			BaseMaximum = {
				get = instance_methods.get_BaseMaximum,
				set = instance_methods.set_BaseMaximum,
			},
			ExtendedSpace = {
				get = instance_methods.get_ExtendedSpace,
				set = instance_methods.set_ExtendedSpace,
			},
			Flags = {
				get = instance_methods.get_Flags,
			},
		};

		local instance_events = nil;
		local interfaces = {
			"IPoolPolicy",
		};

		local interface_map = {
			IPoolPolicy_Init = "Init",
			IPoolPolicy_Spawn = "Spawn",
			IPoolPolicy_Despawn = "Despawn",
			IPoolPolicy_Update = "Update",
			IPoolPolicy_IsNeedDestroy = "IsNeedDestroy",
			IPoolPolicy_Destroy = "Destroy",
			IPoolPolicy_IsReadWriteEnabled = "IsReadWriteEnabled",
			IPoolPolicy_ManualRelease = "ManualRelease",
		};


		return defineclass(System.Object, "BasePoolPolicy", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



BasePoolPolicy.__define_class();
