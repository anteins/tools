require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIUIBehaviour";
require "ChatMsgManager";
require "LogicStatic";

ChatChannelCom = {
	__new_object = function(...)
		return newobject(ChatChannelCom, nil, nil, ...);
	end,
	__define_class = function()
		local static = ChatChannelCom;

		local static_methods = {
			cctor = function()
				EIUIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				_oldCom = __cs2lua_nil_field_value,
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			SetData = function(this, chatenum, callbaclSelect)
				this._chatChannelEnum = chatenum;
				delegationset(false, false, "ChatChannelCom:_callbackSelect", this, nil, "_callbackSelect", callbaclSelect);
				this:SetBgSprite(false);
				this:SetUnreadSpriteActive(false);
				local __compiler_switch_29 = this._chatChannelEnum;
				if __compiler_switch_29 == se_chattype.SE_CHATTYPE_CHATWORLD then
					this._defaultTex = "世界频道";
				elseif __compiler_switch_29 == se_chattype.SE_CHATTYPE_CHATPRIVATE then
					this:SetUnreadSpriteActive((ChatMsgManager.Instance:GetUnReadPrivateMsgs().Count > 0));
					this._defaultTex = "好友聊天";
				elseif __compiler_switch_29 == se_chattype.SE_CHATTYPE_CHATSYSTEM then
					this._defaultTex = "系统消息";
				elseif __compiler_switch_29 == se_chattype.SE_CHATTYPE_CHATUNION then
					this._defaultTex = "冒险团聊天";
				end;
				this:SetChannelLbl(this._defaultTex);
			end,
			OnClick = function(this)
				if externdelegationcomparewithnil(false, false, "ChatChannelCom:_callbackSelect", this, nil, "_callbackSelect", false) then
					this._callbackSelect(this);
				end;
			end,
			SetBgSprite = function(this, b)
				if (invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._btn, nil) or invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._channelLbl, nil)) then
					return ;
				end;
				local colorStr; colorStr = System.String.Empty;
				if (this._chatChannelEnum == se_chattype.SE_CHATTYPE_CHATUNION ) then
					local notify; notify = LogicStatic.Get__System_Predicate_T(typeof(EightGame.Data.Server.ClubDataNotify), nil);
					if (notify == nil) then
						this._bgSprite.spriteName = "b13";
						this._defaultColr = "[B7B3B1]";
					else
						local y; y = condexp(b, true, 44, true, 37);
						this._bgSprite:SetDimensions(this._bgSprite.width, y);
						this._bgSprite.transform.localPosition = condexp(b, false, (function() return newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, 0, 3.00, 0); end), false, (function() return UnityEngine.Vector3.zero; end));
						this._bgSprite.spriteName = condexp(b, true, "b11", true, "b12");
						this._defaultColr = condexp(b, true, "[745037]", true, "[DFC9A7]");
					end;
				else
					local y; y = condexp(b, true, 44, true, 37);
					this._bgSprite:SetDimensions(this._bgSprite.width, y);
					this._bgSprite.transform.localPosition = condexp(b, false, (function() return newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, 0, 3.00, 0); end), false, (function() return UnityEngine.Vector3.zero; end));
					this._bgSprite.spriteName = condexp(b, true, "b11", true, "b12");
					this._defaultColr = condexp(b, true, "[745037]", true, "[DFC9A7]");
				end;
				this:SetChannelLbl(this._defaultTex);
			end,
			SetChannelLbl = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._channelLbl, nil) then
					return ;
				end;
				this._defaultTex = str;
				this._channelLbl.text = System.String.Format("{0}{1}", this._defaultColr, str);
			end,
			SetUnreadSpriteActive = function(this, b)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._unreadSprite, nil) then
					return ;
				end;
				this._unreadSprite.gameObject:SetActive(b);
			end,
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				_channelLbl = __cs2lua_nil_field_value,
				_bgSprite = __cs2lua_nil_field_value,
				_btn = __cs2lua_nil_field_value,
				_unreadSprite = __cs2lua_nil_field_value,
				_chatChannelEnum = 1,
				_callbackSelect = delegationwrap(),
				_defaultTex = System.String.Empty,
				_defaultColr = System.String.Empty,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIUIBehaviour, "ChatChannelCom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



ChatChannelCom.__define_class();
