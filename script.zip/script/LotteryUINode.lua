-- //  **********************************************************************
-- //  Copyright  2015  EIGHT Team . All rights reserved.
-- //  File     : LotteryUINode.cs
-- //  Author   : wolforce
-- //  Created  : 2015/5/11  17:37 
-- //  Purpose  : 
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EightGame__Logic__BaseSubHeaderEvent";
require "EightGame__Component__NetworkUtils";
require "Eight__Framework__EIFrameWork";
require "EightGame__Component__GameResources";
require "GameUtility";
require "EightGame__Logic__LotteryUICom";
require "NGUITools";
require "LotterySceneCom";
require "LotterySceneEventListener";
require "Eight__Framework__EIStringEvent";
require "LogicStatic";
require "EightGame__Logic__CommonExplainTipDialogNode";
require "AlarmManager";
require "EventDelegate";
require "GuideManager";
require "UIRoot";
require "Eight__Framework__EIEvent";
require "EightGame__Component__NetworkClient";
require "EightGame__Component__Statistical";
require "LotteryCheckAvailable";
require "LotteryUtil";
require "LobbyUINode";
require "GlobalCamera";
require "ItemModelCom";
require "ItemModelUtility";
require "LotteryRareIconCom";
require "RoleModelCom";
require "LotteryGetRolePopupDialogNode";
require "RoleInfoUtil";
require "TweenAlpha";
require "AlarmManagerHelper";
require "EightGame__Logic__TipStruct";

LotteryUINode = {
	__new_object = function(...)
		return newobject(LotteryUINode, "ctor", nil, ...);
	end,
	__define_class = function()
		local static = LotteryUINode;

		local static_methods = {
			cctor = function()
				EightGame.Logic.BaseSubHeaderEvent.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				_lotteryScenePath = "CatchCard2/CatchCard2",
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			ctor = function(this)
				this.base.ctor__System_String(this, "LotteryUINode");
				this._isReady = false;
				this:StartCoroutine(this:CreateUI((function()
					this._isReady = true;
					this:Init();
					this:BindUIEvents();
				end)));
--监听抽奖倒计时数据更新事件
				this:AddEventListener(EightGame.Component.NetworkUtils.GetSerDataUpdateEventType(typeof(EightGame.Data.Server.LotterySerData)), (function() local __compiler_delegation_42 = (function(response) this:OnLotteryDataUpdate(response); end); setdelegationkey(__compiler_delegation_42, "LotteryUINode:OnLotteryDataUpdate", this, this.OnLotteryDataUpdate); return __compiler_delegation_42; end)());
				this:AddEventListener(EightGame.Component.NetworkUtils.GetSerDataUpdateEventType(typeof(EightGame.Data.Server.PlayerSerData)), (function() local __compiler_delegation_43 = (function(e) this:OnPlayerDataUpdate(e); end); setdelegationkey(__compiler_delegation_43, "LotteryUINode:OnPlayerDataUpdate", this, this.OnPlayerDataUpdate); return __compiler_delegation_43; end)());
				return this;
			end,
			CreateUI = function(this, callback)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._com, nil) then
					local coroutine; coroutine = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.GameResources):LoadAsyn(System.String.Format("{0}{1}", "GameAssets/Prefabs/UI/", this._UIPath), "prefab", false);
					wrapyield(coroutine.coroutine, false, true);
					local prefab; prefab = typeas(coroutine.res, UnityEngine.GameObject, false);
					if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", prefab, nil) then
						Eight.Framework.EIDebuger.Log(System.String.Format(" load { 0 } error , please check", this._UIPath));
						return nil;
					end;
					local go; go = GameUtility.InstantiateGameObject(prefab, nil, "LotteryUI", nil, nil, nil);
					this._com = go:GetComponent(EightGame.Logic.LotteryUICom);
					if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._com, nil) then
						Eight.Framework.EIDebuger.Log(System.String.Format("{0} is null ,please check {0} Prefab", EightGame.Logic.LotteryUICom));
						return nil;
					end;
				end;
--yield return StartCoroutine(LoadLotterySceneCom());
				this:BindComponent__EIEntityBehaviour(this._com);
				if externdelegationcomparewithnil(false, false, "LotteryUINode:callback", callback, nil, nil, false) then
					callback();
				end;
			end),
			LoadLotterySceneCom = function(this, callback)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._lotterySceneCom, nil) then
					local path; path = LotteryUINode._lotteryScenePath;
					local coroutine; coroutine = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.GameResources):LoadAsyn(System.String.Format("{0}{1}", "BaseAssets/Prefabs/Others/", path), "prefab", false);
					wrapyield(coroutine.coroutine, false, true);
					local prefab; prefab = typeas(coroutine.res, UnityEngine.GameObject, false);
					if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", prefab, nil) then
						Eight.Framework.EIDebuger.LogError(System.String.Format("[{0}] load {1} error", LotteryUINode, path));
						return nil;
					end;
					local go; go = GameUtility.InstantiateGameObject(prefab, nil, "LotteryScene", nil, nil, nil);
					this._lotterySceneCom = NGUITools.AddMissingComponent(go, LotterySceneCom);
					this._lotterySceneCom.animator = go:GetComponent(typeof(UnityEngine.Animator));
					this._lotterySceneCom.fxCamera = go.transform:Find("Main Camera"):GetComponent(typeof(UnityEngine.Camera));
					if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._lotterySceneCom, nil) then
						Eight.Framework.EIDebuger.LogError("[LotteryUINode] can\'t get LotterySceneCom");
						return nil;
					end;
					delegationset(false, false, "LotterySceneEventListener:onAniMotion", this._lotterySceneCom:GetComponent(LotterySceneEventListener), nil, "onAniMotion", (function() local __compiler_delegation_94 = (function(e) this:OnAniMotion(e); end); setdelegationkey(__compiler_delegation_94, "LotteryUINode:OnAniMotion", this, this.OnAniMotion); return __compiler_delegation_94; end)());
				end;
				wrapyield(nil, false, false);
				this._lotterySceneCom.gameObject:SetActive(this._com.gameObject.activeInHierarchy);
				if externdelegationcomparewithnil(false, false, "LotteryUINode:callback", callback, nil, nil, false) then
					callback();
				end;
			end),
			OnEnter = function(this, data)
				this:DispatchEvent(newobject(Eight.Framework.EIStringEvent, "ctor__System_String__System_String", nil, "AUDIO_PLAY_MUSIC", "music_situation_hope"));
--发送倒计时更新请求.
--RequestLotteryUpdate();
--重置页面位置.
				this:ResetPagePosition();
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this._com, nil) then
					this:UpdateUI();
				end;
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this._lotterySceneCom, nil) then
					this._lotterySceneCom.gameObject:SetActive(true);
				end;
				this:SetSubHeaderBgUI(false);
				this:SetSubHeaderCloseEvent((function() local __compiler_delegation_122 = (function() this:OnClickState(); end); setdelegationkey(__compiler_delegation_122, "LotteryUINode:OnClickState", this, this.OnClickState); return __compiler_delegation_122; end)());
				this:SetSubHeaderPopViewWhenClose(false);
				this:SetSubHeaderCloseBtnLbl("说明");
				return this.base:OnEnter(data);
			end,
			OnClickState = function(this)
				local play_lottery_tip; play_lottery_tip = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_playtips), 14);
				local tip; tip = invokeforbasicvalue(play_lottery_tip.desc, false, System.String, "Replace", "\\n", "\n");
				EightGame.Logic.CommonExplainTipDialogNode.Open("召唤之间说明", tip);
			end,
			Dispose = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this._lotterySceneCom, nil) then
					UnityEngine.Object.Destroy(this._lotterySceneCom.gameObject);
				end;
				this._lotterySceneCom = nil;
				this._com = nil;
				return this.base:Dispose();
			end,
			OnExit = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this._lotterySceneCom, nil) then
					this._lotterySceneCom.gameObject:SetActive(false);
				end;
				return this.base:OnExit();
			end,
			get_Title = function(this)
				return "召唤之间";
			end,
			Init = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._com, nil) then
					return ;
				end;
				local curTime; curTime = AlarmManager.Instance:currentTimeMillis();
				local sdList; sdList = LogicStatic.GetList(typeof(EightGame.Data.Server.sd_conscribe), (function(x) return this:isDuringOpenTime(curTime, x); end));
--分页排序.
				local sdListSorted; sdListSorted = newexternlist(System.Collections.Generic.List_EightGame.Data.Server.sd_conscribe, "System.Collections.Generic.List_EightGame.Data.Server.sd_conscribe", "ctor", {}, sdList:ToArray());
				sdListSorted:Sort((function(x, y)
					if (x.page >= y.page) then
						return 1;
					else
						return -1;
					end;
				end));
				this._com:Init(sdListSorted);
			end,
			UpdateUI = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._com, nil) then
					return ;
				end;
				local player; player = LogicStatic.Get__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
				local lotteryList; lotteryList = LogicStatic.GetList(typeof(EightGame.Data.Server.LotterySerData), nil);
				this._com:UpdateUI(lotteryList, player);
			end,
			BindUIEvents = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._com, nil) then
					return ;
				end;
				this._com:BindLotteryBtnEvent();
				delegationadd(false, false, "EightGame.Logic.LotteryUICom:onOneBtnClick", this._com, nil, "onOneBtnClick", (function() local __compiler_delegation_193 = (function(staticId) this:OnOneBtnClick(staticId); end); setdelegationkey(__compiler_delegation_193, "LotteryUINode:OnOneBtnClick", this, this.OnOneBtnClick); return __compiler_delegation_193; end)());
				delegationadd(false, false, "EightGame.Logic.LotteryUICom:onOneBtnDiableClick", this._com, nil, "onOneBtnDiableClick", (function() local __compiler_delegation_194 = (function(staticId) this:OnOneBtnDisaleClick(staticId); end); setdelegationkey(__compiler_delegation_194, "LotteryUINode:OnOneBtnDisaleClick", this, this.OnOneBtnDisaleClick); return __compiler_delegation_194; end)());
				delegationadd(false, false, "EightGame.Logic.LotteryUICom:onTenBtnClick", this._com, nil, "onTenBtnClick", (function() local __compiler_delegation_196 = (function(staticId) this:OnTenBtnClick(staticId); end); setdelegationkey(__compiler_delegation_196, "LotteryUINode:OnTenBtnClick", this, this.OnTenBtnClick); return __compiler_delegation_196; end)());
				delegationadd(false, false, "EightGame.Logic.LotteryUICom:onTenBtnDiableClick", this._com, nil, "onTenBtnDiableClick", (function() local __compiler_delegation_197 = (function(staticId) this:OnTenBtnDisaleClick(staticId); end); setdelegationkey(__compiler_delegation_197, "LotteryUINode:OnTenBtnDisaleClick", this, this.OnTenBtnDisaleClick); return __compiler_delegation_197; end)());
				delegationadd(false, false, "EightGame.Logic.SwipeEventHandler:onSwipe", this._com.ControllerCom.SwipeEventHandleBg, nil, "onSwipe", (function() local __compiler_delegation_199 = (function(dir) this:OnSwipeHandler(dir); end); setdelegationkey(__compiler_delegation_199, "LotteryUINode:OnSwipeHandler", this, this.OnSwipeHandler); return __compiler_delegation_199; end)());
				EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this._com.ControllerCom.LeftBtn.onClick, (function() local __compiler_delegation_200 = (function() this:SwipeRight(); end); setdelegationkey(__compiler_delegation_200, "LotteryUINode:SwipeRight", this, this.SwipeRight); return __compiler_delegation_200; end)());
				EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this._com.ControllerCom.RightBtn.onClick, (function() local __compiler_delegation_201 = (function() this:SwipeLeft(); end); setdelegationkey(__compiler_delegation_201, "LotteryUINode:SwipeLeft", this, this.SwipeLeft); return __compiler_delegation_201; end)());
				EventDelegate.Set__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this._com.RewardsCom.dissmisBg.onClick, (function()
					this:HideSummonUI();
--强制插入引导.
					if GuideManager.Instance:IsRunning() then
						this.ViewParent:CheckGuide();
					end;
				end));
				EventDelegate.Set__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this._com.RewardsCom.skipBtn.onClick, (function()
					if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this._lotterySceneCom.animator, nil) then
						this._com.RewardsCom.skipBtn.gameObject:SetActive(false);
						this._lotterySceneCom.animator:SetTrigger("skip");
					end;
				end));
--监听滚动列表的下标变化.
				delegationset(false, false, "LotteryPagesCom:OnSelectPage", this._com.PagesCom, nil, "OnSelectPage", (function(index)
					this._pageIndex = index;
					this._com.DotsCom:SetDotIndex(index);
					this._com.DotsCom:UpdateDotNotice();
					this._com.PagesCom:SetPageInfoIndex(index);
				end));
			end,
			GetRealScreenSize = function(this)
				local width; width = 0;
				local height; height = 0;
				local root; root = UnityEngine.Object.FindObjectOfType(UIRoot);
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", root, nil) then
					local s; s = (typecast(root.activeHeight, System.Single, false) / UnityEngine.Screen.height);
					height = UnityEngine.Mathf.CeilToInt((UnityEngine.Screen.height * s));
					width = UnityEngine.Mathf.CeilToInt((UnityEngine.Screen.width * s));
				end;
				return wraparray{width, height};
			end,
			SwipeRight = function(this)
				local callback; callback = delegationwrap(this._com.ControllerCom.SwipeEventHandleBg.onSwipe);
				if delegationcomparewithnil(false, false, "LotteryUINode:callback", callback, nil, nil, false) then
					callback(1);
				end;
			end,
			SwipeLeft = function(this)
				local callback; callback = delegationwrap(this._com.ControllerCom.SwipeEventHandleBg.onSwipe);
				if delegationcomparewithnil(false, false, "LotteryUINode:callback", callback, nil, nil, false) then
					callback(2);
				end;
			end,
			OnSwipeHandler = function(this, dir)
--        if (_pageIndex <= 0 && dir == SwipeEventHandler.SwipeDirection.Right) return;
--        if (_pageIndex >= _com.PagesCom.pageList.Count - 1 && dir == SwipeEventHandler.SwipeDirection.Left) return;
				this:BlockUI();
				local duration; duration = 0.30;
				this:StartCoroutine(this:SlideSequence(duration, dir));
			end,
			SlideSequence = function(this, duration, dir)
				if (dir == 1) then
					this._com.PagesCom.EnhanceScroll:OnBtnLeftClick();
				else
					this._com.PagesCom.EnhanceScroll:OnBtnRightClick();
				end;
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, duration), false, true);
				this:UnblockUI();
			end),
			ResetPagePosition = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._com, nil) then
					return ;
				end;
--重置ScrollView的位置和视域.
--EINGUIEnhanceItem enhanceItem = _com.PagesCom.pageList[0].enhanceItem;
--enhanceItem.GetComponent<UIEventListener>().onClick(enhanceItem.gameObject);
--EnhanceScrollView.GetInstance.SetHorizontalTargetItemIndex(_com.PagesCom.pageList[0].enhanceItem);  
				this._com.PagesCom.EnhanceScroll:ResetPosition();
--重置滚动列表，切换到第一个元素.
				this._com.PagesCom.ScrollView:ResetPosition();
--重置UI位置.
			end,
			BlockUI = function(this)
				this:DispatchEvent(newobject(Eight.Framework.EIEvent, "ctor__System_String__Eight_Framework_EIEvent_ReturnCallBack__System_Object__System_Single", nil, "UI_COMMON_BLOCK_PANEL_OPEN", nil, nil, 0.00));
			end,
			UnblockUI = function(this)
				this:DispatchEvent(newobject(Eight.Framework.EIEvent, "ctor__System_String__Eight_Framework_EIEvent_ReturnCallBack__System_Object__System_Single", nil, "UI_COMMON_BLOCK_PANEL_CLOSE", nil, nil, 0.00));
			end,
			OnOneBtnClick = function(this, staticId)
				local sd; sd = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_conscribe), staticId);
				local curTime; curTime = AlarmManager.Instance:currentTimeMillis();
				local isDuringTime; isDuringTime = this:isDuringOpenTime(curTime, sd);
				if (not isDuringTime) then
					this:ShowFloatTip("非常抱歉，招募活动已经结束");
					return ;
				end;
--防止动画加载的过程中玩家连续点击抽奖按钮.
				if this._isLoadingAni then
					return ;
				end;
				this._isLoadingAni = true;
				this:BlockUI();
				Eight.Framework.EIFrameWork.StartCoroutine(this:LoadLotterySceneCom((function()
					this:UnblockUI();
					this._isLoadingAni = false;
--加载完动画后再进行网络请求.
					local action; action = EightGame.Data.Server.ServerService.LuckdrawoneMethod(staticId);
					Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):NetworkRequest(action, (function(returnCode, response)
						this:StartCoroutine(this:_OnOneBtnResponse(returnCode, response));
					end), true, false);
				end)), false);
			end,
			OnTenBtnClick = function(this, staticId)
				local sd; sd = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_conscribe), staticId);
				local player; player = LogicStatic.Get__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
				if (player.vipLv < sd.needviplv) then
					this:ShowFloatTip("您的会员等级不足");
					return ;
				end;
				local curTime; curTime = AlarmManager.Instance:currentTimeMillis();
				local isDuringTime; isDuringTime = this:isDuringOpenTime(curTime, sd);
				if (not isDuringTime) then
					this:ShowFloatTip("非常抱歉，招募活动已经结束");
					return ;
				end;
--防止动画加载的过程中玩家连续点击抽奖按钮.
				if this._isLoadingAni then
					return ;
				end;
				this._isLoadingAni = true;
				this:BlockUI();
				Eight.Framework.EIFrameWork.StartCoroutine(this:LoadLotterySceneCom((function()
					this:UnblockUI();
					this._isLoadingAni = false;
--加载完动画后再进行网络请求.
					local action; action = EightGame.Data.Server.ServerService.LuckdrawtenMethod(staticId);
					Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):NetworkRequest(action, (function(returnCode, response)
						this:StartCoroutine(this:_OnTenBtnResponse(returnCode, response));
					end), true, false);
				end)), false);
			end,
			_OnOneBtnResponse = function(this, returnCode, response)
				if (returnCode < 1000) then
					local res; res = typeas(response, EightGame.Data.Server.LuckDrawOneResponse, false);
					local conscribe; conscribe = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_conscribe), res.luckid);
					this:ShowSummonUI();
					this:RegisterItemsToList(res.datas);
					this._lotterySceneCom.animator:SetTrigger("1");
--热云记录抽奖情况
					if (conscribe.costtype == 2) then
						if (not res.isfree) then
							if (conscribe.cost ~= -1) then
								Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.Statistical):RecordOtherPurchase(("单次抽_" + conscribe.id), 1, conscribe.cost, se_currency.SE_CURRENCY_DIAMOND );
							end;
						end;
					else
						if (not res.isfree) then
							if (conscribe.costten ~= -1) then
								Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.Statistical):RecordOneFriendShipLottery(conscribe.costten);
							end;
						end;
					end;
				else
					this:ShowFloatTip(EightGame.Component.NetCode.GetDesc(returnCode));
				end;
				wrapyield(nil, false, false);
			end),
			_OnTenBtnResponse = function(this, returnCode, response)
				if (returnCode < 1000) then
					local res; res = typeas(response, EightGame.Data.Server.LuckDrawTenResponse, false);
					local conscribe; conscribe = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_conscribe), res.luckid);
					this:ShowSummonUI();
					local list; list = this:SplitRewardItems(res.datas, conscribe.droptimes);
					this:RegisterItemsToList(list);
					this._lotterySceneCom.animator:SetTrigger("10");
--热云记录抽奖情况
					if (conscribe.costtype == 2) then
						if (conscribe.costten ~= -1) then
							Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.Statistical):RecordOtherPurchase(("十连抽_" + conscribe.id), 1, conscribe.costten, se_currency.SE_CURRENCY_DIAMOND );
						end;
					else
						if (not res.isfree) then
							if (conscribe.costten ~= -1) then
								Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.Statistical):RecordTenFriendShipLottery(conscribe.costten);
							end;
						end;
					end;
				else
					this:ShowFloatTip(EightGame.Component.NetCode.GetDesc(returnCode));
				end;
				wrapyield(nil, false, false);
			end),
			OnLotteryDataUpdate = function(this, response)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._com, nil) then
					return ;
				end;
--更新一下抽卡的各种可用信息.
				LotteryCheckAvailable.UpdateAvailableInfo();
				this:UpdateUI();
			end,
			OnPlayerDataUpdate = function(this, e)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._com, nil) then
					return ;
				end;
				local player; player = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetDataByCls__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
				this._com.PagesCom:SetFriendPoint(player.friendPoint);
				this._com.PagesCom:SetDiamond(player.diamond);
			end,
			OnOneBtnDisaleClick = function(this, staticId)
				local costtype; costtype = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_conscribe), staticId).costtype;
				this:ShowFloatTip(LotteryUtil.GetCostTypeNotEnoughNetcodeMsg(costtype));
			end,
			OnTenBtnDisaleClick = function(this, staticId)
				local costtype; costtype = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_conscribe), staticId).costtype;
				this:ShowFloatTip(LotteryUtil.GetCostTypeNotEnoughNetcodeMsg(costtype));
			end,
			OnAniMotion = function(this, e)
				local param; param = e.stringParameter;
				if System.String.IsNullOrEmpty(param) then
					return ;
				end;
				if (param == "one_end") then
					this:StartCoroutine(this:ShowGetRoles(true));
				elseif (param == "ten_end") then
					this:StartCoroutine(this:ShowGetRoles(false));
				elseif (param == "one_card_1") then
					local path; path = System.String.Format("kapaizu/kaipai000/kapai00/i_mount_00");
					local mount; mount = this._lotterySceneCom.transform:Find(path);
					this:AddRewardItem(this._com.RewardsCom.container, mount, getexterninstanceindexer(this._items, nil, "get_Item", 0), true);
				else
					local i; i = 1;
					while (i <= 10) do
						local cmdStr; cmdStr = System.String.Format("ten_card_{0}", i);
						if (param == cmdStr) then
							local path; path = System.String.Format("kapaizu/kaizu/kaipai{0}/kapai_{0}/i_mount_{0}", invokeforbasicvalue(invokeforbasicvalue(i, false, System.Int32, "ToString"), false, System.String, "PadLeft", 2, wrapchar('0', 0x030)));
							local mount; mount = this._lotterySceneCom.transform:Find(path);
							if (this._items.Count >= i) then
								this:AddRewardItem(this._com.RewardsCom.container, mount, getexterninstanceindexer(this._items, nil, "get_Item", invokeintegeroperator(3, "-", i, 1, System.Int32, System.Int32)), false);
							else
								Eight.Framework.EIDebuger.LogError(System.String.Format("[{0}] not have enough item to show", LobbyUINode));
							end;
						end;
					i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
					end;
				end;
			end,
			ShowSummonUI = function(this)
--清容器.
				this._com.RewardsCom:ClearContainer();
--清图标列表.
				this._itemIcons:Clear();
--隐藏正常的UI.
				this._com.ControllerCom.gameObject:SetActive(false);
				this._com.PagesCom.gameObject:SetActive(false);
				this._com.DotsCom.gameObject:SetActive(false);
--隐藏顶部导航.
				this:ShowOrHideSubHeader(false);
--显示容器.
				this._com.RewardsCom.gameObject:SetActive(true);
--显示跳过按钮.
--_com.RewardsCom.skipBtn.gameObject.SetActive(true);
--封全局UI.
				this._com.RewardsCom.topBlockBg.gameObject:SetActive(true);
--隐藏退出挡板.
				this._com.RewardsCom.dissmisBg.gameObject:SetActive(false);
			end,
			RegisterItemsToList = function(this, items)
				this._items = items;
			end,
			AddRewardItem = function(this, container, mountPoint, itemData, isOneCard)
				local screenPos; screenPos = this._lotterySceneCom.fxCamera:WorldToScreenPoint(mountPoint.position);
				local uiPos; uiPos = GlobalCamera.uiCamera:ScreenToWorldPoint(screenPos);
				local go; go = nil;
				if (not itemData.isRole) then
--加载物品图标.
					local itemitem; itemitem = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.sd_item_item), itemData.id);
					go = GameUtility.InstantiateGameObject(this._com.RewardsCom.rewardItemModel.gameObject, container, System.String.Format("item_{0}", itemitem.id), nil, nil, nil);
					local itemModelCom; itemModelCom = go:GetComponent(ItemModelCom);
					ItemModelUtility.UpdateView__ItemModelCom__System_Int32__System_Int64__System_Int32__System_Int32__System_Boolean__System_Boolean(ItemModelUtility, itemModelCom, typecast(itemitem.type, System.Int32, false), 0, typecast(itemData.id, System.Int32, false), itemData.num, false, true);
					itemModelCom.nameLabel.text = itemitem.cardname;
					local rareIconGo; rareIconGo = GameUtility.InstantiateGameObject(this._com.RewardsCom.rewardRareIconModel.gameObject, go, "rareIcon", nil, nil, nil);
					rareIconGo:GetComponent(LotteryRareIconCom):Init(itemitem.cardlabeltype, isOneCard);
--            //设置物品的光环特效.
--            LotteryItemHaloCom itemHalo = go.GetComponent<LotteryItemHaloCom>();
--            itemHalo.Init(itemitem.rank, 3);
				else
--加载角色图标.
					local role; role = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.sd_role_role), itemData.id);
					go = GameUtility.InstantiateGameObject(this._com.RewardsCom.rewardRoleModel.gameObject, container, System.String.Format("role_{0}", role.id), nil, nil, nil);
					go.transform.position = uiPos;
					local roleModelCom; roleModelCom = go:GetComponent(RoleModelCom);
					roleModelCom:SetValue(role);
					local rareIconGo; rareIconGo = GameUtility.InstantiateGameObject(this._com.RewardsCom.rewardRareIconModel.gameObject, go, "rareIcon", nil, nil, nil);
					rareIconGo:GetComponent(LotteryRareIconCom):Init(role.cardlabeltype, isOneCard);
				end;
--把图标加到列表中，以方便以后把角色头像替换成角色碎片用.
				this._itemIcons:Add(go);
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", go, nil) then
--校正位置.
					go.transform.position = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, uiPos.x, uiPos.y, 0);
--播放淡入效果.
					this:CreateAlphaTweener(go, false):PlayForward();
				end;
			end,
			ShowGetRoles = function(this, isOneCard)
				wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, 2.00), false, true);
				local isShowingRole; isShowingRole = false;
				local i; i = 0;
				while (i < this._items.Count) do
				repeat
					local itemData; itemData = getexterninstanceindexer(this._items, nil, "get_Item", i);
					if (not itemData.isRole) then
						break;
					end;
--播放卡片特效.
					GameUtility.PlayerEffect("BaseAssets/Prefabs/Others/CatchCard2/eff_CatchCard02", this._com.RewardsCom.container, (function(fxgo)
						fxgo:GetComponent(typeof(UnityEngine.Animator)):SetInteger("id", condexp(isOneCard, true, 100, false, (function() return invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32); end)));
					end), nil, nil, this._com.RewardsCom.container.layer, -1, nil, true, nil, nil);
					wrapyield(newexternobject(UnityEngine.WaitForSeconds, "UnityEngine.WaitForSeconds", "ctor", nil, 1.30), false, true);
--播放全屏特效.
					isShowingRole = true;
					local role; role = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.sd_role_role), itemData.id);
					local isAlreadyHave; isAlreadyHave = (itemData.resolveItemNum ~= -1);
--播放完后才允许继续下一个遍历.
					LotteryGetRolePopupDialogNode.Open(role, isAlreadyHave);
					delegationset(false, true, "LotteryGetRolePopupDialogNode:ondismiss", LotteryGetRolePopupDialogNode, nil, "ondismiss", (function()
						isShowingRole = false;
						if (this.ViewParent ~= nil) then
							this.ViewParent:CheckGuide();
						end;
					end));
--等待角色展示完成.
					while isShowingRole do
						wrapyield(nil, false, false);
					end;
					local go; go = getexterninstanceindexer(this._itemIcons, nil, "get_Item", i);
					local roleCom; roleCom = go:GetComponent(RoleModelCom);
					roleCom.nameLabel.text = role.cardname;
					roleCom.nameLabel.color = RoleInfoUtil.GetQualityColor(role.rank);
					if isAlreadyHave then
--删除原来的角色头像，换成角色碎片.
						local oldPos; oldPos = go.transform.localPosition;
						go:SetActive(false);
						UnityEngine.Object.DestroyImmediate(go);
--显示角色碎片.
						local itemitem; itemitem = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_item_item), itemData.resolveItem);
						if (itemitem == nil) then
							Eight.Framework.EIDebuger.LogError(System.String.Format("[LotteryUINode] Could\'t find item {0}", itemData.resolveItem));
						end;
						local itemGO; itemGO = GameUtility.InstantiateGameObject(this._com.RewardsCom.rewardItemModel, this._com.RewardsCom.container, System.String.Format("role_item_{0}", itemitem.id), nil, nil, nil);
						local itemModelCom; itemModelCom = itemGO:GetComponent(ItemModelCom);
						itemModelCom:SetValue(typecast(itemitem.type, System.Int32, false), 0, typecast(itemData.resolveItem, System.Int32, false), itemData.resolveItemNum, false, true, false, false);
						itemModelCom.nameLabel.text = itemitem.cardname;
						itemGO.transform.localPosition = oldPos;
						local rareIconGo; rareIconGo = GameUtility.InstantiateGameObject(this._com.RewardsCom.rewardRareIconModel.gameObject, itemGO, "rareIcon", nil, nil, nil);
						rareIconGo:GetComponent(LotteryRareIconCom):Init(itemitem.cardlabeltype, isOneCard);
--替换列表.
						setexterninstanceindexer(this._itemIcons, nil, "set_Item", i, itemGO);
--淡入角色碎片.
						this:CreateAlphaTweener(itemGO, false):PlayForward();
--                //设置物品的光环特效.
--                LotteryItemHaloCom itemHalo = itemGO.GetComponent<LotteryItemHaloCom>();
--                itemHalo.Init(itemitem.rank, 3);
					end;
				until true;
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
				this:ShowSummonReadyQuitUI();
			end),
			ShowSummonReadyQuitUI = function(this)
--隐藏跳过按钮.
				this._com.RewardsCom.skipBtn.gameObject:SetActive(false);
--解封全局UI.
				this._com.RewardsCom.topBlockBg.gameObject:SetActive(false);
--显示退出挡板.
				this._com.RewardsCom.dissmisBg.gameObject:SetActive(true);
			end,
			HideSummonUI = function(this)
--显示正常的UI.
				this._com.ControllerCom.gameObject:SetActive(true);
				this._com.PagesCom.gameObject:SetActive(true);
				this._com.DotsCom.gameObject:SetActive(true);
--隐藏容器.
				this._com.RewardsCom.gameObject:SetActive(false);
--显示顶部导航.
				this:ShowOrHideSubHeader(true);
--回退动画到初始状态.
				this._lotterySceneCom.animator:SetTrigger("back");
			end,
			CreateAlphaTweener = function(this, go, isReverse)
				local ta; ta = go:AddComponent(TweenAlpha);
				ta.from = condexp(isReverse, true, 1.00, true, 0.00);
				ta.to = condexp(isReverse, true, 0.00, true, 1.00);
				ta.duration = 0.60;
				ta.method = 1;
				ta.enabled = false;
				EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(ta.onFinished, (function()
					UnityEngine.Object.Destroy(ta);
				end));
				return ta;
			end,
			SplitRewardItems = function(this, items, splitNum)
				local dic; dic = newexterndictionary(System.Collections.Generic.Dictionary_System.Int64_System.Int32, "System.Collections.Generic.Dictionary_System.Int64_System.Int32", "ctor", {});
				local itemItems; itemItems = newexternlist(System.Collections.Generic.List_EightGame.Data.Server.LotteryItemData, "System.Collections.Generic.List_EightGame.Data.Server.LotteryItemData", "ctor", {});
				local roleItems; roleItems = newexternlist(System.Collections.Generic.List_EightGame.Data.Server.LotteryItemData, "System.Collections.Generic.List_EightGame.Data.Server.LotteryItemData", "ctor", {});
				local newItems; newItems = newexternlist(System.Collections.Generic.List_EightGame.Data.Server.LotteryItemData, "System.Collections.Generic.List_EightGame.Data.Server.LotteryItemData", "ctor", {});
--把物品与人物按种类分拣到桶.
				local i; i = 0;
				while (i < items.Count) do
					local item; item = getexterninstanceindexer(items, nil, "get_Item", i);
					if item.isRole then
						roleItems:Add(item);
					else
						local val; val = this:GetDicVal(dic, item.id);
						val = invokeintegeroperator(2, "+", val, item.num, System.Int32, System.Int32);
						setexterninstanceindexer(dic, nil, "set_Item", item.id, val);
					end;
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
--把人物排到人物碎片的前面.
				local i; i = 0;
				while (i < roleItems.Count) do
					if (getexterninstanceindexer(roleItems, nil, "get_Item", i).resolveItemNum == -1) then
						local j; j = 0;
						while (j < i) do
							if ((getexterninstanceindexer(roleItems, nil, "get_Item", i).id == getexterninstanceindexer(roleItems, nil, "get_Item", j).id) and (getexterninstanceindexer(roleItems, nil, "get_Item", j).resolveItemNum ~= -1)) then
								local temp; temp = getexterninstanceindexer(roleItems, nil, "get_Item", i);
								setexterninstanceindexer(roleItems, nil, "set_Item", i, getexterninstanceindexer(roleItems, nil, "get_Item", j));
								setexterninstanceindexer(roleItems, nil, "set_Item", j, temp);
								break;
							end;
						j = invokeintegeroperator(2, "+", j, 1, System.Int32, System.Int32);
						end;
					end;
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
--把物品从桶分到盘子.
				local lastNum; lastNum = invokeintegeroperator(3, "-", splitNum, roleItems.Count, System.Int32, System.Int32);
				local totalItemNum; totalItemNum = 0;
				local dishes; dishes = newexternlist(System.Collections.Generic.List_, "System.Collections.Generic.List_", "ctor", {});
				for d in getiterator(dic) do
					dishes:Add(wraparray{d.Key, d.Value});
					totalItemNum = invokeintegeroperator(2, "+", totalItemNum, d.Value, System.Int32, System.Int32);
				end;
				if (totalItemNum >= lastNum) then
					while (dishes.Count < lastNum) do
						local i; i = UnityEngine.Random.Range(0, dishes.Count);
						if (getexterninstanceindexer(dishes, nil, "get_Item", i)[2] > 1) then
							local extrudeNum; extrudeNum = UnityEngine.Random.Range(1, invokeintegeroperator(3, "-", typecast(getexterninstanceindexer(dishes, nil, "get_Item", i)[2], System.Int32, false), 1, System.Int32, System.Int32));
							getexterninstanceindexer(dishes, nil, "get_Item", i)[2] = extrudeNum;
							dishes:Add(wraparray{getexterninstanceindexer(dishes, nil, "get_Item", i)[1], extrudeNum});
						end;
					end;
				end;
--存放物品到临时列表.
				local i; i = 0;
				while (i < dishes.Count) do
					local item; item = newexternobject(EightGame.Data.Server.LotteryItemData, "EightGame.Data.Server.LotteryItemData", "ctor", nil);
					item.id = getexterninstanceindexer(dishes, nil, "get_Item", i)[1];
					item.num = typecast(getexterninstanceindexer(dishes, nil, "get_Item", i)[2], System.Int32, false);
					item.isRole = false;
					itemItems:Add(item);
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
--把物品插入到人物中.
				newItems:AddRange(roleItems);
				local random; random = newexternobject(System.Random, "System.Random", "ctor", nil);
				local i; i = 0;
				while (i < itemItems.Count) do
					newItems:Insert(random:Next(invokeintegeroperator(2, "+", newItems.Count, 1, System.Int32, System.Int32)), getexterninstanceindexer(itemItems, nil, "get_Item", i));
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
				return newItems;
			end,
			GetDicVal = function(this, dic, key)
				if (not dic:ContainsKey(key)) then
					dic:Add(key, 0);
				end;
				return getexterninstanceindexer(dic, nil, "get_Item", key);
			end,
			ConvertCountDownToTime = function(this, seconds)
				local span; span = System.TimeSpan.FromMilliseconds(invokeintegeroperator(4, "*", seconds, 1000, System.Int32, System.Int32));
				local timeStr; timeStr = System.String.Format("{0:D2}:{1:D2}:{2:D2}", span.Hours, span.Minutes, span.Seconds);
				return timeStr;
			end,
			GetDiscountStr = function(this, val)
				local numStr; numStr = System.String.Format("{0}", (val - typecast(val, System.Int32, false)));
				if (getforbasicvalue(numStr, false, System.String, "Length") < 3) then
					return "";
				else
					return (invokeforbasicvalue(numStr, false, System.String, "Substring", 2) + "折");
				end;
			end,
			isDuringOpenTime = function(this, curTime, sd)
				return ((curTime <= AlarmManagerHelper.DateTimeToUnixTime(System.Convert.ToDateTime(sd.endtime))) and (curTime >= AlarmManagerHelper.DateTimeToUnixTime(System.Convert.ToDateTime(sd.begintime))));
			end,
			ShowFloatTip = function(this, msg)
				local param; param = newobject(EightGame.Logic.TipStruct, "ctor", nil, msg, 0.20);
				this:DispatchEvent(newobject(Eight.Framework.EIEvent, "ctor__System_String__Eight_Framework_EIEvent_ReturnCallBack__System_Object__System_Single", nil, "UI_FLOATING_TIPS", nil, param, 0.00));
			end,
			DestroyChildren = function(this, trans)
				local children; children = newexternlist(System.Collections.Generic.List_UnityEngine.GameObject, "System.Collections.Generic.List_UnityEngine.GameObject", "ctor", {});
				for child in getiterator(trans) do
					children:Add(child.gameObject);
				end;
				trans:DetachChildren();
				children:ForEach((function(child) return UnityEngine.Object.Destroy(child); end));
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				_UIPath = "Lottery/ui_lottery",
				_com = __cs2lua_nil_field_value,
				_pageIndex = 0,
				_lotterySceneCom = __cs2lua_nil_field_value,
				_items = __cs2lua_nil_field_value,
				_itemIcons = newexternlist(System.Collections.Generic.List_UnityEngine.GameObject, "System.Collections.Generic.List_UnityEngine.GameObject", "ctor", {}),
				GOLD_COUNT_DOWN = "gold_count_down",
				DIAMOND_COUNT_DOWN = "diamond_count_down",
				_isLoadingAni = false,
			};
			return instance_fields;
		end;

		local instance_props = {
			Title = {
				get = instance_methods.get_Title,
			},
		};

		local instance_events = nil;
		local interfaces = {
			"System.Collections.IEnumerable",
		};

		local interface_map = {
			IEnumerable_GetEnumerator = "EINode_GetEnumerator",
		};


		return defineclass(EightGame.Logic.BaseSubHeaderEvent, "LotteryUINode", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryUINode.__define_class();
