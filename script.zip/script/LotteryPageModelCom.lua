-- //  **********************************************************************
-- //  Copyright  2016  EIGHT Team . All rights reserved.
-- //  File     : LotteryPageModelCom.cs
-- //  Author   : wolforce
-- //  Created  : 2016/2/17  17:19 
-- //  Purpose  : 抽卡界面的分页UI通用模型.
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "LotteryUtil";
require "AlarmManager";
require "LotteryCheckAvailable";
require "GameUtility";

LotteryPageModelCom = {
	__new_object = function(...)
		return newobject(LotteryPageModelCom, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotteryPageModelCom;

		local static_methods = {
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			UpdateUI = function(this, sd, dy, player)
				this._sd = sd;
				this._dy = dy;
				local isHaveFree; isHaveFree = sd.free;
				local isDailyReset; isDailyReset = (isHaveFree and (sd.max > -1));
				local isHaveFreeChance; isHaveFreeChance = (isHaveFree and ( ((dy == nil) or (dy.todayfreecount < sd.max)) ));
				local isCD; isCD = (isHaveFree and ( ((dy == nil) or (LotteryUtil.GetCountDown(dy.destunixtime) <= 0)) ));
				local isOneCurrencyEnough; isOneCurrencyEnough = false;
				local isTenCurrencyEnough; isTenCurrencyEnough = false;
--SetDesc(sd.desc);
--对时间提示来说：
--无免费抽奖 => 隐藏.
--有免费抽奖，有每日刷新，次数不够 => 隐藏.
--有免费抽奖，有每日刷新，次数足够，CD时间没到 => 显示CD时间.
--有免费抽奖，有每日刷新，次数足够，CD时间已到 => 显示今日剩余次数.
--有免费抽奖，无每日刷新，CD时间没到 => 显示CD时间.
--有免费抽奖，无每日刷新，CD时间已到 => 显示“可以免费召唤了哦~”.
--SetDesc(sd.desc);
--对时间提示来说：
--无免费抽奖 => 隐藏.
--有免费抽奖，有每日刷新，次数不够 => 隐藏.
--有免费抽奖，有每日刷新，次数足够，CD时间没到 => 显示CD时间.
--有免费抽奖，有每日刷新，次数足够，CD时间已到 => 显示今日剩余次数.
--有免费抽奖，无每日刷新，CD时间没到 => 显示CD时间.
--有免费抽奖，无每日刷新，CD时间已到 => 显示“可以免费召唤了哦~”.
				local timeTipsFlag; timeTipsFlag = true;
				if ((not isHaveFree) or ( ((isHaveFree and isDailyReset) and (not isHaveFreeChance)) )) then
					timeTipsFlag = false;
				end;
				this.TimeTipsGo:SetActive(timeTipsFlag);
				local COUNT_DOWN_NAME; COUNT_DOWN_NAME = System.String.Format("lottery_page_cd_luckid_{0}", sd.id);
				if (( (((isHaveFree and isDailyReset) and isHaveFreeChance) and (not isCD)) ) or ( ((isHaveFree and (not isDailyReset)) and (not isCD)) )) then
--显示CD时间.
					this:BindCoolDownAlarm(COUNT_DOWN_NAME, LotteryUtil.GetCountDown(dy.destunixtime));
				else
					AlarmManager.Instance:cancel(COUNT_DOWN_NAME);
				end;
				if (((isHaveFree and isDailyReset) and isHaveFreeChance) and isCD) then
--显示今日剩余次数.
					local usedCount; usedCount = condexp(( (dy == nil) ), true, 0, false, (function() return dy.todayfreecount; end));
					this:SetTimeTips(System.String.Format("今日剩余免费次数: {0}", invokeintegeroperator(3, "-", sd.max, usedCount, System.Int32, System.Int32)));
				end;
				if ((isHaveFree and (not isDailyReset)) and isCD) then
--显示“可以免费召唤了哦~”.
					this:SetTimeTips("可以免费召唤了哦~");
				end;
--对单抽按钮来说：
--无免费抽奖 => 花钱.
--有免费抽奖，有每日刷新，次数不够 => 花钱.
--有免费抽奖，有每日刷新，次数足够，CD时间没到 => 花钱.
--有免费抽奖，有每日刷新，次数足够，CD时间已到 => 免费抽.
--有免费抽奖，无每日刷新，CD时间没到 => 花钱.
--有免费抽奖，无每日刷新，CD时间已到 => 免费抽.
				if (( (((isHaveFree and isDailyReset) and isHaveFreeChance) and isCD) ) or ( ((isHaveFree and (not isDailyReset)) and isCD) )) then
--免费抽.
					this:SetOneBtnTitle("免费召唤 1 次");
					if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this.OneBtn, nil) then
						this.OneBtn.isEnabled = true;
					end;
					isOneCurrencyEnough = true;
				else
--花钱抽.
					this:SetOneBtnTitle(System.String.Format("召唤 1 次"));
				end;
				local oneColor; oneColor = LotteryUtil.GetCostCurrencyColor(player, sd.costtype, sd.cost);
				this.OneBtnCurrencyLabel.text = System.String.Format("[{0}]{1}[-]", oneColor, sd.cost);
--对单抽角标来说：
--单抽免费 => 显示“免费”字样.
--单抽收费 => 如果有打折就显示，没打折就隐藏.
				if (( (((isHaveFree and isDailyReset) and isHaveFreeChance) and isCD) ) or ( ((isHaveFree and (not isDailyReset)) and isCD) )) then
--免费抽.
					this.OneBtnCornerGo:SetActive(true);
					this:SetOneBtnCornerLabel("免费");
				else
--花钱抽.
					local isOneDiscount; isOneDiscount = false;
					this.OneBtnCornerGo:SetActive(isOneDiscount);
					if isOneDiscount then
						this:SetOneBtnCornerLabel("9折");
					end;
				end;
--多抽按钮.
				this.TenBtn.gameObject:SetActive((sd.droptimes > 0));
				if (sd.droptimes > 0) then
					local tenColor; tenColor = LotteryUtil.GetCostCurrencyColor(player, sd.costtype, sd.costten);
					this:SetTenBtnTitle(System.String.Format("召唤 10 次"));
					this.TenBtnCurrencyLabel.text = System.String.Format("[{0}]{1}[-]", tenColor, sd.costten);
--多抽角标.
					local isTenDiscount; isTenDiscount = false;
					this.TenBtnCornerGo:SetActive(isTenDiscount);
					if isTenDiscount then
						this:SetTenBtnCornerLabel("9折");
					end;
				end;
--按钮背景图片.
				this.OneBtn.normalSprite = LotteryUtil.GetCostTypeBtnBg(sd.costtype);
				this.TenBtn.normalSprite = LotteryUtil.GetCostTypeBtnBg(sd.costtype);
				this.OneBtnCurrencyIcon.spriteName = LotteryUtil.GetCostTypeCurrencyIcon(sd.costtype);
				this.TenBtnCurrencyIcon.spriteName = LotteryUtil.GetCostTypeCurrencyIcon(sd.costtype);
--气泡提示(仅在有优惠券时才提示).
				local info; info = getexterninstanceindexer(LotteryCheckAvailable.GetDic(), nil, "get_Item", sd.id);
				local oneHaveFreeChange; oneHaveFreeChange = info.isOneHaveFreeChance;
				local oneCouponEnough; oneCouponEnough = info.isOneCouponEnough;
				local tenCouponEnough; tenCouponEnough = info.isTenCouponEnough;
				local isShowOneBtnBubble; isShowOneBtnBubble = ((not oneHaveFreeChange) and oneCouponEnough);
				local isShowTenBtnBubble; isShowTenBtnBubble = tenCouponEnough;
				this.OneBtnBubbleTips:SetActive(isShowOneBtnBubble);
				this.TenBtnBubbleTips:SetActive(isShowTenBtnBubble);
				if oneCouponEnough then
					this.OneBtnBubbleIcon.spriteName = "icon_coupon";
					this.OneBtnBubbleIconLabel.text = System.String.Format("[{0}]x {1}[-]", "ffd687", sd.costitem.value);
				end;
				if tenCouponEnough then
					this.TenBtnBubbleIcon.spriteName = "icon_coupon";
					this.TenBtnBubbleIconLabel.text = System.String.Format("[{0}]x {1}[-]", "ffd687", sd.costtenitem.value);
				end;
--决定货币点数的显隐.
				this.OneBtnCurrencyLabel.gameObject:SetActive((not isShowOneBtnBubble));
				this.TenBtnCurrencyLabel.gameObject:SetActive((not isShowTenBtnBubble));
--决定按钮底图是否灰色，货币足够，有免费抽奖机会，有优惠券.
				isOneCurrencyEnough = condexp(isOneCurrencyEnough, true, true, false, (function() return (LotteryUtil.GetCostTypeField(player, sd.costtype) >= sd.cost); end));
				isTenCurrencyEnough = condexp(isTenCurrencyEnough, true, true, false, (function() return (LotteryUtil.GetCostTypeField(player, sd.costtype) >= sd.costten); end));
				this.OneBtn.isEnabled = ((isOneCurrencyEnough or oneHaveFreeChange) or oneCouponEnough);
				this.TenBtn.isEnabled = (isTenCurrencyEnough or tenCouponEnough);
--描述文字.
				local desc; desc = GameUtility.Unescape(sd.desc);
				if ((sd.id == 1000) and ( ((dy == nil) or (dy.onetotalcount == 0)) )) then
					desc = ("首次10连抽，必定出现3星\n" + desc);
				end;
				this:SetDesc(desc);
			end,
			SetDesc = function(this, desc)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.DescLabel, nil) then
					return ;
				end;
				this.DescLabel.text = desc;
			end,
			SetTimeTips = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.TimeLabel, nil) then
					return ;
				end;
				this.TimeLabel.text = str;
			end,
			SetBtnBg = function(this, btn, costtype)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", btn, nil) then
					return ;
				end;
				btn.normalSprite = LotteryUtil.GetCostTypeBtnBg(costtype);
			end,
			SetOneBtnTitle = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.OneBtnTitleLabel, nil) then
					return ;
				end;
				this.OneBtnTitleLabel.text = str;
			end,
			SetOneBtnCornerLabel = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.OneBtnCornerLabel, nil) then
					return ;
				end;
				this.OneBtnCornerLabel.text = str;
			end,
			SetTenBtnTitle = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.TenBtnTitleLabel, nil) then
					return ;
				end;
				this.TenBtnTitleLabel.text = str;
			end,
			SetTenBtnCornerLabel = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this.TenBtnCornerLabel, nil) then
					return ;
				end;
				this.TenBtnCornerLabel.text = str;
			end,
			BindCoolDownAlarm = function(this, alarmName, countDown)
				AlarmManager.Instance:set(alarmName, invokeintegeroperator(2, "+", AlarmManager.Instance:currentTimeMillis(), invokeintegeroperator(4, "*", countDown, 1000, System.Int32, System.Int32), System.Int64, System.Int64), (function(start, cur, __compiler_lua_end)
					local remainTime; remainTime = typecast(( invokeintegeroperator(0, "/", ( invokeintegeroperator(3, "-", __compiler_lua_end, cur, System.Int64, System.Int64) ), 1000, System.Int64, System.Int64) ), System.Int32, false);
--TODO 在这里不断地判断时间是否到达每日刷新时间，如果到达了那个时间，就显示剩余sd:max()次，不用担心出错，因为如果中间如有过抽奖操作，本闹钟会在上个函数被取消掉.
					this:SetTimeTips((this:ConvertCountDownToTime(remainTime) + " 后免费"));
				end), (function()
--显示今日剩余次数.
					if ((this._sd == nil) or (this._dy == nil)) then
						return ;
					end;
					local tipsStr; tipsStr = "";
					if (this._sd.max < 0) then
						tipsStr = System.String.Format("可以免费召唤了哦~");
					else
						tipsStr = System.String.Format("今日剩余免费次数: {0}", invokeintegeroperator(3, "-", this._sd.max, this._dy.todayfreecount, System.Int32, System.Int32));
					end;
					this:SetTimeTips(tipsStr);
					this:SetOneBtnTitle("免费召唤 1 次");
					if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this.OneBtn, nil) then
						this.OneBtn.isEnabled = true;
					end;
				end));
			end,
			ConvertCountDownToTime = function(this, seconds)
				local span; span = System.TimeSpan.FromMilliseconds(invokeintegeroperator(4, "*", seconds, 1000, System.Int32, System.Int32));
				local timeStr; timeStr = System.String.Format("{0:D2}:{1:D2}:{2:D2}", span.Hours, span.Minutes, span.Seconds);
				return timeStr;
			end,
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				DescLabel = __cs2lua_nil_field_value,
				TimeTipsGo = __cs2lua_nil_field_value,
				TimeClockIcon = __cs2lua_nil_field_value,
				TimeLabel = __cs2lua_nil_field_value,
				OneBtn = __cs2lua_nil_field_value,
				OneBtnDisable = __cs2lua_nil_field_value,
				OneBtnSpriteBg = __cs2lua_nil_field_value,
				OneBtnBubbleTips = __cs2lua_nil_field_value,
				OneBtnBubbleIcon = __cs2lua_nil_field_value,
				OneBtnBubbleIconLabel = __cs2lua_nil_field_value,
				OneBtnBubbleNoneIconLabel = __cs2lua_nil_field_value,
				OneBtnCurrencyIcon = __cs2lua_nil_field_value,
				OneBtnCurrencyLabel = __cs2lua_nil_field_value,
				OneBtnTitleLabel = __cs2lua_nil_field_value,
				OneBtnCornerGo = __cs2lua_nil_field_value,
				OneBtnCornerLabel = __cs2lua_nil_field_value,
				TenBtn = __cs2lua_nil_field_value,
				TenBtnDisable = __cs2lua_nil_field_value,
				TenBtnSpriteBg = __cs2lua_nil_field_value,
				TenBtnBubbleTips = __cs2lua_nil_field_value,
				TenBtnBubbleIcon = __cs2lua_nil_field_value,
				TenBtnBubbleIconLabel = __cs2lua_nil_field_value,
				TenBtnBubbleNoneIconLabel = __cs2lua_nil_field_value,
				TenBtnCurrencyIcon = __cs2lua_nil_field_value,
				TenBtnCurrencyLabel = __cs2lua_nil_field_value,
				TenBtnTitleLabel = __cs2lua_nil_field_value,
				TenBtnCornerGo = __cs2lua_nil_field_value,
				TenBtnCornerLabel = __cs2lua_nil_field_value,
				_sd = __cs2lua_nil_field_value,
				_dy = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(UnityEngine.MonoBehaviour, "LotteryPageModelCom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryPageModelCom.__define_class();
