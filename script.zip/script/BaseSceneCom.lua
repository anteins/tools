-- **********************************************************************
-- Copyright   2015  EIGHT Team . All rights reserved.
-- File     :  BaseSceneCom.cs
-- Author   : qbkira
-- Created  : 2015/1/27  上11:27 
-- Purpose  : 
-- **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIUIBehaviour";
require "Eight__Framework__EIFrameWork";
require "EightGame__Logic__AdventureManager";
require "EightGame__Component__NetworkClient";
require "LogicStatic";
require "ShowRewardUtil";
require "GameUtility";
require "RoleConfigureInfo";
require "FunctionOpenUtility";
require "Eight__Framework__EIEvent";
require "Eight__Framework__EIIntEvent";

BaseSceneCom = {
	__new_object = function(...)
		return newobject(BaseSceneCom, nil, nil, ...);
	end,
	__define_class = function()
		local static = BaseSceneCom;

		local static_methods = {
			cctor = function()
				EIUIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				ClickBaseSceneObj = "ClickBaseSceneObj",
				CameraTriggerToIdle = "CameraTriggerToIdle",
				_needReloadRoleByLineup = false,
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			Start = function(this)
				Eight.Framework.EIFrameWork.Instance:AddEventListener("SET_ROLE_SKIN", (function() local __compiler_delegation_54 = (function(e) this:ListenerPlayerChangeCloth(e); end); setdelegationkey(__compiler_delegation_54, "BaseSceneCom:ListenerPlayerChangeCloth", this, this.ListenerPlayerChangeCloth); return __compiler_delegation_54; end)());
			end,
			InitInfo = function(this)
				this._infoDic1:Clear();
				this._infoDic2:Clear();
				this._infoStrDic:Clear();
				this:CancelInvoke("InvokeRepeatRoleAni1");
				this:CancelInvoke("InvokeRepeatRoleAni2");
				this._needReloadRoleIds:Clear();
				BaseSceneCom._needReloadRoleByLineup = false;
				this:InitShowRole();
				this._roleId_1 = 0;
				this._roleId_2 = 0;
				this._roleId_3 = 0;
				this._roleId_4 = 0;
				local cachFightSerDataIds; cachFightSerDataIds = EightGame.Logic.AdventureManager.GetNormalBattleTroops(2);
				local index; index = 0;
				while (index < cachFightSerDataIds.Count) do
				repeat
					local serData; serData = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetDataByCls__System_Int64(typeof(EightGame.Data.Server.FighterSerData), getexterninstanceindexer(cachFightSerDataIds, nil, "get_Item", index));
					if (serData == nil) then
						break;
					end;
					local role; role = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetDataByCls__System_Int32(typeof(EightGame.Data.Server.sd_role_role), serData.staticId);
					if (role == nil) then
						break;
					end;
-- string skin_id = LogicStatic.Get<sd_role_skin>(role.skin).skin_id;
					if (index == 0) then
						this._roleId_1 = role.id;
					elseif (index == 1) then
						this._roleId_2 = role.id;
					elseif (index == 2) then
						this._roleId_3 = role.id;
					elseif (index == 3) then
						this._roleId_4 = role.id;
					end;
				until true;
				index = invokeintegeroperator(2, "+", index, 1, System.Int32, System.Int32);
				end;
				if ((((this._roleId_1 == 0) and (this._roleId_2 == 0)) and (this._roleId_3 == 0)) and (this._roleId_4 == 0)) then
					return ;
				end;
				local _roleIdList; _roleIdList = newexternlist(System.Collections.Generic.List_System.Int32, "System.Collections.Generic.List_System.Int32", "ctor", {});
				if (not _roleIdList:Contains(this._roleId_1)) then
					_roleIdList:Add(this._roleId_1);
				end;
				if (not _roleIdList:Contains(this._roleId_2)) then
					_roleIdList:Add(this._roleId_2);
				end;
				if (not _roleIdList:Contains(this._roleId_3)) then
					_roleIdList:Add(this._roleId_3);
				end;
				if (not _roleIdList:Contains(this._roleId_4)) then
					_roleIdList:Add(this._roleId_4);
				end;
				local index; index = 0;
				while (index < _roleIdList.Count) do
					this:InitRoleModel(index, getexterninstanceindexer(_roleIdList, nil, "get_Item", index));
				index = invokeintegeroperator(2, "+", index, 1, System.Int32, System.Int32);
				end;
				this:InitShowRole();
--InvokeRepeating( "InvokeRepeatRoleAni1" , 10f ,7f);
--InvokeRepeating( "InvokeRepeatRoleAni2" , 10f ,7f);
			end,
			SetHeroDoAniamtion = function(this, b)
				if b then
					if ((this._infoStrDic == nil) or (this._infoStrDic.Count == 0)) then
						return ;
					end;
					for keyValue in getiterator(this._infoStrDic) do
						keyValue.Value.fighterController.roleAnimtor:SetTrigger("sitidle");
					end;
--InvokeRepeating( "InvokeRepeatRoleAni1" , 10f ,7f);
--InvokeRepeating( "InvokeRepeatRoleAni2" , 10f ,7f);
				else
--CancelInvoke( "InvokeRepeatRoleAni1" );
--CancelInvoke( "InvokeRepeatRoleAni2" );
				end;
			end,
			SetCallBack = function(this, callback, onSignPhysical, settingAniFinish, missionAniFinish, signinAniFinish)
				delegationset(false, false, "BaseSceneCom:_callBack", this, nil, "_callBack", callback);
				delegationset(false, false, "BaseSceneCom:_onSignPhysicalCallBack", this, nil, "_onSignPhysicalCallBack", onSignPhysical);
				this._camearAnimator:SetActionCallBack(settingAniFinish, missionAniFinish, signinAniFinish);
			end,
			InitShowRole = function(this)
--EIDebuger.Log ("InitShowRole   先获取展示角色与默认皮肤");
				local roleSkinId; roleSkinId = 0;
				local roleId; roleId = 0;
--int roleId = 200401100;
				local _pl; _pl = LogicStatic.GetList(typeof(EightGame.Data.Server.PartyActiveSerData), (function(x) return (x.detailtype == 11); end));
				if ((_pl == nil) or (_pl.Count == 0)) then
					return ;
				end;
				local _thep; _thep = getexterninstanceindexer(_pl, nil, "get_Item", invokeintegeroperator(3, "-", _pl.Count, 1, System.Int32, System.Int32));
				this._curShowRolePartyId = _thep.id;
				if _thep.isserver then
					local _sdp; _sdp = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.ServerDetailParty), _thep.id);
					local Rdic; Rdic = ShowRewardUtil.GetJSdata(_sdp.rewards);
					for K in getiterator(Rdic.Keys) do
						Eight.Framework.EIDebuger.Log(((("K  -> " + K) + "  Rdic[K] :") + getexterninstanceindexer(Rdic, nil, "get_Item", K)));
						if (getexterninstanceindexer(Rdic, nil, "get_Item", K) == 1) then
							roleId = K;
						end;
					end;
				else
					local _sdp; _sdp = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.sd_party), _thep.branchid);
					if (_sdp == nil) then
						return ;
					end;
					local _sdpd; _sdpd = LogicStatic.Get__System_Int64(typeof(EightGame.Data.Server.sd_party_detail), getexterninstanceindexer(_thep.partydetail, nil, "get_Item", 0).id);
					if (_sdpd ~= nil) then
						roleId = getexterninstanceindexer(_sdpd.showreward, nil, "get_Item", 0).key;
					end;
				end;
				if (roleId == 0) then
					return ;
				end;
				local Skins; Skins = LogicStatic.GetList(typeof(EightGame.Data.Server.sd_role_skin), (function(x) return (x.role_id == roleId); end));
				if ((Skins == nil) or (Skins.Count == 0)) then
					Eight.Framework.EIDebuger.GameLog((" 找不到角色皮肤 roleId -> " + roleId));
					return ;
				end;
				local Hasall; Hasall = true;
				local i; i = 0;
				while (i < Skins.Count) do
					local _tempfs; _tempfs = LogicStatic.Get__System_Predicate_T(typeof(EightGame.Data.Server.FighterSkinSerData), (function(x) return (x.skinid == getexterninstanceindexer(Skins, nil, "get_Item", i).id); end));
					if (_tempfs == nil) then
						roleSkinId = getexterninstanceindexer(Skins, nil, "get_Item", i).id;
						Hasall = false;
						break;
					end;
				i = invokeintegeroperator(2, "+", i, 1, System.Int32, System.Int32);
				end;
				if Hasall then
					roleSkinId = getexterninstanceindexer(Skins, nil, "get_Item", invokeintegeroperator(3, "-", Skins.Count, 1, System.Int32, System.Int32)).id;
				end;
				this._showrole_1 = roleSkinId;
				GameUtility.CreateFighterObjByRoleid(roleId, 0, roleSkinId, false, this.ShowHeroMount, (function(obj)
					obj.name = invokeforbasicvalue(roleId, false, System.Int32, "ToString");
					local roleConfigInfo; roleConfigInfo = obj:GetComponent(RoleConfigureInfo);
					if ((invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", roleConfigInfo, nil) and invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", roleConfigInfo.fighterController, nil)) and invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", roleConfigInfo.fighterController.roleAnimtor, nil)) then
						roleConfigInfo.fighterController.roleAnimtor:SetTrigger("idle");
						if (roleConfigInfo.curRoleSetting ~= nil) then
--设置当前角色的方位和属性
							local roleWidth; roleWidth = ((roleConfigInfo.curRoleSetting.with * roleConfigInfo.curRoleSetting.size) * 1);
							local roleHeigh; roleHeigh = ((roleConfigInfo.curRoleSetting.height * roleConfigInfo.curRoleSetting.size) * 1);
--添加碰撞
							local collider; collider = GameUtility.CheckAndAddComponet(roleConfigInfo.gameObject, typeof(UnityEngine.BoxCollider));
							if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", collider, nil) then
								collider.size = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, roleWidth, roleHeigh, roleWidth);
								collider.center = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, 0.00, (roleHeigh * 0.50), 0.00);
							end;
						end;
					end;
				end));
			end,
			InitRoleModel = function(this, index, roleId)
				GameUtility.CreateFighterObj(roleId, 0, false, getexterninstanceindexer(this.HeroMountList, nil, "get_Item", index), (function(obj)
					obj.name = invokeforbasicvalue(roleId, false, System.Int32, "ToString");
					local roleConfigInfo; roleConfigInfo = obj:GetComponent(RoleConfigureInfo);
					if ((invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", roleConfigInfo, nil) and invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", roleConfigInfo.fighterController, nil)) and invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", roleConfigInfo.fighterController.roleAnimtor, nil)) then
						roleConfigInfo.fighterController.roleAnimtor:SetTrigger("sitidle");
						if (roleConfigInfo.curRoleSetting ~= nil) then
--设置当前角色的方位和属性
							local roleWidth; roleWidth = ((roleConfigInfo.curRoleSetting.with * roleConfigInfo.curRoleSetting.size) * 1);
							local roleHeigh; roleHeigh = ((roleConfigInfo.curRoleSetting.height * roleConfigInfo.curRoleSetting.size) * 1);
--添加碰撞
							local collider; collider = GameUtility.CheckAndAddComponet(roleConfigInfo.gameObject, typeof(UnityEngine.BoxCollider));
							if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", collider, nil) then
								collider.size = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, (roleWidth * this.coliderRate), (roleHeigh * this.coliderRate), (roleWidth * this.coliderRate));
								collider.center = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, 0.00, (collider.size.y * 0.50), 0.00);
							end;
						end;
					end;
					if (index < 2) then
						this._infoDic1:Add(index, roleConfigInfo);
					else
						this._infoDic2:Add(index, roleConfigInfo);
					end;
					this._infoStrDic:Add(roleId, roleConfigInfo);
				end));
			end,
			InvokeRepeatRoleAni1 = function(this)
				local tempInt; tempInt = UnityEngine.Random.Range(0, 4);
				if this._infoDic1:ContainsKey(tempInt) then
					getexterninstanceindexer(this._infoDic1, nil, "get_Item", tempInt).fighterController.roleAnimtor:SetTrigger("sitshow");
				end;
			end,
			InvokeRepeatRoleAni2 = function(this)
				local tempInt; tempInt = UnityEngine.Random.Range(0, 4);
				if this._infoDic2:ContainsKey(tempInt) then
					getexterninstanceindexer(this._infoDic2, nil, "get_Item", tempInt).fighterController.roleAnimtor:SetTrigger("sitshow");
				end;
			end,
			OnUpdate = function(this)
				this._titlePos._bookPos = this._camera:WorldToScreenPoint(this.bookPos.position);
				this._titlePos._settingPos = this._camera:WorldToScreenPoint(this.settingPos.position);
				this._titlePos._missionPos = this._camera:WorldToScreenPoint(this.missionPos.position);
				this._titlePos._physicalSignPos = this._camera:WorldToScreenPoint(invokeexternoperator(CS.UnityEngine.Vector3, "op_Addition", this.physicalSignPos.position, newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, 0, -0.79, 0)));
				if externdelegationcomparewithnil(false, false, "BaseSceneCom:_callBack", this, nil, "_callBack", false) then
					this._callBack(this._titlePos);
				end;
				this.base:OnUpdate();
			end,
			SetCameraTriggerToIdle = function(this, e)
				this:SetBaseSceneCameraTrigger("idle");
			end,
			SetBaseSceneCameraTrigger = function(this, str)
				this._camearAnimator._camearAnimator:Play(str);
			end,
			ClickScreenToRay = function(this, e)
				local ray; ray = this._camera:ScreenPointToRay(UnityEngine.Input.mousePosition);
--从摄像机发出到点击坐标的射线
--从摄像机发出到点击坐标的射线
				local hitInfo;
				if (function() local __compiler_invoke_291; __compiler_invoke_291, hitInfo = UnityEngine.Physics.Raycast(ray, 1000000.00, invokeintegeroperator(5, "<<", 1, UnityEngine.LayerMask.NameToLayer("GameUI"), System.Int32, System.Int32)); return __compiler_invoke_291; end)() then
					if invokeforbasicvalue(hitInfo.collider.gameObject.tag, false, System.String, "Equals", "GetPysical") then
						if Eight.Framework.EIFrameWork.GetState(4) then
							if externdelegationcomparewithnil(false, false, "BaseSceneCom:_onSignPhysicalCallBack", this, nil, "_onSignPhysicalCallBack", false) then
								this._onSignPhysicalCallBack(hitInfo.collider.gameObject);
							end;
						end;
					elseif invokeforbasicvalue(hitInfo.collider.gameObject.tag, false, System.String, "Equals", "Mission") then
						if (not FunctionOpenUtility.JudgeSingleFunctionById(se_functiontype.SE_FUNCTIONTYPE_MISSION_MODULE, true)) then
							return ;
						end;
						this:SetBaseSceneCameraTrigger("questboard");
					elseif invokeforbasicvalue(hitInfo.collider.gameObject.tag, false, System.String, "Equals", "Setting") then
						if (not FunctionOpenUtility.JudgeSingleFunctionById(se_functiontype.SE_FUNCTIONTYPE_SYSTEM_SETTTING_MODULE, true)) then
							return ;
						end;
						this:SetBaseSceneCameraTrigger("setting");
					elseif invokeforbasicvalue(hitInfo.collider.gameObject.tag, false, System.String, "Equals", "SignIn") then
						if (not FunctionOpenUtility.JudgeSingleFunctionById(se_functiontype.SE_FUNCTIONTYPE_SIGNIN_MOUDLE, true)) then
							return ;
						end;
						this:SetBaseSceneCameraTrigger("book");
					end;
--			Debug.DrawLine(ray.origin,hitInfo.point);//划出射线，只有在scene视图中才能看到
				elseif (function() local __compiler_invoke_312; __compiler_invoke_312, hitInfo = UnityEngine.Physics.Raycast(ray, 1000000.00, invokeintegeroperator(5, "<<", 1, UnityEngine.LayerMask.NameToLayer("Game"), System.Int32, System.Int32)); return __compiler_invoke_312; end)() then
					if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", hitInfo.collider.transform.parent.gameObject, this.ShowHeroMount) then
--sd_role_skin _skin = LogicStatic.Get<sd_role_skin>(_showrole_1);
--ClickVoice(_skin.sound_normal);
						Eight.Framework.EIFrameWork.Instance:DispatchEvent(newobject(Eight.Framework.EIEvent, "ctor__System_String__Eight_Framework_EIEvent_ReturnCallBack__System_Object__System_Single", nil, "MAIN_GO_PARTYPAGE", nil, typecast(this._curShowRolePartyId, System.Object, false), 0.00));
					elseif invokeforbasicvalue(hitInfo.collider.gameObject.name, false, System.String, "Equals", invokeforbasicvalue(this._roleId_3, false, System.Int32, "ToString")) then
						if this._infoStrDic:ContainsKey(this._roleId_3) then
							if this:IsSitshow(getexterninstanceindexer(this._infoStrDic, nil, "get_Item", this._roleId_3)) then
								return ;
							end;
							getexterninstanceindexer(this._infoStrDic, nil, "get_Item", this._roleId_3).fighterController.roleAnimtor:SetTrigger("sitshow");
							this:ClickVoice__System_Int32(this._roleId_3);
						end;
					elseif invokeforbasicvalue(hitInfo.collider.gameObject.name, false, System.String, "Equals", invokeforbasicvalue(this._roleId_4, false, System.Int32, "ToString")) then
						if this._infoStrDic:ContainsKey(this._roleId_4) then
							if this:IsSitshow(getexterninstanceindexer(this._infoStrDic, nil, "get_Item", this._roleId_4)) then
								return ;
							end;
							getexterninstanceindexer(this._infoStrDic, nil, "get_Item", this._roleId_4).fighterController.roleAnimtor:SetTrigger("sitshow");
							this:ClickVoice__System_Int32(this._roleId_4);
						end;
					elseif invokeforbasicvalue(hitInfo.collider.gameObject.name, false, System.String, "Equals", invokeforbasicvalue(this._roleId_1, false, System.Int32, "ToString")) then
						if this._infoStrDic:ContainsKey(this._roleId_1) then
							if this:IsSitshow(getexterninstanceindexer(this._infoStrDic, nil, "get_Item", this._roleId_1)) then
								return ;
							end;
							getexterninstanceindexer(this._infoStrDic, nil, "get_Item", this._roleId_1).fighterController.roleAnimtor:SetTrigger("sitshow");
							this:ClickVoice__System_Int32(this._roleId_1);
						end;
					elseif invokeforbasicvalue(hitInfo.collider.gameObject.name, false, System.String, "Equals", invokeforbasicvalue(this._roleId_2, false, System.Int32, "ToString")) then
						if this._infoStrDic:ContainsKey(this._roleId_2) then
							if this:IsSitshow(getexterninstanceindexer(this._infoStrDic, nil, "get_Item", this._roleId_2)) then
								return ;
							end;
							getexterninstanceindexer(this._infoStrDic, nil, "get_Item", this._roleId_2).fighterController.roleAnimtor:SetTrigger("sitshow");
							this:ClickVoice__System_Int32(this._roleId_2);
						end;
					end;
					Eight.Framework.EIDebuger.Log(("hitInfo :" + hitInfo.collider.transform.name));
				end;
			end,
			ClickVoice__System_Int32 = function(this, _id)
				local _fightData; _fightData = LogicStatic.Get__System_Predicate_T(typeof(EightGame.Data.Server.FighterSerData), (function(x) return (x.staticId == _id); end));
				local _skin; _skin = LogicStatic.Get__System_Int32(typeof(EightGame.Data.Server.sd_role_skin), _fightData.skin);
				if ((_skin ~= nil) and (not System.String.IsNullOrEmpty(_skin.sound_normal))) then
					this:ClickVoice__System_String(_skin.sound_normal);
				end;
			end,
			ClickVoice__System_String = function(this, _voiceName)
				GameUtility.PlaySound(_voiceName);
			end,
			IsSitshow = function(this, roleConfigInfo)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", roleConfigInfo.fighterController.roleAnimtor, nil) then
					return roleConfigInfo.fighterController.roleAnimtor:GetCurrentAnimatorStateInfo(0):IsName("sitshow");
				end;
				return true;
			end,
			ListenerPlayerChangeCloth = function(this, e)
				local intevent; intevent = typeas(e, Eight.Framework.EIIntEvent, false);
				if (not this._needReloadRoleIds:Contains(intevent.intParam)) then
					this._needReloadRoleIds:Add(intevent.intParam);
				end;
			end,
			CheckNeedReloadRole = function(this)
--先判断是否因为阵型数据变更需要重新加载
--再判断是否因为因为换装而需要重新加载
				if (not BaseSceneCom._needReloadRoleByLineup) then
					if ((this._needReloadRoleIds == nil) or (this._needReloadRoleIds.Count == 0)) then
						return ;
					end;
					if (this._infoStrDic.Count == 0) then
						return ;
					end;
					local reload; reload = false;
					for keyvalue in getiterator(this._infoStrDic) do
						if this._needReloadRoleIds:Contains(keyvalue.Key) then
--存在着需要换肤的角色，换它，好想偷懒，全部重新加载新
							reload = true;
						end;
					end;
					if (not reload) then
						return ;
					end;
				else
					BaseSceneCom._needReloadRoleByLineup = false;
				end;
				for keyvalue in getiterator(this._infoStrDic) do
					keyvalue.Value:Dispose();
					UnityEngine.Object.DestroyImmediate(keyvalue.Value.gameObject);
				end;
				this:StartCoroutine(this:DelayInitfo());
			end,
			DelayInitfo = function(this)
				wrapyield(nil, false, false);
				this:InitInfo();
			end),
			ResetRoleInfo = function(this)
				if ((this._infoStrDic == nil) or (this._infoStrDic.Count == 0)) then
					for keyvalue in getiterator(this._infoStrDic) do
						local roleConfigInfo; roleConfigInfo = keyvalue.Value;
						roleConfigInfo.fighterController.roleAnimtor:SetTrigger("sitidle");
--设置当前角色的方位和属性
						local roleWidth; roleWidth = ((roleConfigInfo.curRoleSetting.with * roleConfigInfo.curRoleSetting.size) * 1);
						local roleHeigh; roleHeigh = ((roleConfigInfo.curRoleSetting.height * roleConfigInfo.curRoleSetting.size) * 1);
--添加碰撞
						local collider; collider = GameUtility.CheckAndAddComponet(roleConfigInfo.gameObject, typeof(UnityEngine.BoxCollider));
						if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", collider, nil) then
							collider.size = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, roleWidth, roleHeigh, roleWidth);
							collider.center = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, 0.00, (roleHeigh * 0.50), 0.00);
						end;
					end;
				end;
			end,
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				_needReloadRoleIds = newexternlist(System.Collections.Generic.List_System.Int32, "System.Collections.Generic.List_System.Int32", "ctor", {}),
				HeroMountList = __cs2lua_nil_field_value,
				ShowHeroMount = __cs2lua_nil_field_value,
				_camera = __cs2lua_nil_field_value,
				_camearAnimator = __cs2lua_nil_field_value,
				bookPos = __cs2lua_nil_field_value,
				settingPos = __cs2lua_nil_field_value,
				missionPos = __cs2lua_nil_field_value,
				physicalSignPos = __cs2lua_nil_field_value,
				_titlePos = newobject(BaseSceneCom.TitlePos, "ctor", nil),
				_callBack = delegationwrap(),
				_onSignPhysicalCallBack = delegationwrap(),
				_infoDic1 = newexterndictionary(System.Collections.Generic.Dictionary_System.Int32_RoleConfigureInfo, "System.Collections.Generic.Dictionary_System.Int32_RoleConfigureInfo", "ctor", {}),
				_infoDic2 = newexterndictionary(System.Collections.Generic.Dictionary_System.Int32_RoleConfigureInfo, "System.Collections.Generic.Dictionary_System.Int32_RoleConfigureInfo", "ctor", {}),
				_infoStrDic = newexterndictionary(System.Collections.Generic.Dictionary_System.Int32_RoleConfigureInfo, "System.Collections.Generic.Dictionary_System.Int32_RoleConfigureInfo", "ctor", {}),
				_roleId_1 = 0,
				_roleId_2 = 0,
				_roleId_3 = 0,
				_roleId_4 = 0,
				_fight01 = "",
				_fight02 = "",
				_fight03 = "",
				_fight04 = "",
				_curShowRolePartyId = 0,
				coliderRate = 0.65,
				_showrole_1 = 0,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIUIBehaviour, "BaseSceneCom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};




BaseSceneCom.TitlePos = {
	__new_object = function(...)
		return newobject(BaseSceneCom.TitlePos, nil, nil, ...);
	end,
	__define_class = function()
		local static = BaseSceneCom.TitlePos;

		local static_methods = {
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			ctor = function(this)
				this:__ctor();
			end,
			__ctor = function(this)
				if this.__ctor_called then
					return;
				else
					this.__ctor_called = true;
				end
				this._bookPos = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", nil, nil);
				this._settingPos = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", nil, nil);
				this._missionPos = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", nil, nil);
				this._physicalSignPos = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", nil, nil);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				_bookPos = defaultvalue(UnityEngine.Vector3, "UnityEngine.Vector3", true),
				_settingPos = defaultvalue(UnityEngine.Vector3, "UnityEngine.Vector3", true),
				_missionPos = defaultvalue(UnityEngine.Vector3, "UnityEngine.Vector3", true),
				_physicalSignPos = defaultvalue(UnityEngine.Vector3, "UnityEngine.Vector3", true),
				__ctor_called = false,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(System.Object, "BaseSceneCom.TitlePos", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



BaseSceneCom.TitlePos.__define_class();
BaseSceneCom.__define_class();
