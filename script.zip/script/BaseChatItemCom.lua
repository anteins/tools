require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIUIBehaviour";
require "NGUITools";
require "Eight__Framework__EIFrameWork";
require "EightGame__Component__GameResources";
require "UICamera";
require "ChatMsgManager";

BaseChatItemCom = {
	__new_object = function(...)
		return newobject(BaseChatItemCom, nil, nil, ...);
	end,
	__define_class = function()
		local static = BaseChatItemCom;

		local static_methods = {
			cctor = function()
				EIUIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			SetPlayerNameLbl = function(this, namestr, colorStr)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._playerNameLbl, nil) then
					return ;
				end;
				this._playerNameLbl.text = System.String.Format("{0}{1}", colorStr, namestr);
			end,
			SetPlayerVipLbl = function(this, vipStr)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._playerVipLvLbl, nil) then
					return ;
				end;
				this._playerVipLvLbl.transform.parent.gameObject:SetActive((not invokeforbasicvalue(vipStr, false, System.String, "Equals", "0")));
				this._playerVipLvLbl.text = vipStr;
			end,
			SetPlayerLvLbl = function(this, lvStr)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._playerLvLbl, nil) then
					return ;
				end;
				this._playerLvLbl.gameObject:SetActive((not System.String.IsNullOrEmpty(lvStr)));
				this._playerLvLbl.text = lvStr;
			end,
			SetContentLbl = function(this, contentStr, callbackclick)
				if (invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._contentLbl, nil) or System.String.IsNullOrEmpty(contentStr)) then
					return ;
				end;
				this:SetContentLblActive(true);
				delegationset(false, false, "BaseChatItemCom:_callbackClickLbl", this, nil, "_callbackClickLbl", callbackclick);
				this._contentLbl.text = System.String.Format("[494242]{0}[-]", contentStr);
				local v2; v2 = this._contentLbl.printedSize;
				if (v2.x > 510) then
					v2.x = 490;
				end;
				this:SetContentBgSpriteWidth(invokeintegeroperator(2, "+", UnityEngine.Mathf.CeilToInt(v2.x), 15, System.Int32, System.Int32), invokeintegeroperator(2, "+", UnityEngine.Mathf.CeilToInt(this._contentLbl.height), 10, System.Int32, System.Int32));
				this:SetEmojiTextureActive(false);
				local bx; bx = NGUITools.AddMissingComponent(NGUITools, typeof(UnityEngine.BoxCollider), this._contentLbl.gameObject);
				bx.size = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, (v2.x + 30.00), (this._contentLbl.height + 30.00), 0);
				bx.center = newexternobject(UnityEngine.Vector3, "UnityEngine.Vector3", "ctor", nil, (v2.x / 2), 0, 0);
			end,
			SetContentBgSpriteWidth = function(this, width, height)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._contentBgSprite, nil) then
					return ;
				end;
				this._contentBgSprite.width = width;
				this._contentBgSprite.height = height;
			end,
			SetContentBgSprite = function(this, bgSprite)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._contentBgSprite, nil) then
					return ;
				end;
				this._contentBgSprite.spriteName = bgSprite;
			end,
			SetGenderSprite = function(this, gender)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._genderSprite, nil) then
					return ;
				end;
				this._genderSprite.spriteName = condexp(gender, true, "male", true, "female");
			end,
			SetSendMsgType = function(this, chattype)
				local str; str = "player";
				if (chattype == se_chattype.SE_CHATTYPE_CHATSYSTEM ) then
					str = "system";
				else
					str = "player";
				end;
				this:ForceSetSendMsgTypeSprite(str);
			end,
			ForceSetSendMsgTypeSprite = function(this, str)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this._sendMsgTypeSprite, nil) then
					this._sendMsgTypeSprite.spriteName = str;
				end;
			end,
			LoadParnerTexture = function(this, path)
				local c; c = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.GameResources):LoadAsyn(path, "png", true);
				wrapyield(c.coroutine, false, true);
				this._parnterIcon.mainTexture = typeas(c.res, UnityEngine.Texture2D, false);
			end),
			ClickLbl = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this._contentLbl, nil) then
					local url; url = this._contentLbl:GetUrlAtPosition__UnityEngine_Vector3(UICamera.lastHit.point);
					local t; t = ChatMsgManager.Instance:AnalysisURLContent(url);
					if externdelegationcomparewithnil(false, false, "BaseChatItemCom:_callbackClickLbl", this, nil, "_callbackClickLbl", false) then
						this._callbackClickLbl(t);
					end;
				end;
			end,
			LoadEmojiTexture = function(this, chatemoji)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._emojiTexture, nil) then
					return nil;
				end;
				this:SetEmojiTextureActive(true);
				local c; c = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.GameResources):LoadAsyn(("GameAssets/Textures/Icon/" + chatemoji.image), "png", true);
				wrapyield(c.coroutine, false, true);
				local tex; tex = typeas(c.res, UnityEngine.Texture2D, false);
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", tex, nil) then
					this._emojiTexture.mainTexture = tex;
				end;
				this:SetContentLblActive(false);
			end),
			SetContentLblActive = function(this, b)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._contentLbl, nil) then
					return ;
				end;
				this._contentLbl.gameObject:SetActive(b);
			end,
			SetEmojiTextureActive = function(this, b)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Equality", this._emojiTexture, nil) then
					return ;
				end;
				this._emojiTexture.gameObject:SetActive(b);
			end,
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				_playerNameLbl = __cs2lua_nil_field_value,
				_playerVipLvLbl = __cs2lua_nil_field_value,
				_parnterIcon = __cs2lua_nil_field_value,
				_playerLvLbl = __cs2lua_nil_field_value,
				_genderSprite = __cs2lua_nil_field_value,
				_contentLbl = __cs2lua_nil_field_value,
				_contentBgSprite = __cs2lua_nil_field_value,
				_emojiTexture = __cs2lua_nil_field_value,
				_sendMsgTypeSprite = __cs2lua_nil_field_value,
				_arrowSprite = __cs2lua_nil_field_value,
				_callbackClickLbl = delegationwrap(),
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIUIBehaviour, "BaseChatItemCom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



BaseChatItemCom.__define_class();
