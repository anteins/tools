-- //  **********************************************************************
-- //  Copyright  2015  EIGHT Team . All rights reserved.
-- //  File     : LotteryItemHaloCom.cs
-- //  Author   : wolforce
-- //  Created  : 2015/7/10  15:03 
-- //  Purpose  : 专门管理抽奖抽到的物品的背景特效.
-- //  **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIBehaviour";

LotteryItemHaloCom = {
	__new_object = function(...)
		return newobject(LotteryItemHaloCom, nil, nil, ...);
	end,
	__define_class = function()
		local static = LotteryItemHaloCom;

		local static_methods = {
			cctor = function()
				EIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			Init = function(this, curItemRank, openItemRank)
				local isEnable; isEnable = (curItemRank >= openItemRank);
				this.haloSprite.gameObject:SetActive(isEnable);
				if isEnable then
					this.haloSprite.spriteName = System.String.Format("halo_item_rank_{0}", curItemRank);
				end;
			end,
			Start = function(this)
			end,
			Update = function(this)
			end,
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				haloSprite = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIBehaviour, "LotteryItemHaloCom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LotteryItemHaloCom.__define_class();
