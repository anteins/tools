require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EightGame__Logic__UIDialogNode";
require "EightGame__Logic__DialogUI";
require "Eight__Framework__EIFrameWork";
require "EightGame__Component__GameResources";
require "NGUITools";
require "ChangeNamePopupUICom";
require "EventDelegate";
require "LogicStatic";
require "EightGame__Component__NetworkClient";
require "PlayerInfoUtil";
require "EightGame__Component__Statistical";
require "EightGame__Logic__CommonTipsParam";
require "Eight__Framework__EIEvent";

ChangeNameDialogNode = {
	__new_object = function(...)
		return newobject(ChangeNameDialogNode, "ctor", nil, ...);
	end,
	__define_class = function()
		local static = ChangeNameDialogNode;

		local static_methods = {
			Open = function()
				if (ChangeNameDialogNode._lastDialogID == -1) then
					EightGame.Logic.UIDialogNode.OpenIt(ChangeNameDialogNode, nil, (function() local __compiler_delegation_28 = (function(data) ChangeNameDialogNode._Private_OnOpen(data); end); setdelegationkey(__compiler_delegation_28, "ChangeNameDialogNode:_Private_OnOpen", ChangeNameDialogNode, ChangeNameDialogNode._Private_OnOpen); return __compiler_delegation_28; end)());
				end;
			end,
			Hide = function()
				if (ChangeNameDialogNode._lastDialogID ~= -1) then
					EightGame.Logic.UIDialogNode.HideIt(ChangeNameDialogNode, ChangeNameDialogNode._lastDialogID, (function() local __compiler_delegation_37 = (function(data) ChangeNameDialogNode._Private_OnHide(data); end); setdelegationkey(__compiler_delegation_37, "ChangeNameDialogNode:_Private_OnHide", ChangeNameDialogNode, ChangeNameDialogNode._Private_OnHide); return __compiler_delegation_37; end)());
				end;
			end,
			Close = function()
				if ((ChangeNameDialogNode._lastDialogID ~= -1) and (not EightGame.Logic.DialogUI.currentDialogUI.IsLock)) then
					EightGame.Logic.UIDialogNode.CloseIt(ChangeNameDialogNode, ChangeNameDialogNode._lastDialogID, (function() local __compiler_delegation_46 = (function(data) ChangeNameDialogNode._Private_OnClose(data); end); setdelegationkey(__compiler_delegation_46, "ChangeNameDialogNode:_Private_OnClose", ChangeNameDialogNode, ChangeNameDialogNode._Private_OnClose); return __compiler_delegation_46; end)());
					ChangeNameDialogNode._lastDialogID = -1;
				end;
			end,
			_Private_OnOpen = function(data)
				ChangeNameDialogNode._lastDialogID = typecast(data, System.Int32, false);
			end,
			_Private_OnHide = function(data)
			end,
			_Private_OnClose = function(data)
			end,
			cctor = function()
				EightGame.Logic.UIDialogNode.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				ondismiss = delegationwrap(),
				_lastDialogID = -1,
				ASSET_PATH = "NewWorld/PlayerInfo/changeNamePopup",
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			ctor = function(this)
				this.base.ctor(this);
				this._isReady = false;
				this:StartCoroutine(this:CreateAssets());
				return this;
			end,
			CreateAssets = function(this)
--下面是一段资源创建的示例, 请修改成你自己的//
				local coroutine; coroutine = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.GameResources):LoadAsyn("GameAssets/Prefabs/UI/NewWorld/PlayerInfo/changeNamePopup", "prefab", false);
				wrapyield(coroutine.coroutine, false, true);
				local prefab; prefab = typeas(coroutine.res, UnityEngine.GameObject, false);
				local obj; obj = NGUITools.AddChild__UnityEngine_GameObject__UnityEngine_GameObject(NGUITools, this.dialogParent.gameObject, prefab);
				this.popup = obj:GetComponent(ChangeNamePopupUICom);
				this:BindEvents();
				this:BindComponent__EIEntityBehaviour(this.popup);
--这里可以你自己的逻辑//
				this._isReady = true;
				return nil;
			end),
			OnEnter = function(this, data)
--在这里初始化你的gameobject脚本//
				return nil;
			end),
			OnExit = function(this)
				return nil;
			end),
			Dispose = function(this)
				ChangeNameDialogNode._lastDialogID = -1;
				if externdelegationcomparewithnil(false, true, "ChangeNameDialogNode:ondismiss", ChangeNameDialogNode, nil, "ondismiss", false) then
					ChangeNameDialogNode.ondismiss();
				end;
				this.popup = nil;
				return this.base:Dispose();
			end,
			BindEvents = function(this)
				EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.popup.nameInput.onChange, (function() local __compiler_delegation_123 = (function() this:OnInputChange(); end); setdelegationkey(__compiler_delegation_123, "ChangeNameDialogNode:OnInputChange", this, this.OnInputChange); return __compiler_delegation_123; end)());
				EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.popup.cancelBtn.onClick, (function()
					this:OnDissmissPopup();
				end));
				EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.popup.okBtn.onClick, (function()
					local name; name = invokeforbasicvalue(this.popup.nameInput.value, false, System.String, "Trim");
					if (getforbasicvalue(name, false, System.String, "Length") == 0) then
						this:ShowErrorMsg("请输入你的名字");
						return ;
					end;
					local player; player = LogicStatic.Get__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
					if (System.Text.Encoding.UTF8:GetString(player.name) == name) then
						this:ShowErrorMsg("新昵称不能与当前昵称相同");
						return ;
					end;
					if (not this._isNamePassCheck) then
						return ;
					end;
					local action; action = EightGame.Data.Server.ServerService.ChangenameMethod(System.Text.Encoding.UTF8:GetBytes(name));
					Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):NetworkRequest(action, (function() local __compiler_delegation_146 = (function(returnCode, response) this:OnChangeName(returnCode, response); end); setdelegationkey(__compiler_delegation_146, "ChangeNameDialogNode:OnChangeName", this, this.OnChangeName); return __compiler_delegation_146; end)(), true, false);
				end));
			end,
			OnInputChange = function(this)
				this._isNamePassCheck = false;
				local str; str = this.popup.nameInput.value;
				local charLimit; charLimit = this.popup.nameInput.characterLimit;
--检查特殊字符.
				if PlayerInfoUtil.CheckCharacterSpecial(str) then
					this:ShowErrorMsg("名字不能含有特殊字符");
					return ;
				end;
--检查敏感词.
				if PlayerInfoUtil.CheckBlackList(str) then
					this:ShowErrorMsg("名字不能含有非法词汇");
					return ;
				end;
				this:HideErrorMsg();
				this._isNamePassCheck = true;
			end,
			OnChangeName = function(this, returnCode, response)
				local res; res = typeas(response, EightGame.Data.Server.ChangeNameResponse, false);
				local msg; msg = "";
				if (returnCode < 1000) then
--统计钻石改名 [by breen]
					local player; player = Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.NetworkClient):GetDataByCls__System_Predicate_T(typeof(EightGame.Data.Server.PlayerSerData), nil);
					if ((player ~= nil) and (player.namehistory ~= nil)) then
						local nameHistory; nameHistory = System.Text.Encoding.UTF8:GetString(player.namehistory);
						if (getforbasicvalue(nameHistory, false, System.String, "Length") > 0) then
							local nameHistoryList; nameHistoryList = typeas(MiniJSON.Json.Deserialize(nameHistory), System.Collections.Generic.List_System.Object, false);
							if (nameHistoryList.Count > 0) then
								Eight.Framework.EIFrameWork.GetComponent(EightGame.Component.Statistical):RecordOtherPurchase("修改名字", 1, 150, se_currency.SE_CURRENCY_DIAMOND );
							end;
						end;
					end;
					local name; name = System.Text.Encoding.UTF8:GetString(res.name);
					msg = System.String.Format("昵称已成功修改为 {0}", name);
				else
					msg = EightGame.Component.NetCode.GetDesc(returnCode);
				end;
				this:ShowSimpleTip(msg);
				this:OnDissmissPopup();
			end,
			ShowSimpleTip = function(this, msg)
				local param; param = newobject(EightGame.Logic.CommonTipsParam, "ctor", nil, msg, 0, nil, nil, "");
--        param.action = true;
				param.isShowOKCancelBtn = false;
				this:DispatchEvent(newobject(Eight.Framework.EIEvent, "ctor__System_String__Eight_Framework_EIEvent_ReturnCallBack__System_Object__System_Single", nil, "UI_TIPS", nil, param, 0.00));
			end,
			ShowErrorMsg = function(this, msg)
				this.popup.errorTipLabel.text = msg;
				this.popup.errorTipLabel.gameObject:SetActive(true);
				this.popup.costTipGO:SetActive(false);
				this.popup.freeTipGO:SetActive(false);
			end,
			HideErrorMsg = function(this)
				this.popup.errorTipLabel.gameObject:SetActive(false);
				this.popup:SwitchCostTip();
			end,
			OnDissmissPopup = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this.popup, nil) then
					UnityEngine.Object.Destroy(this.popup.gameObject);
				end;
				ChangeNameDialogNode.Close();
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				popup = __cs2lua_nil_field_value,
				_isNamePassCheck = false,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = {
			"System.Collections.IEnumerable",
		};

		local interface_map = {
			IEnumerable_GetEnumerator = "EINode_GetEnumerator",
		};


		return defineclass(EightGame.Logic.UIDialogNode, "ChangeNameDialogNode", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



ChangeNameDialogNode.__define_class();
