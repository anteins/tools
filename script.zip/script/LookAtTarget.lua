require "cs2lua__utility";
require "cs2lua__attributes";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";

LookAtTarget = {
	__new_object = function(...)
		return newobject(LookAtTarget, nil, nil, ...);
	end,
	__define_class = function()
		local static = LookAtTarget;

		local static_methods = {
			cctor = function()
			end,
		};

		local static_fields_build = function()
			local static_fields = {
				__attributes = LookAtTarget__Attrs,
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			Start = function(this)
				this.mTrans = this.transform;
			end,
			LateUpdate = function(this)
				if invokeexternoperator(CS.UnityEngine.Object, "op_Inequality", this.target, nil) then
					local dir; dir = invokeexternoperator(CS.UnityEngine.Vector3, "op_Subtraction", this.target.position, this.mTrans.position);
					local mag; mag = dir.magnitude;
					if (mag > 0.00) then
						local lookRot; lookRot = UnityEngine.Quaternion.LookRotation(dir);
						this.mTrans.rotation = UnityEngine.Quaternion.Slerp(this.mTrans.rotation, lookRot, UnityEngine.Mathf.Clamp01((this.speed * UnityEngine.Time.deltaTime)));
					end;
				end;
			end,
			ctor = function(this)
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				level = 0,
				target = __cs2lua_nil_field_value,
				speed = 8.00,
				mTrans = __cs2lua_nil_field_value,
				__attributes = LookAtTarget__Attrs,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(UnityEngine.MonoBehaviour, "LookAtTarget", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



LookAtTarget.__define_class();
