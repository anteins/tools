-- **********************************************************************
-- Copyright   2015  EIGHT Team . All rights reserved.
-- File     :  BaseSceneAnimControlCom.cs
-- Author   : qbkira
-- Created  : 2015/1/27  上11:30 
-- Purpose  : 
-- **********************************************************************
require "cs2lua__utility";
require "cs2lua__namespaces";
require "cs2lua__externenums";
require "cs2lua__interfaces";
require "EIBehaviour";

BaseSceneAnimControlCom = {
	__new_object = function(...)
		return newobject(BaseSceneAnimControlCom, nil, nil, ...);
	end,
	__define_class = function()
		local static = BaseSceneAnimControlCom;

		local static_methods = {
			cctor = function()
				EIBehaviour.cctor(this);
			end,
		};

		local static_fields_build = function()
			local static_fields = {
			};
			return static_fields;
		end;
		local static_props = nil;
		local static_events = nil;

		local instance_methods = {
			ctor = function(this)
				this.base.ctor(this);
			end,
		};

		local instance_fields_build = function()
			local instance_fields = {
				StartAnimator = __cs2lua_nil_field_value,
			};
			return instance_fields;
		end;
		local instance_props = nil;
		local instance_events = nil;
		local interfaces = nil;
		local interface_map = nil;

		return defineclass(EIBehaviour, "BaseSceneAnimControlCom", static, static_methods, static_fields_build, static_props, static_events, instance_methods, instance_fields_build, instance_props, instance_events, interfaces, interface_map, false);
	end,
};



BaseSceneAnimControlCom.__define_class();
