
local this = nil
_lua_ChatEmojiLineControoler = BaseCom:New('_lua_ChatEmojiLineControoler')
function _lua_ChatEmojiLineControoler:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatEmojiLineControoler:SetData( cEnum, datalist, callbackClickEmoji)
	GameLog("------------------------------_lua_ChatEmojiLineControoler SetData------------------------------")
	this._dataList = datalist 
	this._callbackClickEmoji = callbackClickEmoji 
	this:InitModels() 
	this:InitDatas() 
end

function _lua_ChatEmojiLineControoler:InitModels()
	GameLog("------------------------------_lua_ChatEmojiLineControoler InitModels------------------------------")
	if (obj_len(this._itemModelList) > 0) then
		return  
	end 
	local index; index = 0;
	while (index < ChatEmojiLineControoler._eachLineItemCount) do
		local go; go = GameUtility.InstantiateGameObject(this._itemModelPrefab, this._grid.gameObject, CS.System.String.Format("{0}{1}", "item", index));
		go.gameObject:SetActive(false) 
		local com; com = go:GetComponent("ChatEmojiItemCom");
		this._itemModelList:Add(com) 
	index = index+1  
	end 
end

function _lua_ChatEmojiLineControoler:InitDatas()
	GameLog("------------------------------_lua_ChatEmojiLineControoler InitDatas------------------------------")
	local index; index = 0;
	while (index < obj_len(this._itemModelList)) do
		if (index < obj_len(this._dataList)) then
			local itemserdata; itemserdata = DictGetValue(this._dataList, index);
			if (itemserdata == nil) then
				DictGetValue(this._itemModelList, index).gameObject:SetActive(false) 
				return  
			end 
			DictGetValue(this._itemModelList, index).gameObject:SetActive(true) 
			NGUITools.AddWidgetCollider__UnityEngine_GameObject(DictGetValue(this._itemModelList, index).gameObject) 
			DictGetValue(this._itemModelList, index):SetData(DictGetValue(this._dataList, index), function(com) this:CallbackClickEmoji(com) end) 
		else
			DictGetValue(this._itemModelList, index).gameObject:SetActive(false) 
		end 
	index = index+1  
	end 
	this._grid.repositionNow = true 
end

function _lua_ChatEmojiLineControoler:CallbackClickEmoji( com)
	GameLog("------------------------------_lua_ChatEmojiLineControoler CallbackClickEmoji------------------------------")
	if this ~= "_callbackClickEmoji" then
		this._callbackClickEmoji(com) 
	end 
end

function _lua_ChatEmojiLineControoler:hotfix()
	xlua.hotfix(ChatEmojiLineControoler, {
       ['SetData'] = function(this, cEnum, datalist, callbackClickEmoji)
           _lua_ChatEmojiLineControoler:Ref(this)
           return _lua_ChatEmojiLineControoler:SetData( cEnum, datalist, callbackClickEmoji)
       end,
       ['InitModels'] = function(this)
           _lua_ChatEmojiLineControoler:Ref(this)
           return _lua_ChatEmojiLineControoler:InitModels()
       end,
       ['InitDatas'] = function(this)
           _lua_ChatEmojiLineControoler:Ref(this)
           return _lua_ChatEmojiLineControoler:InitDatas()
       end,
       ['CallbackClickEmoji'] = function(this, com)
           _lua_ChatEmojiLineControoler:Ref(this)
           return _lua_ChatEmojiLineControoler:CallbackClickEmoji( com)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatEmojiLineControoler)