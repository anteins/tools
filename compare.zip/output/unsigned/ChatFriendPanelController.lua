
local this = nil
_lua_ChatFriendPanelController = BaseCom:New('_lua_ChatFriendPanelController')
function _lua_ChatFriendPanelController:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatFriendPanelController:SetData( callbackSelcetFriend, callbackClose)
	GameLog("------------------------------_lua_ChatFriendPanelController SetData------------------------------")
	if not isnil(this._uiRecycledList) then
		this._uiRecycledList.onUpdateItem =  (function(go, prefabIndex, dataindex) this:OnUpdateItem(go, prefabIndex, dataindex) end) 
	end 
	this._callbackClose = callbackClose 
	this._callbackSelectFriend = callbackSelcetFriend 
	CS.Eight.Framework.EIFrameWork.StartCoroutine(this:LoadItemPrefab(), false) 
end

function _lua_ChatFriendPanelController:LoadItemPrefab()
	GameLog("------------------------------_lua_ChatFriendPanelController LoadItemPrefab------------------------------")
	if isnil(this._itemPrefab) then
		local coroutine; coroutine = XLuaScriptUtils.GameResources():LoadAsyn(CS.System.String.Format("{0}{1}", "GameAssets/Prefabs/UI/", this._itemPrefabPath), "prefab", false);
		if coroutine.coroutine then
coroutine.yield(coroutine.coroutine)
end
		this._itemPrefab = coroutine.res 
	end 
	if not isnil(this._itemPrefab) then
		if (obj_len(this._applicationItemDic) == 0) then
			local index; index = 0;
			while (index < 7) do
				local go; go = GameUtility.InstantiateGameObject(this._itemPrefab, this._uiRecycledList.gameObject, ("Friend" .. index));
				local r; r = go:GetComponent("ChatFriendItemCom");
				this._applicationItemDic:Add(go, r) 
				go.gameObject:SetActive(false) 
			index = index+1  
			end 
		end 
	end 
	this:RequestFriendSerData((function(obj)
		if ((obj == nil) or (obj_len(obj) == 0)) then
			this:SetTipActive(true) 
			this._allDatas:Clear() 
			this._uiRecycledList:UpdateDataCount(0, false) 
		else
			this:SetTipActive(false) 
			this._allDatas = obj 
			this._uiRecycledList:UpdateDataCount(obj_len(this._allDatas), false) 
		end 
	end)) 
end

function _lua_ChatFriendPanelController:OnUpdateItem( go, prefabIndex, dataindex)
	GameLog("------------------------------_lua_ChatFriendPanelController OnUpdateItem------------------------------")
	if ((this._allDatas == nil) or (obj_len(this._allDatas) == 0)) then
		return  
	end 
	local com; com = nil;
	if (function() local __compiler_invoke_128  __compiler_invoke_128, com = this._applicationItemDic:TryGetValue(go)  return __compiler_invoke_128  end)() then
		if isnil(com) then
			return  
		end 
		if ((obj_len(this._allDatas) > 0) and (dataindex < obj_len(this._allDatas))) then
			com:SetData(DictGetValue(this._allDatas, dataindex), function(friendSerData) this:CallbackSelectFriend(friendSerData) end) 
		end 
	end 
end

function _lua_ChatFriendPanelController:CallbackSelectFriend( friendSerData)
	GameLog("------------------------------_lua_ChatFriendPanelController CallbackSelectFriend------------------------------")
	if this ~= "_callbackSelectFriend" then
		this._callbackSelectFriend(friendSerData) 
	end 
end

function _lua_ChatFriendPanelController:OnClickClose()
	GameLog("------------------------------_lua_ChatFriendPanelController OnClickClose------------------------------")
	if not isnil(this) then
		this.gameObject:SetActive(false) 
	end 
	if this ~= "_callbackClose" then
		this._callbackClose() 
	end 
end

function _lua_ChatFriendPanelController:SetTipActive( b)
	GameLog("------------------------------_lua_ChatFriendPanelController SetTipActive------------------------------")
	if isnil(this._tipLbl) then
		return  
	end 
	this._tipLbl.gameObject:SetActive(b) 
end

function _lua_ChatFriendPanelController:hotfix()
	xlua.hotfix(ChatFriendPanelController, {
       ['SetData'] = function(this, callbackSelcetFriend, callbackClose)
           _lua_ChatFriendPanelController:Ref(this)
           return _lua_ChatFriendPanelController:SetData( callbackSelcetFriend, callbackClose)
       end,
       ['LoadItemPrefab'] = function(this)
           _lua_ChatFriendPanelController:Ref(this)
           return util.cs_generator(function()
               _lua_ChatFriendPanelController:LoadItemPrefab()
           end)
       end,
       ['OnUpdateItem'] = function(this, go, prefabIndex, dataindex)
           _lua_ChatFriendPanelController:Ref(this)
           return _lua_ChatFriendPanelController:OnUpdateItem( go, prefabIndex, dataindex)
       end,
       ['CallbackSelectFriend'] = function(this, friendSerData)
           _lua_ChatFriendPanelController:Ref(this)
           return _lua_ChatFriendPanelController:CallbackSelectFriend( friendSerData)
       end,
       ['OnClickClose'] = function(this)
           _lua_ChatFriendPanelController:Ref(this)
           return _lua_ChatFriendPanelController:OnClickClose()
       end,
       ['SetTipActive'] = function(this, b)
           _lua_ChatFriendPanelController:Ref(this)
           return _lua_ChatFriendPanelController:SetTipActive( b)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatFriendPanelController)