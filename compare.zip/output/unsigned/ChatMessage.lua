
local this = nil
_lua_ChatMessage = BaseCom:New('_lua_ChatMessage')
function _lua_ChatMessage:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatMessage:hotfix()
end

table.insert(g_tbHotfix, _lua_ChatMessage)