
local this = nil
_lua_ClubCreatePageUI = BaseCom:New('_lua_ClubCreatePageUI')
function _lua_ClubCreatePageUI:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubCreatePageUI:Init()
	GameLog("------------------------------_lua_ClubCreatePageUI Init------------------------------")
	EventDelegate.Add(this.CreataBt.onClick, function() this:ToCreate() end) 
	EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.CancleBt.onClick, function() this:ToCancle() end) 
end

function _lua_ClubCreatePageUI:ToCreate()
	GameLog("------------------------------_lua_ClubCreatePageUI ToCreate------------------------------")
	if FunctionOpenUtility.JudgeSingleFunctionById(se_functiontype.SE_FUNCTIONTYPE_GUILD_GREAT, true) then
		if this.IsCreat then
			return  
		end 
		this.IsCreat = true 
		this:HideErrorMsg() 
		this:OnInputChange() 
		if (not this.IsNameCheck) then
			this.IsCreat = false 
			return  
		end 
		local srv; srv = XLuaScriptUtils.ServiceCenter():GetService(typeof(CS.EightGame.Component.ClubService));
		local request; request = CS.EightGame.Data.Server.SendNewGuildRequest();
		srv:SendNewGuildRequest(request, (function(arg1)
			this.IsCreat = false 
			local errorc; errorc = arg1;
			if (errorc ~= 200) then
				local _tipstr; _tipstr = CS.EightGame.Component.NetCode.GetDesc(errorc);
				local param; param = CS.EightGame.Logic.TipStruct(_tipstr,0.20) ;
				CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_FLOATING_TIPS",nil,param,0.00) ) 
			else
				CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("GO_CLUB_SENCE",nil,nil,0.00) ) 
			end 
		end), nil) 
	end 
end

function _lua_ClubCreatePageUI:OnInputChange()
	GameLog("------------------------------_lua_ClubCreatePageUI OnInputChange------------------------------")
	this.IsNameCheck = false 
	local str; str = Trim(this.NameInput.value);
	local charLimit; charLimit = this.NameInput.characterLimit;
	if CS.System.String.IsNullOrEmpty(str) then
		this:ShowErrorMsg("名字不能为空") 
		return  
	end 
	if PlayerInfoUtil.CheckCharacterSpecial(str) then
		this:ShowErrorMsg("名字不能含有特殊字符") 
		return  
	end 
	if PlayerInfoUtil.CheckBlackList(str) then
		this:ShowErrorMsg("名字不能含有非法词汇") 
		return  
	end 
	if ClubUtility.IsClubRename(str) then
		this:ShowErrorMsg("该名称已被占有") 
		return  
	end 
	this.IsNameCheck = true 
end

function _lua_ClubCreatePageUI:ShowErrorMsg( msg)
	GameLog("------------------------------_lua_ClubCreatePageUI ShowErrorMsg------------------------------")
	this.ErrorLab.text = msg 
	this.ErrorLab.gameObject:SetActive(true) 
end

function _lua_ClubCreatePageUI:HideErrorMsg()
	GameLog("------------------------------_lua_ClubCreatePageUI HideErrorMsg------------------------------")
	this.ErrorLab.gameObject:SetActive(false) 
end

function _lua_ClubCreatePageUI:ToCancle()
	GameLog("------------------------------_lua_ClubCreatePageUI ToCancle------------------------------")
	if this.IsCreat then
		this.IsCreat = false 
		return  
	end 
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("OUT_CLUB_CREAT",nil,nil,0.00) ) 
end

function _lua_ClubCreatePageUI:hotfix()
	xlua.hotfix(ClubCreatePageUI, {
       ['Init'] = function(this)
           _lua_ClubCreatePageUI:Ref(this)
           return _lua_ClubCreatePageUI:Init()
       end,
       ['ToCreate'] = function(this)
           _lua_ClubCreatePageUI:Ref(this)
           return _lua_ClubCreatePageUI:ToCreate()
       end,
       ['OnInputChange'] = function(this)
           _lua_ClubCreatePageUI:Ref(this)
           return _lua_ClubCreatePageUI:OnInputChange()
       end,
       ['ShowErrorMsg'] = function(this, msg)
           _lua_ClubCreatePageUI:Ref(this)
           return _lua_ClubCreatePageUI:ShowErrorMsg( msg)
       end,
       ['HideErrorMsg'] = function(this)
           _lua_ClubCreatePageUI:Ref(this)
           return _lua_ClubCreatePageUI:HideErrorMsg()
       end,
       ['ToCancle'] = function(this)
           _lua_ClubCreatePageUI:Ref(this)
           return _lua_ClubCreatePageUI:ToCancle()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubCreatePageUI)