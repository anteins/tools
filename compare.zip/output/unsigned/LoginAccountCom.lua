
local this = nil
_lua_LoginAccountCom = BaseCom:New('_lua_LoginAccountCom')
function _lua_LoginAccountCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LoginAccountCom:set_SetCurrentObj( value)
	GameLog("------------------------------_lua_LoginAccountCom set_SetCurrentObj------------------------------")
	this.GameCurryContainer = value 
end

function _lua_LoginAccountCom:get_IsLoginAgain()
	GameLog("------------------------------_lua_LoginAccountCom get_IsLoginAgain------------------------------")
	return this._isAgain 
end

function _lua_LoginAccountCom:SetFieldActive( on)
	GameLog("------------------------------_lua_LoginAccountCom SetFieldActive------------------------------")
	if not isnil(this.GameObjectFieldContainer) then
		this.GameObjectFieldContainer:SetActive(on) 
	end 
	if not isnil(this.GameCurryContainer) then
		this.GameCurryContainer:SetActive(on) 
	end 
end

function _lua_LoginAccountCom:SetLatestAccount( latestAccount)
	GameLog("------------------------------_lua_LoginAccountCom SetLatestAccount------------------------------")
	if CS.System.String.IsNullOrEmpty(latestAccount) then
		latestAccount = "" 
		this._isAgain = false 
	else
		this._isAgain = true 
	end 
	this.LabelAccount.value = latestAccount 
	this.CurryAccout.text = latestAccount 
	this.LabelAccount:UpdateLabel() 
end

function _lua_LoginAccountCom:LoginAccount()
	GameLog("------------------------------_lua_LoginAccountCom LoginAccount------------------------------")
	if (obj_len(this.LabelAccount.value) == 0) then
		this:ShowFloatTip("请输入账号！") 
		return  
	end 
	local userInfo; userInfo = CS.EightGame.Logic.LoginUserParam("eichannel_empty","eichannel_empty",this.LabelAccount.value,"null") ;
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("LOGIN_SDK_ACCOUNT_SUCCESS",nil,userInfo,0.00) ) 
end

function _lua_LoginAccountCom:LoginOut()
	GameLog("------------------------------_lua_LoginAccountCom LoginOut------------------------------")
	this.LabelPassword.value = "" 
	this.LabelPassword:UpdateLabel() 
end

function _lua_LoginAccountCom:GetAccountObj()
	GameLog("------------------------------_lua_LoginAccountCom GetAccountObj------------------------------")
	return this.AccountObj 
end

function _lua_LoginAccountCom:ShowFloatTip( msg)
	GameLog("------------------------------_lua_LoginAccountCom ShowFloatTip------------------------------")
	local param; param = CS.EightGame.Logic.TipStruct(msg,0.20) ;
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_FLOATING_TIPS",nil,param,0.00) ) 
end

function _lua_LoginAccountCom:hotfix()
	xlua.hotfix(LoginAccountCom, {
       ['SetFieldActive'] = function(this, on)
           _lua_LoginAccountCom:Ref(this)
           return _lua_LoginAccountCom:SetFieldActive( on)
       end,
       ['SetLatestAccount'] = function(this, latestAccount)
           _lua_LoginAccountCom:Ref(this)
           return _lua_LoginAccountCom:SetLatestAccount( latestAccount)
       end,
       ['LoginAccount'] = function(this)
           _lua_LoginAccountCom:Ref(this)
           return _lua_LoginAccountCom:LoginAccount()
       end,
       ['LoginOut'] = function(this)
           _lua_LoginAccountCom:Ref(this)
           return _lua_LoginAccountCom:LoginOut()
       end,
       ['GetAccountObj'] = function(this)
           _lua_LoginAccountCom:Ref(this)
           return _lua_LoginAccountCom:GetAccountObj()
       end,
       ['ShowFloatTip'] = function(this, msg)
           _lua_LoginAccountCom:Ref(this)
           return _lua_LoginAccountCom:ShowFloatTip( msg)
       end,
   })
end

table.insert(g_tbHotfix, _lua_LoginAccountCom)