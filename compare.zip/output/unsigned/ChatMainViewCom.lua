
local this = nil
_lua_ChatMainViewCom = BaseCom:New('_lua_ChatMainViewCom')
function _lua_ChatMainViewCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatMainViewCom:get_showFriend()
	GameLog("------------------------------_lua_ChatMainViewCom get_showFriend------------------------------")
	return this._showFriend 
end

function _lua_ChatMainViewCom:set_showFriend( value)
	GameLog("------------------------------_lua_ChatMainViewCom set_showFriend------------------------------")
	this._showFriend = value 
	this:SetChatFriendActive(this._showFriend) 
end

function _lua_ChatMainViewCom:Init( callbackClickChatBtn)
	GameLog("------------------------------_lua_ChatMainViewCom Init------------------------------")
	this._sendMsgLock = false 
	this._callbackClickChatBtn = callbackClickChatBtn 
	if not isnil(this._openChatBtn) then
		this._openChatBtn.gameObject:SetActive(false) 
	end 
	this:SetChatViewActive(false) 
	this:InitChatItemComList() 
	this._uiRecycledList.onUpdateItem =  (function(go, itemIndex, dataindex) this:OnUpdateItem(go, itemIndex, dataindex) end) 
	this:InitChannel() 
	this:RegisterEvent() 
	this:SetOpenChatBtnActive(false) 
	this:SetOpenChatBtnRedActive((ChatMsgManager.Instance:GetUnReadPrivateMsgs().Count > 0)) 
end

function _lua_ChatMainViewCom:RegisterEvent()
	GameLog("------------------------------_lua_ChatMainViewCom RegisterEvent------------------------------")
	if not isnil(this._openChatBtn) then
		EventDelegate.Set__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this._openChatBtn.onClick, function() this:ClickOpenChatBtn() end) 
	end 
	if not isnil(this._showBtn) then
		EventDelegate.Set__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this._showBtn.onClick, function() this:CallbackClickShowBtn() end) 
	end 
	if not isnil(this._closeBtn) then
		EventDelegate.Set__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this._closeBtn.onClick, function() this:CallbackClickCloseBtn() end) 
	end 
	if not isnil(this._emonticonBtn) then
		EventDelegate.Set__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this._emonticonBtn.onClick, function() this:CallbackClickEmonticonBtn() end) 
	end 
	if not isnil(this._sendBtn) then
		EventDelegate.Set__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this._sendBtn.onClick, function() this:OnSubmitBtn() end) 
	end 
	if not isnil(this._uiInput) then
		this._uiInput.characterLimit = ChatMsgManager.Instance._cachMsgCount 
	end 
end

function _lua_ChatMainViewCom:OnSubmitBtn()
	GameLog("------------------------------_lua_ChatMainViewCom OnSubmitBtn------------------------------")
	if (not ChatMsgManager.Instance:JudgeSendCondition(nil, this._uiInput.value)) then
		return  
	end 
	this:ClearSendMsg() 
	this:UpdateSendMsg("") 
	this:SendMsg() 
end

function _lua_ChatMainViewCom:ClickOpenChatBtn()
	GameLog("------------------------------_lua_ChatMainViewCom ClickOpenChatBtn------------------------------")
	if this ~= "_callbackClickChatBtn" then
		this._callbackClickChatBtn() 
	end 
end

function _lua_ChatMainViewCom:SetOpenChatBtnActive( b)
	GameLog("------------------------------_lua_ChatMainViewCom SetOpenChatBtnActive------------------------------")
	if isnil(this._openChatBtn) then
		return  
	end 
	this._openChatBtn.gameObject:SetActive(b) 
end

function _lua_ChatMainViewCom:SetOpenChatBtnRedActive( b)
	GameLog("------------------------------_lua_ChatMainViewCom SetOpenChatBtnRedActive------------------------------")
	if isnil(this._openChatBtn) then
		return  
	end 
	local gotr; gotr = this._openChatBtn.transform:FindChild("PointSprite");
	if isnil(gotr) then
		return  
	end 
	gotr.gameObject:SetActive(b) 
end

function _lua_ChatMainViewCom:CloseChat()
	GameLog("------------------------------_lua_ChatMainViewCom CloseChat------------------------------")
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIBoolEvent("SET_CLUB_CAMERA",false) ) 
	this:SetOpenChatBtnActive(false) 
	this:SetChatViewActive(false) 
	this:ChatViewMoveInOut(false) 
	this:SetChatExplainActive(false) 
end

function _lua_ChatMainViewCom:OpenChatView()
	GameLog("------------------------------_lua_ChatMainViewCom OpenChatView------------------------------")
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIBoolEvent("SET_CLUB_CAMERA",true) ) 
	this._sendMsgLock = false 
	this:SetChatViewActive(true) 
	this:SetOpenChatBtnActive(false) 
	this:ChatViewMoveInOut(true) 
	this:SetEmojiBtnState() 
	this._getChatSysMessageNotify = ChatMsgManager.Instance:GetChatSysMessageNotifyData() 
	if (this._getChatSysMessageNotify ~= nil) then
		if not isnil(this._latestChanelCom) then
			this._latestChanelCom:SetBgSprite(false) 
			this._latestChanelCom = nil 
		end 
		local com; com = this:GetChannelComByEnum(se_chattype.SE_CHATTYPE_CHATWORLD );
		if isnil(com) then
			return  
		end 
		this:CallbackSelectChannel(com) 
		com:SetChannelLbl(CS.System.String.Format("世界频道CH.{0}", this._getChatSysMessageNotify.chanelId)) 
		this:SetCurActionLbl(CS.System.String.Format("[{0}]世界频道-[-][{1}]CH.{2}", "FFD988", "5CF5FF", this._getChatSysMessageNotify.chanelId)) 
		local priCom; priCom = this:GetChannelComByEnum(se_chattype.SE_CHATTYPE_CHATPRIVATE );
		if isnil(priCom) then
			return  
		end 
		priCom:SetUnreadSpriteActive((ChatMsgManager.Instance:GetUnReadPrivateMsgs().Count > 0)) 
	end 
end

function _lua_ChatMainViewCom:ChatViewMoveInOut( moveIn)
	GameLog("------------------------------_lua_ChatMainViewCom ChatViewMoveInOut------------------------------")
	if isnil(this._chatView) then
		return  
	end 
	local twp; twp = UITweener.Begin(TweenPosition, this._chatView.gameObject, 0.30);
	if moveIn then
		twp.from = CS.UnityEngine.Vector3(-678.50,-562.00,0) 
		twp.to = CS.UnityEngine.Vector3(0,-562.00,0) 
	else
		twp.from = CS.UnityEngine.Vector3(0,-562.00,0) 
		twp.to = CS.UnityEngine.Vector3(-678.50,-562.00,0) 
	end 
	twp:Play() 
end

function _lua_ChatMainViewCom:InitChannel()
	GameLog("------------------------------_lua_ChatMainViewCom InitChannel------------------------------")
	if (obj_len(this._cacheChatChannelList) > 0) then
		local enumlist; enumlist = ChatMsgManager.Instance:GetAllChatChannels();
		local index; index = 0;
		while (index < obj_len(this._cacheChatChannelList)) do
			if (index < obj_len(enumlist)) then
				DictGetValue(this._cacheChatChannelList, index).gameObject:SetActive(true) 
				DictGetValue(this._cacheChatChannelList, index):SetData(DictGetValue(enumlist, index), function(channelcom) this:CallbackSelectChannel(channelcom) end) 
			else
				DictGetValue(this._cacheChatChannelList, index).gameObject:SetActive(false) 
			end 
		index = index+1  
		end 
	end 
end

function _lua_ChatMainViewCom:InitChatItemComList()
	GameLog("------------------------------_lua_ChatMainViewCom InitChatItemComList------------------------------")
	if (obj_len(this._applicationItemDic) == 0) then
		local index; index = 0;
		while (index < 10) do
			local go; go = NGUITools.AddChild__UnityEngine_GameObject__UnityEngine_GameObject(NGUITools, this._uiRecycledList.gameObject, this._chatItemPrefab.gameObject);
			local com; com = go:GetComponent("ChatItemCom");
			this._applicationItemDic:Add(go, com) 
		index = index+1  
		end 
	end 
end

function _lua_ChatMainViewCom:GetChatSysMessageByChanid( chanid)
	GameLog("------------------------------_lua_ChatMainViewCom GetChatSysMessageByChanid------------------------------")
	local index; index = 0;
	while (index < obj_len(this._getChatSysMessageNotify.msgList)) do
		if (DictGetValue(this._getChatSysMessageNotify.msgList, index).word_room_id == chanid) then
			return DictGetValue(this._getChatSysMessageNotify.msgList, index) 
		end 
	index = index+1  
	end 
	return nil 
end

function _lua_ChatMainViewCom:UpdateAllChatMsgs( friendId)
	GameLog("------------------------------_lua_ChatMainViewCom UpdateAllChatMsgs------------------------------")
	this._allChatMessage:Clear() 
	this._allChatMessage:AddRange(ChatMsgManager.Instance:GetAllChatMessageByChannel(this._currentChanelEnum, friendId)) 
end

function _lua_ChatMainViewCom:CallbackCloseFriend()
	GameLog("------------------------------_lua_ChatMainViewCom CallbackCloseFriend------------------------------")
	this._showFriend = false 
end

function _lua_ChatMainViewCom:CallbackSelectWorldChanel( msg)
	GameLog("------------------------------_lua_ChatMainViewCom CallbackSelectWorldChanel------------------------------")
	if (msg.word_room_id == this._getChatSysMessageNotify.chanelId) then
		return  
	end 
	if this._lockChangeWorldChannel then
		CS.EightGame.Logic.FloatingTextTipUIRoot.SetFloattingTip("请稍后", 0.00) 
		return  
	end 
	this._lockChangeWorldChannel = true 
	local param; param = CS.EightGame.Data.Server.ChatChangeWorldChanelParam();
	param.chanelId = msg.word_room_id 
	local srv; srv = XLuaScriptUtils.ServiceCenter():GetService(typeof(CS.EightGame.Component.ChatSerice));
	srv:ChangeWorldChanel(param, (function(obj)
		this._lockChangeWorldChannel = false 
		if (obj ~= 200) then
			CS.EightGame.Logic.FloatingTextTipUIRoot.SetFloattingTip(CS.EightGame.Component.NetCode.GetDesc(obj), 0.00) 
			return  
		end 
		ChatMsgManager.Instance:ClearWorldChannelMsg() 
		this:UpdateAllChatMsgs(0) 
		this:RecycledListMoveTo() 
		local com; com = this:GetChannelComByEnum(se_chattype.SE_CHATTYPE_CHATWORLD );
		if isnil(com) then
			return  
		end 
		com:SetChannelLbl(CS.System.String.Format("世界频道CH.{0}", msg.word_room_id)) 
		this:SetCurActionLbl(CS.System.String.Format("[{0}]世界频道-[-][{1}]CH.{2}", "FFD988", "5CF5FF", msg.word_room_id)) 
		this:SetChatWorldActive(false) 
		CS.EightGame.Logic.FloatingTextTipUIRoot.SetFloattingTip(CS.System.String.Format("进入CH.{0}成功", msg.word_room_id), 0.00) 
	end), nil) 
end

function _lua_ChatMainViewCom:CallbackFriendItem( friendSerdata)
	GameLog("------------------------------_lua_ChatMainViewCom CallbackFriendItem------------------------------")
	local com; com = this:GetChannelComByEnum(se_chattype.SE_CHATTYPE_CHATPRIVATE );
	if isnil(com) then
		return  
	end 
	this._curFriendSerData = friendSerdata 
	com:SetChannelLbl(friendSerdata.name) 
	this.showFriend = false 
	this:UpdateAllChatMsgs(friendSerdata.fid) 
	this:RecycledListMoveTo() 
	this:SetInputEnable(this:CheckPreCondition(false)) 
	local b; b = (ChatMsgManager.Instance:GetUnReadPrivateMsgs().Count > 0);
	com:SetUnreadSpriteActive(b) 
	this:SetOpenChatBtnRedActive(b) 
	this:SetInputDefaultLbl("请点击输入") 
	this:SetCurActionLbl(CS.System.String.Format("[{0}]私聊频道-[-][{1}]{2}[-]", "FFD988", "5CF5FF", friendSerdata.name)) 
end

function _lua_ChatMainViewCom:GetChannelComByEnum( cEnum)
	GameLog("------------------------------_lua_ChatMainViewCom GetChannelComByEnum------------------------------")
	local com; com = nil;
	local index; index = 0;
	while (index < obj_len(this._cacheChatChannelList)) do
		if (DictGetValue(this._cacheChatChannelList, index)._chatChannelEnum == cEnum) then
			com = DictGetValue(this._cacheChatChannelList, index) 
		end 
	index = index+1  
	end 
	return com 
end

function _lua_ChatMainViewCom:SetChatFriendActive( b)
	GameLog("------------------------------_lua_ChatMainViewCom SetChatFriendActive------------------------------")
	if isnil(this._chatFriendPanelController) then
		return  
	end 
	this._chatFriendPanelController.gameObject:SetActive(b) 
end

function _lua_ChatMainViewCom:SetChatWorldActive( b)
	GameLog("------------------------------_lua_ChatMainViewCom SetChatWorldActive------------------------------")
	if isnil(this._chatWorldChanelController) then
		return  
	end 
	this._chatWorldChanelController.gameObject:SetActive(b) 
end

function _lua_ChatMainViewCom:InitChatData()
	GameLog("------------------------------_lua_ChatMainViewCom InitChatData------------------------------")
end

function _lua_ChatMainViewCom:LoadPrefab()
	GameLog("------------------------------_lua_ChatMainViewCom LoadPrefab------------------------------")
	if isnil(this._chatItemPrefab) then
		local coroutine; coroutine = XLuaScriptUtils.GameResources():LoadAsyn(CS.System.String.Format("{0}{1}", "GameAssets/Prefabs/UI/", this._chatItemPrefabPath), "prefab", false);
		if coroutine.coroutine then
coroutine.yield(coroutine.coroutine)
end
		this._chatItemPrefab = coroutine.res 
	end 
end

function _lua_ChatMainViewCom:OnUpdateItem( go, itemIndex, dataindex)
	GameLog("------------------------------_lua_ChatMainViewCom OnUpdateItem------------------------------")
	NGUITools.AddMissingComponent(go, UIDragScrollView) 
	NGUITools.AddWidgetCollider__UnityEngine_GameObject(go) 
	local box; box = NGUITools.AddMissingComponent(go, typeof(CS.UnityEngine.BoxCollider));
	box.size = CS.UnityEngine.Vector3(600.00,100.00,0) 
	local com; com = nil;
	local __compiler_invoke_620; __compiler_invoke_620, com = this._applicationItemDic:TryGetValue(go);
	if not isnil(com) then
		if (dataindex < obj_len(this._allChatMessage)) then
			com:SetData(DictGetValue(this._allChatMessage, dataindex), function(msg) this:CallbackClickLbl(msg) end) 
		end 
	end 
end

function _lua_ChatMainViewCom:CallbackClickEmonticonBtn()
	GameLog("------------------------------_lua_ChatMainViewCom CallbackClickEmonticonBtn------------------------------")
	this._chatEmojiItemCom = nil 
	if this._chatEmojiPanelController.gameObject.activeSelf then
		this._chatEmojiPanelController.gameObject:SetActive(false) 
	else
		this._chatEmojiPanelController.gameObject:SetActive(true) 
		this._chatEmojiPanelController:SetData(function(com) this:CallbackSelectEmoji(com) end) 
	end 
	this:SetShowPanelActive(false) 
end

function _lua_ChatMainViewCom:CallbackSelectEmoji( com)
	GameLog("------------------------------_lua_ChatMainViewCom CallbackSelectEmoji------------------------------")
	if this._chatEmojiItemCom == com then
		this:ClearSendMsg() 
		local str; str = ChatMsgManager.Instance:JoinItemContent(com._chatemoji);
		this._sendMsg = str 
		this:SendMsg() 
		this._chatEmojiItemCom = nil 
		return  
	end 
	this._chatEmojiItemCom = com 
end

function _lua_ChatMainViewCom:CallbackClickShowBtn()
	GameLog("------------------------------_lua_ChatMainViewCom CallbackClickShowBtn------------------------------")
	this._selectItem = nil 
	if this._chatShowPanelController.gameObject.activeSelf then
		this:SetShowPanelActive(false) 
	else
		this:SetShowPanelActive(true) 
		if not isnil(this._chatShowPanelController) then
			this._chatShowPanelController:SetData(function(obj) this:CallbackSelectItem(obj) end) 
		end 
	end 
	this._chatEmojiPanelController.gameObject:SetActive(false) 
end

function _lua_ChatMainViewCom:CallbackClickCloseBtn()
	GameLog("------------------------------_lua_ChatMainViewCom CallbackClickCloseBtn------------------------------")
	if this ~= "_callbackClickChatBtn" then
		this._callbackClickChatBtn() 
	end 
end

function _lua_ChatMainViewCom:SetShowPanelActive( b)
	GameLog("------------------------------_lua_ChatMainViewCom SetShowPanelActive------------------------------")
	if isnil(this._chatShowPanelController) then
		return  
	end 
	this._chatShowPanelController.gameObject:SetActive(b) 
end

function _lua_ChatMainViewCom:ResetSendMsg()
	GameLog("------------------------------_lua_ChatMainViewCom ResetSendMsg------------------------------")
	this:ClearSendMsg() 
	this._uiInput.value = "" 
	this._uiInput:RemoveFocus() 
end

function _lua_ChatMainViewCom:ListenerMsgAdd( e)
	GameLog("------------------------------_lua_ChatMainViewCom ListenerMsgAdd------------------------------")
	local chatmsg; chatmsg = e.extraInfo;
	if (not this._chatView.activeSelf) then
		local b; b = (ChatMsgManager.Instance:GetUnReadPrivateMsgs().Count > 0);
		this:SetOpenChatBtnRedActive(b) 
		return  
	end 
	if (this._currentChanelEnum == se_chattype.SE_CHATTYPE_CHATWORLD ) then
		if ((chatmsg.chattype == se_chattype.SE_CHATTYPE_CHATWORLD ) or (chatmsg.chattype == se_chattype.SE_CHATTYPE_CHATSYSTEM )) then
			ListExtension.Push(this._allChatMessage, ChatMessage, chatmsg) 
			if (obj_len(this._allChatMessage) > ChatMsgManager.Instance._cachMsgCount) then
				ListExtension.DequeueHead(this._allChatMessage, ChatMessage) 
			end 
			this:UpdateChatList() 
		end 
	elseif (chatmsg.chattype == this._currentChanelEnum) then
		if (this._currentChanelEnum == se_chattype.SE_CHATTYPE_CHATPRIVATE ) then
			if (this._curFriendSerData ~= nil) then
				if ((chatmsg.toplayerid == this._curFriendSerData.fid) or (chatmsg.playerid == this._curFriendSerData.fid)) then
					ListExtension.Push(this._allChatMessage, ChatMessage, chatmsg) 
					if (obj_len(this._allChatMessage) > ChatMsgManager.Instance._cachMsgCount) then
						ListExtension.DequeueHead(this._allChatMessage, ChatMessage) 
					end 
					this:UpdateChatList() 
				end 
			end 
		else
			ListExtension.Push(this._allChatMessage, ChatMessage, chatmsg) 
			if (obj_len(this._allChatMessage) > ChatMsgManager.Instance._cachMsgCount) then
				ListExtension.DequeueHead(this._allChatMessage, ChatMessage) 
			end 
			this:UpdateChatList() 
		end 
	end 
	if (chatmsg.chattype == se_chattype.SE_CHATTYPE_CHATPRIVATE ) then
		if (this._currentChanelEnum ~= se_chattype.SE_CHATTYPE_CHATPRIVATE ) then
			local com; com = this:GetChannelComByEnum(se_chattype.SE_CHATTYPE_CHATPRIVATE );
			local b; b = (ChatMsgManager.Instance:GetUnReadPrivateMsgs().Count > 0);
			if not isnil(com) then
				com:SetUnreadSpriteActive(b) 
			end 
			this:SetOpenChatBtnRedActive(b) 
		else
			if (this._curFriendSerData ~= nil) then
				if ((chatmsg.playerid ~= this._curFriendSerData.fid) and (chatmsg.toplayerid ~= this._curFriendSerData.fid)) then
					local com; com = this:GetChannelComByEnum(se_chattype.SE_CHATTYPE_CHATPRIVATE );
					local b; b = (ChatMsgManager.Instance:GetUnReadPrivateMsgs().Count > 0);
					if not isnil(com) then
						com:SetUnreadSpriteActive(b) 
					end 
					this:SetOpenChatBtnRedActive(b) 
				else
					ChatMsgManager.Instance:ClearUnReadPrivateChatMsg(this._curFriendSerData.fid) 
				end 
			end 
		end 
	end 
end

function _lua_ChatMainViewCom:UpdateChatList()
	GameLog("------------------------------_lua_ChatMainViewCom UpdateChatList------------------------------")
	if not isnil(this._uiRecycledList) then
		local needMove; needMove = (this._uiRecycledList.publicdatacount ~= obj_len(this._allChatMessage));
		this._uiRecycledList:UpdateDataCount(obj_len(this._allChatMessage), (obj_len(this._allChatMessage) < 7)) 
		if ((obj_len(this._allChatMessage) > 7) and needMove) then
			local index; index = obj_len(this._allChatMessage)-7 ;
			SpringPanel.Begin(this._uiRecycledList.Panel.gameObject, CS.UnityEngine.Vector3(0,(this._uiRecycledList.Panel.transform.localPosition.y + this._uiRecycledList.itemSize),0), 6.00) 
		end 
	end 
end

function _lua_ChatMainViewCom:SetInputLbl( valuestr)
	GameLog("------------------------------_lua_ChatMainViewCom SetInputLbl------------------------------")
	if isnil(this._uiInput) then
		return  
	end 
	this._uiInput.value = valuestr 
end

function _lua_ChatMainViewCom:SetInputDefaultLbl( defaultStr)
	GameLog("------------------------------_lua_ChatMainViewCom SetInputDefaultLbl------------------------------")
	if isnil(this._uiInput) then
		return  
	end 
	this:SetInputLbl("") 
	this._uiInput.defaultText = CS.System.String.Format("[B7B3B1]{0}", defaultStr) 
	this._uiInput.label.supportEncoding = true 
end

function _lua_ChatMainViewCom:SetInputFocus( b)
	GameLog("------------------------------_lua_ChatMainViewCom SetInputFocus------------------------------")
	if isnil(this._uiInput) then
		return  
	end 
	if (not b) then
		this._uiInput:RemoveFocus() 
	end 
end

function _lua_ChatMainViewCom:SetInputEnable( b)
	GameLog("------------------------------_lua_ChatMainViewCom SetInputEnable------------------------------")
	if isnil(this._uiInput) then
		return  
	end 
	this._uiInput:GetComponent(typeof(CS.UnityEngine.BoxCollider)).enabled = b 
end

function _lua_ChatMainViewCom:CallbackSelectItem( obj)
	GameLog("------------------------------_lua_ChatMainViewCom CallbackSelectItem------------------------------")
	if (this._selectItem ~= nil) then
		if isequal(this._selectItem, obj) then
			if (not ChatMsgManager.Instance:JudgeSendCondition(obj, this._uiInput.value)) then
				return  
			end 
			this:ClearSendMsg() 
			local str; str = ChatMsgManager.Instance:JoinItemContent(obj);
			this:UpdateSendMsg(str) 
			this:SendMsg() 
			this:SetChatExplainActive(false) 
			this:SetSendTipActive(false) 
			this._selectItem = nil 
			return  
		end 
	end 
	this._selectItem = obj 
	this:SetChatExplainActive(true) 
	this:SetSendTipActive(true) 
	this._chatExplainController:SetData__System_Object(obj) 
end

function _lua_ChatMainViewCom:UpdateSendMsg( str)
	GameLog("------------------------------_lua_ChatMainViewCom UpdateSendMsg------------------------------")
	this._sendMsg = CS.System.String.Format("{0}{1}{2}", this._uiInput.value, this._sendMsg, str) 
end

function _lua_ChatMainViewCom:SetSendTipActive( b)
	GameLog("------------------------------_lua_ChatMainViewCom SetSendTipActive------------------------------")
	if isnil(this._sendTipLbl) then
		return  
	end 
	this._sendTipLbl.gameObject:SetActive(b) 
end

function _lua_ChatMainViewCom:ClickChatExplainAction( e)
	GameLog("------------------------------_lua_ChatMainViewCom ClickChatExplainAction------------------------------")
	this:SetChatExplainActive(false) 
	this:SetSendTipActive(false) 
end

function _lua_ChatMainViewCom:SetChatExplainActive( b)
	GameLog("------------------------------_lua_ChatMainViewCom SetChatExplainActive------------------------------")
	if isnil(this._chatExplainController) then
		return  
	end 
	this._chatExplainController.gameObject:SetActive(b) 
end

function _lua_ChatMainViewCom:SetChatSubGroupActive( b)
	GameLog("------------------------------_lua_ChatMainViewCom SetChatSubGroupActive------------------------------")
	if not isnil(this._chatSubBtnController) then
		this._chatSubBtnController.gameObject:SetActive(b) 
	end 
end

function _lua_ChatMainViewCom:ClearSendMsg()
	GameLog("------------------------------_lua_ChatMainViewCom ClearSendMsg------------------------------")
	this._sendMsg = "" 
end

function _lua_ChatMainViewCom:RecycledListMoveTo()
	GameLog("------------------------------_lua_ChatMainViewCom RecycledListMoveTo------------------------------")
	local moveto; moveto = (( obj_len(this._allChatMessage)-7  ) > 0) and (function() return ( obj_len(this._allChatMessage)-7  ); end) or 0;
	local b; b = (moveto == 0);
	this._uiRecycledList.ScrollView:ResetPosition() 
	this._uiRecycledList:UpdateDataCount(obj_len(this._allChatMessage), true) 
	if (not b) then
		this._uiRecycledList:MoveTo__System_Int32__System_Boolean(moveto, true) 
	end 
end

function _lua_ChatMainViewCom:SetCurActionLbl( str)
	GameLog("------------------------------_lua_ChatMainViewCom SetCurActionLbl------------------------------")
	if isnil(this._curActionLbl) then
		return  
	end 
	this._curActionLbl.text = str 
end

function _lua_ChatMainViewCom:CheckPreCondition( showtip)
	GameLog("------------------------------_lua_ChatMainViewCom CheckPreCondition------------------------------")
	if (this._currentChanelEnum == se_chattype.SE_CHATTYPE_CHATWORLD ) then
		return FunctionOpenUtility.JudgeSingleFunctionById(se_functiontype.SE_FUNCTIONTYPE_CHAT_WORLD_MODULE , showtip) 
	elseif (this._currentChanelEnum == se_chattype.SE_CHATTYPE_CHATPRIVATE ) then
		return FunctionOpenUtility.JudgeSingleFunctionById(se_functiontype.SE_FUNCTIONTYPE_CHAT_FRIEND_MODULE , showtip) 
	elseif (this._currentChanelEnum == se_chattype.SE_CHATTYPE_CHATUNION ) then
		return FunctionOpenUtility.JudgeSingleFunctionById(se_functiontype.SE_FUNCTIONTYPE_CHAT_UNION_MODULE , showtip) 
	end 
	return false 
end

function _lua_ChatMainViewCom:UnRegisterEvent()
	GameLog("------------------------------_lua_ChatMainViewCom UnRegisterEvent------------------------------")
	CS.Eight.Framework.EIFrameWork.Instance:RemoveEventListener(ChatMsgManager.Instance.CHAT_MSG_ADD) 
	CS.Eight.Framework.EIFrameWork.Instance:RemoveEventListener(ChatExplainController.CLICK_CHATEXPLAIN_ACTION) 
end

function _lua_ChatMainViewCom:SetChatViewActive( b)
	GameLog("------------------------------_lua_ChatMainViewCom SetChatViewActive------------------------------")
	if isnil(this._chatView) then
		return  
	end 
	this._chatView.transform.parent.gameObject:SetActive(b) 
end

function _lua_ChatMainViewCom:hotfix()
	xlua.hotfix(ChatMainViewCom, {
       ['Init'] = function(this, callbackClickChatBtn)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:Init( callbackClickChatBtn)
       end,
       ['RegisterEvent'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:RegisterEvent()
       end,
       ['OnSubmitBtn'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:OnSubmitBtn()
       end,
       ['ClickOpenChatBtn'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:ClickOpenChatBtn()
       end,
       ['SetOpenChatBtnActive'] = function(this, b)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetOpenChatBtnActive( b)
       end,
       ['SetOpenChatBtnRedActive'] = function(this, b)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetOpenChatBtnRedActive( b)
       end,
       ['CloseChat'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:CloseChat()
       end,
       ['OpenChatView'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:OpenChatView()
       end,
       ['ChatViewMoveInOut'] = function(this, moveIn)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:ChatViewMoveInOut( moveIn)
       end,
       ['InitChannel'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:InitChannel()
       end,
       ['InitChatItemComList'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:InitChatItemComList()
       end,
       ['GetChatSysMessageByChanid'] = function(this, chanid)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:GetChatSysMessageByChanid( chanid)
       end,
       ['UpdateAllChatMsgs'] = function(this, friendId)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:UpdateAllChatMsgs( friendId)
       end,
       ['CallbackCloseFriend'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:CallbackCloseFriend()
       end,
       ['CallbackSelectWorldChanel'] = function(this, msg)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:CallbackSelectWorldChanel( msg)
       end,
       ['CallbackFriendItem'] = function(this, friendSerdata)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:CallbackFriendItem( friendSerdata)
       end,
       ['GetChannelComByEnum'] = function(this, cEnum)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:GetChannelComByEnum( cEnum)
       end,
       ['SetChatFriendActive'] = function(this, b)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetChatFriendActive( b)
       end,
       ['SetChatWorldActive'] = function(this, b)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetChatWorldActive( b)
       end,
       ['InitChatData'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:InitChatData()
       end,
       ['LoadPrefab'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return util.cs_generator(function()
               _lua_ChatMainViewCom:LoadPrefab()
           end)
       end,
       ['OnUpdateItem'] = function(this, go, itemIndex, dataindex)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:OnUpdateItem( go, itemIndex, dataindex)
       end,
       ['CallbackClickEmonticonBtn'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:CallbackClickEmonticonBtn()
       end,
       ['CallbackSelectEmoji'] = function(this, com)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:CallbackSelectEmoji( com)
       end,
       ['CallbackClickShowBtn'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:CallbackClickShowBtn()
       end,
       ['CallbackClickCloseBtn'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:CallbackClickCloseBtn()
       end,
       ['SetShowPanelActive'] = function(this, b)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetShowPanelActive( b)
       end,
       ['ResetSendMsg'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:ResetSendMsg()
       end,
       ['ListenerMsgAdd'] = function(this, e)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:ListenerMsgAdd( e)
       end,
       ['UpdateChatList'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:UpdateChatList()
       end,
       ['SetInputLbl'] = function(this, valuestr)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetInputLbl( valuestr)
       end,
       ['SetInputDefaultLbl'] = function(this, defaultStr)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetInputDefaultLbl( defaultStr)
       end,
       ['SetInputFocus'] = function(this, b)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetInputFocus( b)
       end,
       ['SetInputEnable'] = function(this, b)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetInputEnable( b)
       end,
       ['CallbackSelectItem'] = function(this, obj)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:CallbackSelectItem( obj)
       end,
       ['UpdateSendMsg'] = function(this, str)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:UpdateSendMsg( str)
       end,
       ['SetSendTipActive'] = function(this, b)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetSendTipActive( b)
       end,
       ['ClickChatExplainAction'] = function(this, e)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:ClickChatExplainAction( e)
       end,
       ['SetChatExplainActive'] = function(this, b)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetChatExplainActive( b)
       end,
       ['SetChatSubGroupActive'] = function(this, b)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetChatSubGroupActive( b)
       end,
       ['ClearSendMsg'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:ClearSendMsg()
       end,
       ['RecycledListMoveTo'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:RecycledListMoveTo()
       end,
       ['SetCurActionLbl'] = function(this, str)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetCurActionLbl( str)
       end,
       ['CheckPreCondition'] = function(this, showtip)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:CheckPreCondition( showtip)
       end,
       ['UnRegisterEvent'] = function(this)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:UnRegisterEvent()
       end,
       ['SetChatViewActive'] = function(this, b)
           _lua_ChatMainViewCom:Ref(this)
           return _lua_ChatMainViewCom:SetChatViewActive( b)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatMainViewCom)