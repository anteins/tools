
local this = nil
_lua_ChatChannelCom = BaseCom:New('_lua_ChatChannelCom')
function _lua_ChatChannelCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatChannelCom:SetData( chatenum, callbaclSelect)
	GameLog("------------------------------_lua_ChatChannelCom SetData------------------------------")
	this._chatChannelEnum = chatenum 
	this._callbackSelect = callbaclSelect 
	this:SetBgSprite(false) 
	this:SetUnreadSpriteActive(false) 
	local __compiler_switch_29 = this._chatChannelEnum;
	if __compiler_switch_29 == se_chattype.SE_CHATTYPE_CHATWORLD then
		this._defaultTex = "世界频道" 
	elseif __compiler_switch_29 == se_chattype.SE_CHATTYPE_CHATPRIVATE then
		this:SetUnreadSpriteActive((ChatMsgManager.Instance:GetUnReadPrivateMsgs().Count > 0)) 
		this._defaultTex = "好友聊天" 
	elseif __compiler_switch_29 == se_chattype.SE_CHATTYPE_CHATSYSTEM then
		this._defaultTex = "系统消息" 
	elseif __compiler_switch_29 == se_chattype.SE_CHATTYPE_CHATUNION then
		this._defaultTex = "冒险团聊天" 
	end 
	this:SetChannelLbl(this._defaultTex) 
end

function _lua_ChatChannelCom:OnClick()
	GameLog("------------------------------_lua_ChatChannelCom OnClick------------------------------")
	if this ~= "_callbackSelect" then
		this._callbackSelect(this) 
	end 
end

function _lua_ChatChannelCom:SetChannelLbl( str)
	GameLog("------------------------------_lua_ChatChannelCom SetChannelLbl------------------------------")
	if isnil(this._channelLbl) then
		return  
	end 
	this._defaultTex = str 
	this._channelLbl.text = CS.System.String.Format("{0}{1}", this._defaultColr, str) 
end

function _lua_ChatChannelCom:SetUnreadSpriteActive( b)
	GameLog("------------------------------_lua_ChatChannelCom SetUnreadSpriteActive------------------------------")
	if isnil(this._unreadSprite) then
		return  
	end 
	this._unreadSprite.gameObject:SetActive(b) 
end

function _lua_ChatChannelCom:hotfix()
	xlua.hotfix(ChatChannelCom, {
       ['SetData'] = function(this, chatenum, callbaclSelect)
           _lua_ChatChannelCom:Ref(this)
           return _lua_ChatChannelCom:SetData( chatenum, callbaclSelect)
       end,
       ['OnClick'] = function(this)
           _lua_ChatChannelCom:Ref(this)
           return _lua_ChatChannelCom:OnClick()
       end,
       ['SetChannelLbl'] = function(this, str)
           _lua_ChatChannelCom:Ref(this)
           return _lua_ChatChannelCom:SetChannelLbl( str)
       end,
       ['SetUnreadSpriteActive'] = function(this, b)
           _lua_ChatChannelCom:Ref(this)
           return _lua_ChatChannelCom:SetUnreadSpriteActive( b)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatChannelCom)