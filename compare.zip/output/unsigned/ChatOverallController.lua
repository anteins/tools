
local this = nil
_lua_ChatOverallController = BaseCom:New('_lua_ChatOverallController')
function _lua_ChatOverallController:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatOverallController:ReceiveMessage( notify)
	GameLog("------------------------------_lua_ChatOverallController ReceiveMessage------------------------------")
	ChatMsgManager.Instance:ReceiveMessage(notify) 
end

function _lua_ChatOverallController:ReceiveSysMessage( notify)
	GameLog("------------------------------_lua_ChatOverallController ReceiveSysMessage------------------------------")
	ChatMsgManager.Instance:ReceiveSysMessage(notify) 
end

function _lua_ChatOverallController:ReceiveKeyWordMessage( notify)
	GameLog("------------------------------_lua_ChatOverallController ReceiveKeyWordMessage------------------------------")
	ChatMsgManager.Instance:ReceiveKeyWordMessage(notify) 
end

function _lua_ChatOverallController:hotfix()
	xlua.hotfix(ChatOverallController, {
       ['ReceiveMessage'] = function(this, notify)
           _lua_ChatOverallController:Ref(this)
           return _lua_ChatOverallController:ReceiveMessage( notify)
       end,
       ['ReceiveSysMessage'] = function(this, notify)
           _lua_ChatOverallController:Ref(this)
           return _lua_ChatOverallController:ReceiveSysMessage( notify)
       end,
       ['ReceiveKeyWordMessage'] = function(this, notify)
           _lua_ChatOverallController:Ref(this)
           return _lua_ChatOverallController:ReceiveKeyWordMessage( notify)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatOverallController)