
local this = nil
_lua_ClubApplyerListPageUI = BaseCom:New('_lua_ClubApplyerListPageUI')
function _lua_ClubApplyerListPageUI:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubApplyerListPageUI:Init()
	GameLog("------------------------------_lua_ClubApplyerListPageUI Init------------------------------")
	this:InitObjs() 
	delegationadd(false, false, "UIRecycledList:onUpdateItem", this.BrRecyced, nil, "onUpdateItem", function(item, itemIndex, dataIndex) this:OnUpdata(item, itemIndex, dataIndex) end) 
	EventDelegate.Add(this.CloseBt.onClick, function() this:OnClose() end) 
end

function _lua_ClubApplyerListPageUI:OnClose()
	GameLog("------------------------------_lua_ClubApplyerListPageUI OnClose------------------------------")
	ClubApplyerListDialogNode.Close() 
end

function _lua_ClubApplyerListPageUI:OnUpdata( item, itemIndex, dataIndex)
	GameLog("------------------------------_lua_ClubApplyerListPageUI OnUpdata------------------------------")
	local _Sui; _Sui = nil;
	if (function() local __compiler_invoke_40  __compiler_invoke_40, _Sui = this.dataDic:TryGetValue(item)  return __compiler_invoke_40  end)() then
		if ((obj_len(this.ApplyerList) > 0) and (dataIndex < obj_len(this.ApplyerList))) then
			_Sui = item:GetComponent("SingleClubApplyerUI") 
			_Sui:SetUp(DictGetValue(this.ApplyerList, dataIndex)) 
		end 
	end 
end

function _lua_ClubApplyerListPageUI:InitObjs()
	GameLog("------------------------------_lua_ClubApplyerListPageUI InitObjs------------------------------")
	if (obj_len(this.dataDic) == 0) then
		local i; i = 0;
		while (i < 7) do
			local obj; obj = NGUITools.AddChild__UnityEngine_GameObject__UnityEngine_GameObject(NGUITools, this.BrRecyced.gameObject, this.SingleSample);
			local com; com = obj:GetComponent("SingleClubApplyerUI");
			obj.name = CS.System.String.Format("c_appler_{0}", i) 
			obj:SetActive(true) 
			com:Init() 
			this.dataDic:Add(obj, com) 
		i = i+1  
		end 
	end 
end

function _lua_ClubApplyerListPageUI:hotfix()
	xlua.hotfix(ClubApplyerListPageUI, {
       ['Init'] = function(this)
           _lua_ClubApplyerListPageUI:Ref(this)
           return _lua_ClubApplyerListPageUI:Init()
       end,
       ['OnClose'] = function(this)
           _lua_ClubApplyerListPageUI:Ref(this)
           return _lua_ClubApplyerListPageUI:OnClose()
       end,
       ['OnUpdata'] = function(this, item, itemIndex, dataIndex)
           _lua_ClubApplyerListPageUI:Ref(this)
           return _lua_ClubApplyerListPageUI:OnUpdata( item, itemIndex, dataIndex)
       end,
       ['InitObjs'] = function(this)
           _lua_ClubApplyerListPageUI:Ref(this)
           return _lua_ClubApplyerListPageUI:InitObjs()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubApplyerListPageUI)