
local this = nil
_lua_ClubBossReadyPageUI = BaseCom:New('_lua_ClubBossReadyPageUI')
function _lua_ClubBossReadyPageUI:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubBossReadyPageUI:Init()
	GameLog("------------------------------_lua_ClubBossReadyPageUI Init------------------------------")
	CS.UIEventListener.Get(this.MyRewardBoxTex.gameObject).onPress =  (function(_obj, b) ClubUtility.OnPress(_obj, b) end) 
	EventDelegate.Add(this.BattleMoreBt.onClick, function() this:OnBuyMoreBattleTime() end) 
	EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.BattleReadyBt.onClick, function() this:OnBeBattle() end) 
	EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.ShowDescBt.onClick, function() this:OnShowRankList() end) 
	EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.PointTakeBtn.onClick, function() this:OnPointTakeBtn() end) 
	EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(this.PointViewBtn.onClick, function() this:OnPointViewBtn() end) 
	this.FirstSimpleRank:Init() 
	this.SecendSimpleRank:Init() 
	this.ThirdSimpleRank:Init() 
	this.MySimpleRank:Init() 
end

function _lua_ClubBossReadyPageUI:SetEndTimeClock( endtime)
	GameLog("------------------------------_lua_ClubBossReadyPageUI SetEndTimeClock------------------------------")
	AlarmManager.Instance:set("ClubBossEndClock", endtime, (function(start, cur, __compiler_lua_end)
		local remainTime; remainTime = ( __compiler_lua_end-cur  );
		this.EndTimeLab.text = CS.System.String.Format("讨伐结束时间   {0}", SpecialPartyTipsUIcom.ConvertCountDownToTime(remainTime)) 
	end), (function()
		this.BattleReadyBt.gameObject:SetActive(false) 
		this.OverObjs:SetActive(true) 
		this.BattleMoreBt.gameObject:SetActive(false) 
		this.EndTimeLab.text = "讨伐结束" 
		this.BattleMoreBt.gameObject:SetActive(false) 
	end)) 
end

function _lua_ClubBossReadyPageUI:CheckBossTime( _bossData)
	GameLog("------------------------------_lua_ClubBossReadyPageUI CheckBossTime------------------------------")
	local issucces, isend;
	if (CS.System.Convert.ToInt32(_bossData.bosshp) == 0) then
		issucces = true 
		isend = false 
		return issucces, isend 
	else
		local curtime; curtime = AlarmManager.Instance:currentTimeMillis();
		isend = (_bossData.closetime < curtime) 
		issucces = false 
		return issucces, isend 
	end 
	return issucces, isend 
end

function _lua_ClubBossReadyPageUI:ResetThings()
	GameLog("------------------------------_lua_ClubBossReadyPageUI ResetThings------------------------------")
	this.BattleReadyBt.gameObject:SetActive(false) 
	this.OverObjs:SetActive(false) 
	this.SuccesObj:SetActive(false) 
	this.FailObj:SetActive(false) 
end

function _lua_ClubBossReadyPageUI:OnShowRankList()
	GameLog("------------------------------_lua_ClubBossReadyPageUI OnShowRankList------------------------------")
	BossRanksWindowNode.Open(this.NowRanks) 
end

function _lua_ClubBossReadyPageUI:SendReliveRequest()
	GameLog("------------------------------_lua_ClubBossReadyPageUI SendReliveRequest------------------------------")
	local srv; srv = XLuaScriptUtils.ServiceCenter():GetService(typeof(CS.EightGame.Component.ClubService));
	local request; request = CS.EightGame.Data.Server.SendDeathRequest();
	srv:SendDeathRequest(request, (function(returnCode)
		local msg; msg = "";
		if (CS.System.Convert.ToInt32(returnCode) == 200) then
			msg = "复活成功" 
		else
			msg = CS.EightGame.Component.NetCode.GetDesc(returnCode) 
		end 
		CS.EightGame.Logic.FloatingTextTipUIRoot.SetFloattingTip(msg, 0.00) 
	end), nil) 
end

function _lua_ClubBossReadyPageUI:OnPointTakeBtn()
	GameLog("------------------------------_lua_ClubBossReadyPageUI OnPointTakeBtn------------------------------")
	local srv; srv = XLuaScriptUtils.ServiceCenter():GetService(typeof(CS.EightGame.Component.ClubService));
	local request; request = CS.EightGame.Data.Server.SendGetRewardCreditRequest();
	srv:SendGetRewardCreditRequest(request, (function(returnCode)
		local msg; msg = "";
		if (CS.System.Convert.ToInt32(returnCode) == 200) then
			msg = "积分奖励领取成功" 
		else
			msg = CS.EightGame.Component.NetCode.GetDesc(returnCode) 
		end 
		CS.EightGame.Logic.FloatingTextTipUIRoot.SetFloattingTip(msg, 0.00) 
	end), nil) 
end

function _lua_ClubBossReadyPageUI:OnPointViewBtn()
	GameLog("------------------------------_lua_ClubBossReadyPageUI OnPointViewBtn------------------------------")
	CS.Eight.Framework.EIFrameWork.StartCoroutine(RoleInfoUtil.LoadAsynUIPrefab(this.gameObject, "ClubUI/ClubPageUI/ui_boss_integral_popup_frag", (function(obj)
		local popup; popup = obj:GetComponent("ClubIntegralPageUI");
		local param; param = CS.EightGame.Logic.TipsDialogParam("ClubIntegralPageUI","个人积分奖励",obj,"返回",nil,5,0) ;
		delegationset(false, false, "CS.EightGame.Logic.TipsDialogParam:ondismiss", param, nil, "ondismiss", (function()
			if not isnil(obj) then
				CS.UnityEngine.Object.Destroy(obj) 
			end 
		end)) 
		CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_COMMONT_TIPS_DIALOG",nil,param,0.00) ) 
		popup:Init() 
	end)), false) 
end

function _lua_ClubBossReadyPageUI:OnExit()
	GameLog("------------------------------_lua_ClubBossReadyPageUI OnExit------------------------------")
	AlarmManager.Instance:cancel("ClubBossEndClock") 
end

function _lua_ClubBossReadyPageUI:GoBossBattleMsg( _eventIdParam, _battleInfo, fighterids)
	GameLog("------------------------------_lua_ClubBossReadyPageUI GoBossBattleMsg------------------------------")
	local srv; srv = XLuaScriptUtils.ServiceCenter():GetService(typeof(CS.EightGame.Component.ClubService));
	local request; request = CS.EightGame.Data.Server.SendBoss();
	local _fids; _fids = fighterids:FindAll((function(x) return (x ~= 0); end));
	if ((_fids == nil) or (obj_len(_fids) == 0)) then
		return  
	end 
	request.fighter:AddRange(_fids) 
	srv:SendBoss(request, (function(arg1, response)
		local errorc; errorc = arg1;
		this:BeginClubBossWar(errorc, response, _eventIdParam, _battleInfo) 
	end), nil) 
end

function _lua_ClubBossReadyPageUI:BeginClubBossWar( returnCode, setupResponse, _eventIdParam, _battleInfo)
	GameLog("------------------------------_lua_ClubBossReadyPageUI BeginClubBossWar------------------------------")
	if (returnCode ~= 200) then
		CS.EightGame.Logic.FloatingTextTipUIRoot.SetFloattingTip(CS.EightGame.Component.NetCode.GetDesc(returnCode), 0.00) 
		return  
	end 
	local assistPid; assistPid = 0;
	local param; param = CS.EightGame.Logic.BattleStartParam(setupResponse.battleGveSetup.battleSetup,_battleInfo,_eventIdParam,assistPid,nil) ;
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("FIGHT_BATTLE_SETUP",nil,param,0.00) ) 
end

function _lua_ClubBossReadyPageUI:GetEligibilityFighters( battleinfo, accordList)
	GameLog("------------------------------_lua_ClubBossReadyPageUI GetEligibilityFighters------------------------------")
	if ((obj_len(battleinfo.mustjob) == 0) or ( ((obj_len(battleinfo.mustjob) == 1) and (DictGetValue(battleinfo.mustjob, 0) == se_jobtype.SE_JOBTYPE_NOTHING )) )) then
		return this:GetEligibilityLvFighters(battleinfo.mustlevel, accordList) 
	end 
	return this:GetEligibilityJobFighters(battleinfo.mustjob, this:GetEligibilityLvFighters(battleinfo.mustlevel, accordList)) 
end

function _lua_ClubBossReadyPageUI:GetEligibilityLvFighters( limitLv, accordList)
	GameLog("------------------------------_lua_ClubBossReadyPageUI GetEligibilityLvFighters------------------------------")
	local result; result = XLuaScriptUtils.new_List_1(typeof(CS.EightGame.Data.Server.FighterSerData));
	local index; index = 0;
	while (index < obj_len(accordList)) do
		if (DictGetValue(accordList, index).level >= limitLv) then
			result:Add(DictGetValue(accordList, index)) 
		end 
	index = index+1  
	end 
	return result 
end

function _lua_ClubBossReadyPageUI:OnCancel()
	GameLog("------------------------------_lua_ClubBossReadyPageUI OnCancel------------------------------")
	this.isClick = false 
	return true 
end

function _lua_ClubBossReadyPageUI:hotfix()
	xlua.hotfix(ClubBossReadyPageUI, {
       ['Init'] = function(this)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:Init()
       end,
       ['SetEndTimeClock'] = function(this, endtime)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:SetEndTimeClock( endtime)
       end,
       ['CheckBossTime'] = function(this, _bossData)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:CheckBossTime( _bossData)
       end,
       ['ResetThings'] = function(this)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:ResetThings()
       end,
       ['OnShowRankList'] = function(this)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:OnShowRankList()
       end,
       ['SendReliveRequest'] = function(this)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:SendReliveRequest()
       end,
       ['OnPointTakeBtn'] = function(this)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:OnPointTakeBtn()
       end,
       ['OnPointViewBtn'] = function(this)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:OnPointViewBtn()
       end,
       ['OnExit'] = function(this)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:OnExit()
       end,
       ['GoBossBattleMsg'] = function(this, _eventIdParam, _battleInfo, fighterids)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:GoBossBattleMsg( _eventIdParam, _battleInfo, fighterids)
       end,
       ['BeginClubBossWar'] = function(this, returnCode, setupResponse, _eventIdParam, _battleInfo)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:BeginClubBossWar( returnCode, setupResponse, _eventIdParam, _battleInfo)
       end,
       ['GetEligibilityFighters'] = function(this, battleinfo, accordList)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:GetEligibilityFighters( battleinfo, accordList)
       end,
       ['GetEligibilityLvFighters'] = function(this, limitLv, accordList)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:GetEligibilityLvFighters( limitLv, accordList)
       end,
       ['OnCancel'] = function(this)
           _lua_ClubBossReadyPageUI:Ref(this)
           return _lua_ClubBossReadyPageUI:OnCancel()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubBossReadyPageUI)