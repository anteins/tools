
local this = nil
_lua_ChatShowPanelController = BaseCom:New('_lua_ChatShowPanelController')
function _lua_ChatShowPanelController:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatShowPanelController:SetData( callbackSelectItem)
	GameLog("------------------------------_lua_ChatShowPanelController SetData------------------------------")
	this._sourceDatas:Clear() 
	this._callbackSelectItem = callbackSelectItem 
	if not isnil(this._uiRecycledList) then
		this._uiRecycledList.onUpdateItem =  (function(go, itemIndex, dataIndex) this:OnUpdateItem(go, itemIndex, dataIndex) end) 
	end 
	CS.Eight.Framework.EIFrameWork.StartCoroutine(this:LoadPrefab(), false) 
end

function _lua_ChatShowPanelController:LoadPrefab()
	GameLog("------------------------------_lua_ChatShowPanelController LoadPrefab------------------------------")
	if isnil(this._itemLinePrefab) then
		local coroutine; coroutine = XLuaScriptUtils.GameResources():LoadAsyn(CS.System.String.Format("{0}{1}", "GameAssets/Prefabs/UI/", this._itemLinePrefabPath), "prefab", false);
		if coroutine.coroutine then
coroutine.yield(coroutine.coroutine)
end
		this._itemLinePrefab = coroutine.res 
		this:InitItemLine() 
		this:InitBtns() 
	else
		this:InitBtns() 
	end 
end

function _lua_ChatShowPanelController:InitItemLine()
	GameLog("------------------------------_lua_ChatShowPanelController InitItemLine------------------------------")
	if (isnil(this._itemLinePrefab) or (obj_len(this._applicationItemDic) > 0)) then
		return  
	end 
	local index; index = 0;
	while (index < 5) do
		local go; go = GameUtility.InstantiateGameObject(this._itemLinePrefab, this._uiRecycledList.gameObject, ("itemLine" .. index));
		local r; r = go:GetComponent("ChatItemLineControlller");
		this._applicationItemDic:Add(go, r) 
	index = index+1  
	end 
end

function _lua_ChatShowPanelController:InitBtns()
	GameLog("------------------------------_lua_ChatShowPanelController InitBtns------------------------------")
	local enumlist; enumlist = XLuaScriptUtils.new_List_1(typeof(ChatShowItemBtnCom.ChatShowItemEnum));
	enumlist:Add(0) 
	enumlist:Add(1) 
	local index; index = 0;
	while (index < obj_len(this._btns)) do
		if (index < obj_len(enumlist)) then
			DictGetValue(this._btns, index).gameObject:SetActive(true) 
			DictGetValue(this._btns, index):SetData(DictGetValue(enumlist, index), function(com) this:CallbackSelectBtn(com) end) 
			DictGetValue(this._btns, index):SetBtnSprite(false) 
		else
			DictGetValue(this._btns, index).gameObject:SetActive(false) 
		end 
	index = index+1  
	end 
	this:CallbackSelectBtn(DictGetValue(this._btns, 0)) 
end

function _lua_ChatShowPanelController:CallbackSelectBtn( com)
	GameLog("------------------------------_lua_ChatShowPanelController CallbackSelectBtn------------------------------")
	if not isnil(ChatShowPanelController._latestShowItemBtnCom) then
		ChatShowPanelController._latestShowItemBtnCom:SetBtnSprite(false) 
	end 
	ChatShowPanelController._latestShowItemBtnCom = com 
	if not isnil(ChatShowPanelController._latestShowItemBtnCom) then
		ChatShowPanelController._latestShowItemBtnCom:SetBtnSprite(true) 
	end 
	this._curBtnEnum = com._enum 
	this._sourceDatas:Clear() 
	if (CS.System.Convert.ToInt32(this._curBtnEnum) == 0) then
		this:InitItemData() 
	elseif (CS.System.Convert.ToInt32(this._curBtnEnum) == 1) then
		this:InitEquipmentData() 
	elseif (CS.System.Convert.ToInt32(this._curBtnEnum) == 2) then
		this:InitAvatorData() 
	end 
	this._uiRecycledList:UpdateDataCount(CS.UnityEngine.Mathf.CeilToInt((obj_len(this._sourceDatas) / ChatItemLineControlller._eachLineItemCount)), true) 
end

function _lua_ChatShowPanelController:OnUpdateItem( go, itemIndex, dataIndex)
	GameLog("------------------------------_lua_ChatShowPanelController OnUpdateItem------------------------------")
	local com; com = nil;
	if (function() local __compiler_invoke_166  __compiler_invoke_166, com = this._applicationItemDic:TryGetValue(go)  return __compiler_invoke_166  end)() then
		if isnil(com) then
			return  
		end 
		if ((obj_len(this._sourceDatas) > 0) and (dataIndex < obj_len(this._sourceDatas))) then
			com:SetData(this._curBtnEnum, this:GetItemSerDatasByDataIndex(this._sourceDatas, dataIndex), function(obj) this:OnSelectionChange(obj) end) 
		end 
	end 
end

function _lua_ChatShowPanelController:GetItemSerDatasByDataIndex( sourcedatas, dataIndex)
	GameLog("------------------------------_lua_ChatShowPanelController GetItemSerDatasByDataIndex------------------------------")
	local resulutDatas; resulutDatas = XLuaScriptUtils.new_List_1(typeof(CS.System.Object));
	if ((sourcedatas == nil) or (obj_len(sourcedatas) == 0)) then
		return resulutDatas 
	end 
	if (obj_len(sourcedatas) < ( ( dataIndex+1  )*ChatItemLineControlller._eachLineItemCount  )) then
		if (obj_len(sourcedatas)-dataIndex*ChatItemLineControlller._eachLineItemCount   > 0) then
			resulutDatas = sourcedatas:GetRange(dataIndex*ChatItemLineControlller._eachLineItemCount , obj_len(sourcedatas)-dataIndex*ChatItemLineControlller._eachLineItemCount  ) 
		end 
	else
		resulutDatas = sourcedatas:GetRange(dataIndex*ChatItemLineControlller._eachLineItemCount , ChatItemLineControlller._eachLineItemCount) 
	end 
	return resulutDatas 
end

function _lua_ChatShowPanelController:OnSelectionChange( obj)
	GameLog("------------------------------_lua_ChatShowPanelController OnSelectionChange------------------------------")
	if this ~= "_callbackSelectItem" then
		this._callbackSelectItem(obj) 
	end 
end

function _lua_ChatShowPanelController:OnClickClose()
	GameLog("------------------------------_lua_ChatShowPanelController OnClickClose------------------------------")
	if not isnil(this) then
		this.gameObject:SetActive(false) 
	end 
end

function _lua_ChatShowPanelController:hotfix()
	xlua.hotfix(ChatShowPanelController, {
       ['SetData'] = function(this, callbackSelectItem)
           _lua_ChatShowPanelController:Ref(this)
           return _lua_ChatShowPanelController:SetData( callbackSelectItem)
       end,
       ['LoadPrefab'] = function(this)
           _lua_ChatShowPanelController:Ref(this)
           return util.cs_generator(function()
               _lua_ChatShowPanelController:LoadPrefab()
           end)
       end,
       ['InitItemLine'] = function(this)
           _lua_ChatShowPanelController:Ref(this)
           return _lua_ChatShowPanelController:InitItemLine()
       end,
       ['InitBtns'] = function(this)
           _lua_ChatShowPanelController:Ref(this)
           return _lua_ChatShowPanelController:InitBtns()
       end,
       ['CallbackSelectBtn'] = function(this, com)
           _lua_ChatShowPanelController:Ref(this)
           return _lua_ChatShowPanelController:CallbackSelectBtn( com)
       end,
       ['OnUpdateItem'] = function(this, go, itemIndex, dataIndex)
           _lua_ChatShowPanelController:Ref(this)
           return _lua_ChatShowPanelController:OnUpdateItem( go, itemIndex, dataIndex)
       end,
       ['GetItemSerDatasByDataIndex'] = function(this, sourcedatas, dataIndex)
           _lua_ChatShowPanelController:Ref(this)
           return _lua_ChatShowPanelController:GetItemSerDatasByDataIndex( sourcedatas, dataIndex)
       end,
       ['OnSelectionChange'] = function(this, obj)
           _lua_ChatShowPanelController:Ref(this)
           return _lua_ChatShowPanelController:OnSelectionChange( obj)
       end,
       ['OnClickClose'] = function(this)
           _lua_ChatShowPanelController:Ref(this)
           return _lua_ChatShowPanelController:OnClickClose()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatShowPanelController)