
local this = nil
_lua_ClientTeammmemberData = BaseCom:New('_lua_ClientTeammmemberData')
function _lua_ClientTeammmemberData:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClientTeammmemberData:hotfix()
end

table.insert(g_tbHotfix, _lua_ClientTeammmemberData)