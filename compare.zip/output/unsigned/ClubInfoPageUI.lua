
local this = nil
_lua_ClubInfoPageUI = BaseCom:New('_lua_ClubInfoPageUI')
function _lua_ClubInfoPageUI:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubInfoPageUI:OnAddFresh( e)
	GameLog("------------------------------_lua_ClubInfoPageUI OnAddFresh------------------------------")
	this:SetSort() 
end

function _lua_ClubInfoPageUI:OnExit()
	GameLog("------------------------------_lua_ClubInfoPageUI OnExit------------------------------")
	this.MemberObjs:SetActive(false) 
	this.UpGradePage.gameObject:SetActive(false) 
end

function _lua_ClubInfoPageUI:OnChangeSort()
	GameLog("------------------------------_lua_ClubInfoPageUI OnChangeSort------------------------------")
	local labstr; labstr = "";
	this.Mshow =  ( ( this.Mshow )+1  )%7   
	this:SetSort() 
	local __compiler_switch_131 = this.Mshow;
	if __compiler_switch_131 == 0 then
		labstr = "筛选: 综合" 
	elseif __compiler_switch_131 == 1 then
		labstr = "筛选: 权限" 
	elseif __compiler_switch_131 == 2 then
		labstr = "筛选: 周贡献" 
	elseif __compiler_switch_131 == 3 then
		labstr = "筛选: 总贡献" 
	elseif __compiler_switch_131 == 4 then
		labstr = "筛选: 等级" 
	elseif __compiler_switch_131 == 5 then
		labstr = "筛选: 会员" 
	elseif __compiler_switch_131 == 6 then
		labstr = "筛选: 在线" 
	end 
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIStringEvent("CHANGE_SHOW_CLUB_MEMBERS",labstr) ) 
end

function _lua_ClubInfoPageUI:SetStaticInfo( _data)
	GameLog("------------------------------_lua_ClubInfoPageUI SetStaticInfo------------------------------")
	this.MaxMoneyLab.text = "" 
	this.MaxWoodLab.text = "" 
	this.MaxMineralLab.text = "" 
	this.MaxManaLab.text = "" 
end

function _lua_ClubInfoPageUI:OnShowEditorTip()
	GameLog("------------------------------_lua_ClubInfoPageUI OnShowEditorTip------------------------------")
	local _tippath; _tippath = "ClubUI/ClubTipsUI/SignEditorTips";
	CS.Eight.Framework.EIFrameWork.StartCoroutine(RoleInfoUtil.LoadAsynUIPrefab(nil, _tippath, (function(obj)
		local _tipui; _tipui = obj:GetComponent("ClubEditorTipUI");
		_tipui:Init() 
		local tipsDialogParam; tipsDialogParam = CS.EightGame.Logic.TipsDialogParam("ClubInfoEditor","团队公告编辑",obj,"确定",(function() 
			this:SendInput(_tipui.EInput.value) 
			return true 
		end), "返回", function() return this:OnCancel() end, 5, 0) 
		delegationset(false, false, "CS.EightGame.Logic.TipsDialogParam:ondismiss", tipsDialogParam, nil, "ondismiss", (function()
			if not isnil(obj) then
				CS.UnityEngine.Object.Destroy(obj) 
			end 
		end)) 
		CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_COMMONT_TIPS_DIALOG",nil,tipsDialogParam,0.00) ) 
	end)), false) 
end

function _lua_ClubInfoPageUI:OnShowApplyerListPage()
	GameLog("------------------------------_lua_ClubInfoPageUI OnShowApplyerListPage------------------------------")
	ClubApplyerListDialogNode.Open() 
end

function _lua_ClubInfoPageUI:OnSendEditor()
	GameLog("------------------------------_lua_ClubInfoPageUI OnSendEditor------------------------------")
	return true 
end

function _lua_ClubInfoPageUI:OnCancel()
	GameLog("------------------------------_lua_ClubInfoPageUI OnCancel------------------------------")
	return true 
end

function _lua_ClubInfoPageUI:OnOpenApplyList()
	GameLog("------------------------------_lua_ClubInfoPageUI OnOpenApplyList------------------------------")
	ClubApplyerListDialogNode.Open() 
end

function _lua_ClubInfoPageUI:OnOpenUpGradePage()
	GameLog("------------------------------_lua_ClubInfoPageUI OnOpenUpGradePage------------------------------")
	this:OnEnter(2) 
end

function _lua_ClubInfoPageUI:InitDic()
	GameLog("------------------------------_lua_ClubInfoPageUI InitDic------------------------------")
	if (obj_len(this.dataDic) == 0) then
		local i; i = 0;
		while (i < 8) do
			local obj; obj = NGUITools.AddChild__UnityEngine_GameObject__UnityEngine_GameObject(NGUITools, this.BrRecyced.gameObject, this.SingleMemberSample);
			local com; com = obj:GetComponent("SingleMemberUI");
			EventDelegate.Add(com.MoreThingsBt.onClick, (function()
				this:OnShowPrivilegeUI(com.MyMember, com.MoreThingsBt.transform.localPosition) 
			end)) 
			obj.name = CS.System.String.Format("member_{0}", i) 
			obj:SetActive(true) 
			this.dataDic:Add(obj, com) 
		i = i+1  
		end 
	end 
end

function _lua_ClubInfoPageUI:OnUpdata( item, itemIndex, dataIndex)
	GameLog("------------------------------_lua_ClubInfoPageUI OnUpdata------------------------------")
	local _Sui; _Sui = nil;
	if (function() local __compiler_invoke_396  __compiler_invoke_396, _Sui = this.dataDic:TryGetValue(item)  return __compiler_invoke_396  end)() then
		if ((obj_len(this.Memerbers) > 0) and (dataIndex < obj_len(this.Memerbers))) then
			_Sui = item:GetComponent("SingleMemberUI") 
			_Sui:SetUp(DictGetValue(this.Memerbers, dataIndex)) 
		end 
	end 
end

function _lua_ClubInfoPageUI:SendInput( str)
	GameLog("------------------------------_lua_ClubInfoPageUI SendInput------------------------------")
	local _tips; _tips = "";
	local newstr; newstr = ChatMsgManager.Instance:FifterString(str);
	if (obj_len(newstr) > 70) then
		_tips = "公告文字过长(70字),请重新设置" 
	end 
	if PlayerInfoUtil.CheckBlackList(newstr) then
		_tips = "公告不能含有非法词汇,请重新设置" 
	end 
	if (not CS.System.String.IsNullOrEmpty(_tips)) then
		local param; param = CS.EightGame.Logic.TipStruct(_tips,0.20) ;
		CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_FLOATING_TIPS",nil,param,0.00) ) 
		return  
	end 
	local srv; srv = XLuaScriptUtils.ServiceCenter():GetService(typeof(CS.EightGame.Component.ClubService));
	local request; request = CS.EightGame.Data.Server.SendNewSignRequest();
	srv:SendNewSignRequest(request, (function(arg1)
		local errorc; errorc = arg1;
		if (errorc ~= 200) then
			local _tipstr; _tipstr = CS.EightGame.Component.NetCode.GetDesc(errorc);
			local param; param = CS.EightGame.Logic.TipStruct(_tipstr,0.20) ;
			CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_FLOATING_TIPS",nil,param,0.00) ) 
		else
			this.ClubSignatureLab.text = str 
		end 
	end), nil) 
end

function _lua_ClubInfoPageUI:OnClickProble()
	GameLog("------------------------------_lua_ClubInfoPageUI OnClickProble------------------------------")
	local detalstr; detalstr = "[99ff82]每日维护资金：[-]\n冒险团每日需要支付维护资金,冒险团等级越高、设施等级越高,需要支付的资金也越多。当维护资金不支付时，将会使用声望值支付,当声望也无法支付时，冒险团将解散\n\n[99ff82]繁荣：[-]\n团内成员进行特定的冒险团活动可获得繁荣值,繁荣值每天结算一次,繁荣值没达到指定量则结算时会扣除相应的,繁荣值繁荣等级越高,在讨伐任务中获得的奖励就越好\n\n[99ff82]资金：[-]\n可用于冒险团升级和冒险团维护，可在冒险团活动中获得\n\n[99ff82]木材：[-]\n冒险团升级所需，可在冒险团活动中获得\n\n[99ff82]石材：[-]\n冒险团升级所需，可在冒险团活动中获得";
	ClubUtility.ShowCommonExpainTips(detalstr) 
end

function _lua_ClubInfoPageUI:hotfix()
	xlua.hotfix(ClubInfoPageUI, {
       ['OnAddFresh'] = function(this, e)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:OnAddFresh( e)
       end,
       ['OnExit'] = function(this)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:OnExit()
       end,
       ['OnChangeSort'] = function(this)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:OnChangeSort()
       end,
       ['SetStaticInfo'] = function(this, _data)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:SetStaticInfo( _data)
       end,
       ['OnShowEditorTip'] = function(this)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:OnShowEditorTip()
       end,
       ['OnShowApplyerListPage'] = function(this)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:OnShowApplyerListPage()
       end,
       ['OnSendEditor'] = function(this)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:OnSendEditor()
       end,
       ['OnCancel'] = function(this)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:OnCancel()
       end,
       ['OnOpenApplyList'] = function(this)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:OnOpenApplyList()
       end,
       ['OnOpenUpGradePage'] = function(this)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:OnOpenUpGradePage()
       end,
       ['InitDic'] = function(this)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:InitDic()
       end,
       ['OnUpdata'] = function(this, item, itemIndex, dataIndex)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:OnUpdata( item, itemIndex, dataIndex)
       end,
       ['SendInput'] = function(this, str)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:SendInput( str)
       end,
       ['OnClickProble'] = function(this)
           _lua_ClubInfoPageUI:Ref(this)
           return _lua_ClubInfoPageUI:OnClickProble()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubInfoPageUI)