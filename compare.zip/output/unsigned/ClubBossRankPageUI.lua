
local this = nil
_lua_ClubBossRankPageUI = BaseCom:New('_lua_ClubBossRankPageUI')
function _lua_ClubBossRankPageUI:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubBossRankPageUI:Init()
	GameLog("------------------------------_lua_ClubBossRankPageUI Init------------------------------")
	this:CreataDicObjs() 
	delegationadd(false, false, "UIRecycledList:onUpdateItem", this.BrRecyced, nil, "onUpdateItem", function(item, itemIndex, dataIndex) this:OnUpdateItem(item, itemIndex, dataIndex) end) 
end

function _lua_ClubBossRankPageUI:CreataDicObjs()
	GameLog("------------------------------_lua_ClubBossRankPageUI CreataDicObjs------------------------------")
	if (obj_len(this.dataDic) == 0) then
		local i; i = 0;
		while (i < 8) do
			local obj; obj = NGUITools.AddChild__UnityEngine_GameObject__UnityEngine_GameObject(NGUITools, this.BrRecyced.gameObject, this.MyRankUI.gameObject);
			local com; com = obj:GetComponent("SingleRankUI");
			com:Init() 
			obj.name = CS.System.String.Format("ranks_{0}", i) 
			obj:SetActive(true) 
			this.dataDic:Add(obj, com) 
		i = i+1  
		end 
	end 
end

function _lua_ClubBossRankPageUI:OnUpdateItem( item, itemIndex, dataIndex)
	GameLog("------------------------------_lua_ClubBossRankPageUI OnUpdateItem------------------------------")
	local _Rui; _Rui = nil;
	if (function() local __compiler_invoke_68  __compiler_invoke_68, _Rui = this.dataDic:TryGetValue(item)  return __compiler_invoke_68  end)() then
		if ((this.dataDic.Count > 0) and (dataIndex < obj_len(this.dataDic))) then
			local _rdata; _rdata = DictGetValue(this.curData, dataIndex);
			_Rui = item:GetComponent("SingleRankUI") 
			_Rui:FreshData__EightGame_Data_Server_bossRankdata(_rdata) 
		end 
	end 
end

function _lua_ClubBossRankPageUI:hotfix()
	xlua.hotfix(ClubBossRankPageUI, {
       ['Init'] = function(this)
           _lua_ClubBossRankPageUI:Ref(this)
           return _lua_ClubBossRankPageUI:Init()
       end,
       ['CreataDicObjs'] = function(this)
           _lua_ClubBossRankPageUI:Ref(this)
           return _lua_ClubBossRankPageUI:CreataDicObjs()
       end,
       ['OnUpdateItem'] = function(this, item, itemIndex, dataIndex)
           _lua_ClubBossRankPageUI:Ref(this)
           return _lua_ClubBossRankPageUI:OnUpdateItem( item, itemIndex, dataIndex)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubBossRankPageUI)