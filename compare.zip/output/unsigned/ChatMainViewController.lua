
local this = nil
_lua_ChatMainViewController = BaseCom:New('_lua_ChatMainViewController')
function _lua_ChatMainViewController:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatMainViewController:InitChat()
	GameLog("------------------------------_lua_ChatMainViewController InitChat------------------------------")
	if isnil(this._com) then
		return  
	end 
	this._com.gameObject:SetActive(true) 
	this._com:Init(function() this:CallbackClickChatBtn() end) 
end

function _lua_ChatMainViewController:CloseChat()
	GameLog("------------------------------_lua_ChatMainViewController CloseChat------------------------------")
	if isnil(this._com) then
		return  
	end 
	this._com.gameObject:SetActive(false) 
	this._com:UnRegisterEvent() 
end

function _lua_ChatMainViewController:CallbackClickChatBtn()
	GameLog("------------------------------_lua_ChatMainViewController CallbackClickChatBtn------------------------------")
	if isnil(this._com) then
		return  
	end 
	if this.chatViewState then
		this.chatViewState = false 
		this._com:CloseChat() 
	else
		this.chatViewState = true 
		this._com:OpenChatView() 
	end 
end

function _lua_ChatMainViewController:ForceSetChatViewState( b)
	GameLog("------------------------------_lua_ChatMainViewController ForceSetChatViewState------------------------------")
	if isnil(this._com) then
		return  
	end 
	this.chatViewState = b 
	if this.chatViewState then
		this._com:OpenChatView() 
	else
		this._com:CloseChat() 
	end 
end

function _lua_ChatMainViewController:hotfix()
	xlua.hotfix(ChatMainViewController, {
       ['InitChat'] = function(this)
           _lua_ChatMainViewController:Ref(this)
           return _lua_ChatMainViewController:InitChat()
       end,
       ['CloseChat'] = function(this)
           _lua_ChatMainViewController:Ref(this)
           return _lua_ChatMainViewController:CloseChat()
       end,
       ['CallbackClickChatBtn'] = function(this)
           _lua_ChatMainViewController:Ref(this)
           return _lua_ChatMainViewController:CallbackClickChatBtn()
       end,
       ['ForceSetChatViewState'] = function(this, b)
           _lua_ChatMainViewController:Ref(this)
           return _lua_ChatMainViewController:ForceSetChatViewState( b)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatMainViewController)