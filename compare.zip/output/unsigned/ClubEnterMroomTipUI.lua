
local this = nil
_lua_ClubEnterMroomTipUI = BaseCom:New('_lua_ClubEnterMroomTipUI')
function _lua_ClubEnterMroomTipUI:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubEnterMroomTipUI:hotfix()
end

table.insert(g_tbHotfix, _lua_ClubEnterMroomTipUI)