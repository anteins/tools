
local this = nil
_lua_ChangeNameDialogNode = BaseCom:New('_lua_ChangeNameDialogNode')
function _lua_ChangeNameDialogNode:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChangeNameDialogNode:CreateAssets()
	GameLog("------------------------------_lua_ChangeNameDialogNode CreateAssets------------------------------")
	local coroutine; coroutine = XLuaScriptUtils.GameResources():LoadAsyn("GameAssets/Prefabs/UI/NewWorld/PlayerInfo/changeNamePopup", "prefab", false);
	if coroutine.coroutine then
coroutine.yield(coroutine.coroutine)
end
	local prefab; prefab = coroutine.res;
	local obj; obj = NGUITools.AddChild__UnityEngine_GameObject__UnityEngine_GameObject(NGUITools, this.dialogParent.gameObject, prefab);
	this.popup = obj:GetComponent("ChangeNamePopupUICom") 
	this:BindEvents() 
	this:BindComponent(this.popup)
	this._isReady = true 
	return nil 
end

function _lua_ChangeNameDialogNode:OnExit()
	GameLog("------------------------------_lua_ChangeNameDialogNode OnExit------------------------------")
	return nil 
end

function _lua_ChangeNameDialogNode:OnInputChange()
	GameLog("------------------------------_lua_ChangeNameDialogNode OnInputChange------------------------------")
	this._isNamePassCheck = false 
	local str; str = this.popup.nameInput.value;
	local charLimit; charLimit = this.popup.nameInput.characterLimit;
	if PlayerInfoUtil.CheckCharacterSpecial(str) then
		this:ShowErrorMsg("名字不能含有特殊字符") 
		return  
	end 
	if PlayerInfoUtil.CheckBlackList(str) then
		this:ShowErrorMsg("名字不能含有非法词汇") 
		return  
	end 
	this:HideErrorMsg() 
	this._isNamePassCheck = true 
end

function _lua_ChangeNameDialogNode:OnChangeName( returnCode, response)
	GameLog("------------------------------_lua_ChangeNameDialogNode OnChangeName------------------------------")
	local res; res = response;
	local msg; msg = "";
	if (returnCode < 1000) then
		local player; player = CS.Eight.Framework.EIFrameWork.GetComponent(CS.EightGame.Component.NetworkClient):GetDataByCls__System_Predicate_T(typeof(CS.EightGame.Data.Server.PlayerSerData), nil);
		if ((player ~= nil) and (player.namehistory ~= nil)) then
			local nameHistory; nameHistory = player.namehistory;
			if (obj_len(nameHistory) > 0) then
				local nameHistoryList; nameHistoryList = CS.MiniJSON.Json.Deserialize(nameHistory);
				if (obj_len(nameHistoryList) > 0) then
					CS.Eight.Framework.EIFrameWork.GetComponent(CS.EightGame.Component.Statistical):RecordOtherPurchase("修改名字", 1, 150, se_currency.SE_CURRENCY_DIAMOND ) 
				end 
			end 
		end 
		local name; name = res.name;
		msg = CS.System.String.Format("昵称已成功修改为 {0}", name) 
	else
		msg = CS.EightGame.Component.NetCode.GetDesc(returnCode) 
	end 
	this:ShowSimpleTip(msg) 
	this:OnDissmissPopup() 
end

function _lua_ChangeNameDialogNode:ShowSimpleTip( msg)
	GameLog("------------------------------_lua_ChangeNameDialogNode ShowSimpleTip------------------------------")
	local param; param = CS.EightGame.Logic.CommonTipsParam(msg,0,nil,nil,"") ;
	param.isShowOKCancelBtn = false 
	this:DispatchEvent(CS.Eight.Framework.EIEvent("UI_TIPS",nil,param,0.00) ) 
end

function _lua_ChangeNameDialogNode:ShowErrorMsg( msg)
	GameLog("------------------------------_lua_ChangeNameDialogNode ShowErrorMsg------------------------------")
	this.popup.errorTipLabel.text = msg 
	this.popup.errorTipLabel.gameObject:SetActive(true) 
	this.popup.costTipGO:SetActive(false) 
	this.popup.freeTipGO:SetActive(false) 
end

function _lua_ChangeNameDialogNode:HideErrorMsg()
	GameLog("------------------------------_lua_ChangeNameDialogNode HideErrorMsg------------------------------")
	this.popup.errorTipLabel.gameObject:SetActive(false) 
	this.popup:SwitchCostTip() 
end

function _lua_ChangeNameDialogNode:OnDissmissPopup()
	GameLog("------------------------------_lua_ChangeNameDialogNode OnDissmissPopup------------------------------")
	if not isnil(this.popup) then
		CS.UnityEngine.Object.Destroy(this.popup.gameObject) 
	end 
	ChangeNameDialogNode.Close() 
end

function _lua_ChangeNameDialogNode:hotfix()
	xlua.hotfix(ChangeNameDialogNode, {
       ['CreateAssets'] = function(this)
           _lua_ChangeNameDialogNode:Ref(this)
           return util.cs_generator(function()
               _lua_ChangeNameDialogNode:CreateAssets()
           end)
       end,
       ['OnExit'] = function(this)
           _lua_ChangeNameDialogNode:Ref(this)
           return _lua_ChangeNameDialogNode:OnExit()
       end,
       ['OnInputChange'] = function(this)
           _lua_ChangeNameDialogNode:Ref(this)
           return _lua_ChangeNameDialogNode:OnInputChange()
       end,
       ['OnChangeName'] = function(this, returnCode, response)
           _lua_ChangeNameDialogNode:Ref(this)
           return _lua_ChangeNameDialogNode:OnChangeName( returnCode, response)
       end,
       ['ShowSimpleTip'] = function(this, msg)
           _lua_ChangeNameDialogNode:Ref(this)
           return _lua_ChangeNameDialogNode:ShowSimpleTip( msg)
       end,
       ['ShowErrorMsg'] = function(this, msg)
           _lua_ChangeNameDialogNode:Ref(this)
           return _lua_ChangeNameDialogNode:ShowErrorMsg( msg)
       end,
       ['HideErrorMsg'] = function(this)
           _lua_ChangeNameDialogNode:Ref(this)
           return _lua_ChangeNameDialogNode:HideErrorMsg()
       end,
       ['OnDissmissPopup'] = function(this)
           _lua_ChangeNameDialogNode:Ref(this)
           return _lua_ChangeNameDialogNode:OnDissmissPopup()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChangeNameDialogNode)