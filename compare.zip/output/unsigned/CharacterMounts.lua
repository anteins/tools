
local this = nil
_lua_CharacterMounts = BaseCom:New('_lua_CharacterMounts')
function _lua_CharacterMounts:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_CharacterMounts:GetMounts( mountName)
	GameLog("------------------------------_lua_CharacterMounts GetMounts------------------------------")
	if ((this._mountsDict ~= nil) and this._mountsDict:ContainsKey(mountName)) then
		return DictGetValue(this._mountsDict, mountName) 
	end 
	return nil 
end

function _lua_CharacterMounts:hotfix()
	xlua.hotfix(CharacterMounts, {
       ['GetMounts'] = function(this, mountName)
           _lua_CharacterMounts:Ref(this)
           return _lua_CharacterMounts:GetMounts( mountName)
       end,
   })
end

table.insert(g_tbHotfix, _lua_CharacterMounts)