
local this = nil
_lua_ClubEntrustPartyUI = BaseCom:New('_lua_ClubEntrustPartyUI')
function _lua_ClubEntrustPartyUI:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubEntrustPartyUI:Init()
	GameLog("------------------------------_lua_ClubEntrustPartyUI Init------------------------------")
	EventDelegate.Add(this.UpPushUiBt.onClick, function() this:OnSendCollectMaterialFunction() end) 
end

function _lua_ClubEntrustPartyUI:SetReward( guilditem)
	GameLog("------------------------------_lua_ClubEntrustPartyUI SetReward------------------------------")
	local rewardstr; rewardstr = "";
	local numRate; numRate = this:CheckRewardNum();
	this.RewardRateTipLab.text = CS.System.String.Format("[00ff2c]{0}[-]倍奖励次数", numRate) 
	if (guilditem.getmoney ~= 0) then
		local rstr; rstr = ShowRewardUtil.GetTypeWords(10, 1);
		rewardstr = rewardstr + CS.System.String.Format("{0} {1}    ", rstr, guilditem.getmoney) 
	end 
	if (guilditem.getprestige ~= 0) then
		local rstr; rstr = ShowRewardUtil.GetTypeWords(10, 5);
		rewardstr = rewardstr + CS.System.String.Format("{0} {1}    ", rstr, guilditem.getprestige) 
	end 
	if (guilditem.getprosperity ~= 0) then
		local rstr; rstr = ShowRewardUtil.GetTypeWords(10, 6);
		rewardstr = rewardstr + CS.System.String.Format("{0} {1}    ", rstr, guilditem.getprosperity) 
	end 
	this.AllRewardValLab.text = rewardstr 
	if (guilditem.getcontribution ~= 0) then
		this.MyRewardValLab.gameObject:SetActive(true) 
		local rstr; rstr = ShowRewardUtil.GetTypeWords(11, 0);
		this.MyRewardValLab.text = CS.System.String.Format("{0} {1}", rstr, guilditem.getcontribution) 
	else
		this.MyRewardValLab.gameObject:SetActive(false) 
	end 
end

function _lua_ClubEntrustPartyUI:OnSendCollectMaterialFunction()
	GameLog("------------------------------_lua_ClubEntrustPartyUI OnSendCollectMaterialFunction------------------------------")
	if (not this.IsEnough) then
		local _tipstr; _tipstr = "该活动物品不满足";
		local param; param = CS.EightGame.Logic.TipStruct(_tipstr,0.20) ;
		CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_FLOATING_TIPS",nil,param,0.00) ) 
		return  
	end 
	local _tippath; _tippath = "ClubUI/ClubTipsUI/UpPushTips";
	CS.Eight.Framework.EIFrameWork.StartCoroutine(RoleInfoUtil.LoadAsynUIPrefab(nil, _tippath, (function(obj)
		local _tipui; _tipui = obj:GetComponent("ClubPushItemTipsUI");
		local title; title = "材料委任";
		_tipui:SetUp(this.ModelComList, 1) 
		local tipsDialogParam; tipsDialogParam = CS.EightGame.Logic.TipsDialogParam("CollectMaterial",title,obj,"确定",(function() 
			this:SendMaterialMsg() 
			return true 
		end), "返回", (function()
			return true 
		end), 5, 0) 
		this.IsRequst = false 
		delegationset(false, false, "CS.EightGame.Logic.TipsDialogParam:ondismiss", tipsDialogParam, nil, "ondismiss", (function()
			if not isnil(obj) then
				CS.UnityEngine.Object.Destroy(obj) 
			end 
		end)) 
		CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_COMMONT_TIPS_DIALOG",nil,tipsDialogParam,0.00) ) 
	end)), false) 
end

function _lua_ClubEntrustPartyUI:SendMaterialMsg()
	GameLog("------------------------------_lua_ClubEntrustPartyUI SendMaterialMsg------------------------------")
	if this.IsRequst then
		return  
	end 
	this.IsRequst = true 
	local srv; srv = XLuaScriptUtils.ServiceCenter():GetService(typeof(CS.EightGame.Component.ClubService));
	local request; request = CS.EightGame.Data.Server.SendCollectMaterial();
	srv:SendCollectMaterial(request, (function(arg1)
		local errorc; errorc = arg1;
		if (errorc ~= 200) then
			local _tipstr; _tipstr = CS.EightGame.Component.NetCode.GetDesc(errorc);
			local param; param = CS.EightGame.Logic.TipStruct(_tipstr,0.20) ;
			CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_FLOATING_TIPS",nil,param,0.00) ) 
		else
			CS.EightGame.Logic.FloatingTextTipUIRoot.SetFloattingTip("交付成功", 0.00) 
			this:SetUp() 
			CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("FRESH_CLUB_PARTYINFO",nil,nil,0.00) ) 
		end 
		this.IsRequst = false 
	end), nil) 
end

function _lua_ClubEntrustPartyUI:hotfix()
	xlua.hotfix(ClubEntrustPartyUI, {
       ['Init'] = function(this)
           _lua_ClubEntrustPartyUI:Ref(this)
           return _lua_ClubEntrustPartyUI:Init()
       end,
       ['SetReward'] = function(this, guilditem)
           _lua_ClubEntrustPartyUI:Ref(this)
           return _lua_ClubEntrustPartyUI:SetReward( guilditem)
       end,
       ['OnSendCollectMaterialFunction'] = function(this)
           _lua_ClubEntrustPartyUI:Ref(this)
           return _lua_ClubEntrustPartyUI:OnSendCollectMaterialFunction()
       end,
       ['SendMaterialMsg'] = function(this)
           _lua_ClubEntrustPartyUI:Ref(this)
           return _lua_ClubEntrustPartyUI:SendMaterialMsg()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubEntrustPartyUI)