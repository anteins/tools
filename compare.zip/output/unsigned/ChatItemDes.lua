
local this = nil
_lua_ChatItemDes = BaseCom:New('_lua_ChatItemDes')
function _lua_ChatItemDes:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatItemDes:AnalysSendStr( obj)
	GameLog("------------------------------_lua_ChatItemDes AnalysSendStr------------------------------")
	local itemContent; itemContent = obj;
	local contentArray; contentArray = Split(itemContent, wraparray{"itemtype=",",itemstaticid=",",itemgid=",},1);
	local itemtype; itemtype = "";
	local itemstiticid; itemstiticid = 0;
	local itemGid; itemGid = 0;
	local extraObj; extraObj = "";
	if (obj_len(contentArray) > 2) then
		itemtype = DictGetValue(contentArray, 1) 
		itemstiticid = tonumber(DictGetValue(contentArray, 2)) 
		itemGid = CS.System.Int64.Parse(DictGetValue(contentArray, 3)) 
	end 
	local t; t = ChatMsgURLContent(itemtype,itemstiticid,itemGid,"",itemContent,"") ;
	return t 
end

function _lua_ChatItemDes:hotfix()
	xlua.hotfix(ChatItemDes, {
       ['AnalysSendStr'] = function(this, obj)
           _lua_ChatItemDes:Ref(this)
           return _lua_ChatItemDes:AnalysSendStr( obj)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatItemDes)