
local this = nil
_lua_ClubApplyerListDialogNode = BaseCom:New('_lua_ClubApplyerListDialogNode')
function _lua_ClubApplyerListDialogNode:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubApplyerListDialogNode:CreateAssets()
	GameLog("------------------------------_lua_ClubApplyerListDialogNode CreateAssets------------------------------")
	local c; c = XLuaScriptUtils.GameResources():LoadAsyn(("GameAssets/Prefabs/UI/" .. ClubApplyerListDialogNode._uiPath), "prefab", false);
	coroutine.yield(c.coroutine) 
	local prefab; prefab = c.res;
	if isnil(prefab) then
		CS.Eight.Framework.EIDebuger.LogError("[ClubApplyerListPageUI] load ClubTipsUI error") 
		return nil 
	end 
	local obj; obj = NGUITools.AddChild__UnityEngine_GameObject__UnityEngine_GameObject(NGUITools, this.dialogParent.gameObject, prefab);
	this._applyerListCom = obj:GetComponent("ClubApplyerListPageUI") 
	this._applyerListCom:Init() 
	this:AddEventListener("FRESH_CLUB_APPLYER_PAGE", function(e) this._applyerListCom:OnEnter(e) end) 
	this._isReady = true 
	return nil 
end

function _lua_ClubApplyerListDialogNode:OnExit()
	GameLog("------------------------------_lua_ClubApplyerListDialogNode OnExit------------------------------")
	return nil 
end

function _lua_ClubApplyerListDialogNode:hotfix()
	xlua.hotfix(ClubApplyerListDialogNode, {
       ['CreateAssets'] = function(this)
           _lua_ClubApplyerListDialogNode:Ref(this)
           return util.cs_generator(function()
               _lua_ClubApplyerListDialogNode:CreateAssets()
           end)
       end,
       ['OnExit'] = function(this)
           _lua_ClubApplyerListDialogNode:Ref(this)
           return _lua_ClubApplyerListDialogNode:OnExit()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubApplyerListDialogNode)