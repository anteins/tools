
local this = nil
_lua_ChatEmojiItemCom = BaseCom:New('_lua_ChatEmojiItemCom')
function _lua_ChatEmojiItemCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatEmojiItemCom:SetData( chatemoji, callbackSelect)
	GameLog("------------------------------_lua_ChatEmojiItemCom SetData------------------------------")
	if isequal(this._chatemoji, chatemoji) then
		return  
	end 
	this._chatemoji = chatemoji 
	this._callbackSelect = callbackSelect 
	CS.Eight.Framework.EIFrameWork.StartCoroutine(this:LoadEmojiTexture(), false) 
end

function _lua_ChatEmojiItemCom:LoadEmojiTexture()
	GameLog("------------------------------_lua_ChatEmojiItemCom LoadEmojiTexture------------------------------")
	local c; c = XLuaScriptUtils.GameResources():LoadAsyn(("GameAssets/Textures/Icon/" .. this._chatemoji.image), "png", true);
	coroutine.yield(c.coroutine) 
	local tex; tex = c.res;
	if not isnil(tex) then
		this._emojiTexture.mainTexture = tex 
	end 
	NGUITools.AddWidgetCollider__UnityEngine_GameObject(this.gameObject) 
end

function _lua_ChatEmojiItemCom:OnClick()
	GameLog("------------------------------_lua_ChatEmojiItemCom OnClick------------------------------")
	if this ~= "_callbackSelect" then
		this._callbackSelect(this) 
	end 
end

function _lua_ChatEmojiItemCom:hotfix()
	xlua.hotfix(ChatEmojiItemCom, {
       ['SetData'] = function(this, chatemoji, callbackSelect)
           _lua_ChatEmojiItemCom:Ref(this)
           return _lua_ChatEmojiItemCom:SetData( chatemoji, callbackSelect)
       end,
       ['LoadEmojiTexture'] = function(this)
           _lua_ChatEmojiItemCom:Ref(this)
           return util.cs_generator(function()
               _lua_ChatEmojiItemCom:LoadEmojiTexture()
           end)
       end,
       ['OnClick'] = function(this)
           _lua_ChatEmojiItemCom:Ref(this)
           return _lua_ChatEmojiItemCom:OnClick()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatEmojiItemCom)