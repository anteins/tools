
local this = nil
_lua_ChatFriendItemCom = BaseCom:New('_lua_ChatFriendItemCom')
function _lua_ChatFriendItemCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatFriendItemCom:SetPlayerNameLbl( playername)
	GameLog("------------------------------_lua_ChatFriendItemCom SetPlayerNameLbl------------------------------")
	if isnil(this._playerNameLbl) then
		return  
	end 
	this._playerNameLbl.text = playername 
end

function _lua_ChatFriendItemCom:SetPlayerVipLbl( playerVip)
	GameLog("------------------------------_lua_ChatFriendItemCom SetPlayerVipLbl------------------------------")
	if isnil(this._playerVipLvLbl) then
		return  
	end 
	this._playerVipLvLbl.transform.parent.gameObject:SetActive((playerVip ~= 0)) 
	this._playerVipLvLbl.text = tostring(playerVip) 
end

function _lua_ChatFriendItemCom:PlayerLvLbl( playerLv)
	GameLog("------------------------------_lua_ChatFriendItemCom PlayerLvLbl------------------------------")
	if isnil(this._playerLvLbl) then
		return  
	end 
	this._playerLvLbl.text = tostring(playerLv) 
end

function _lua_ChatFriendItemCom:SetOnlineLbl( online)
	GameLog("------------------------------_lua_ChatFriendItemCom SetOnlineLbl------------------------------")
	if isnil(this._onlineLbl) then
		return  
	end 
	this._onlineLbl.text = online 
end

function _lua_ChatFriendItemCom:SetGenderSprite( gender)
	GameLog("------------------------------_lua_ChatFriendItemCom SetGenderSprite------------------------------")
	if isnil(this._genderSprite) then
		return  
	end 
	this._genderSprite.spriteName = gender 
end

function _lua_ChatFriendItemCom:SetIcnTexture( str)
	GameLog("------------------------------_lua_ChatFriendItemCom SetIcnTexture------------------------------")
	if isnil(this._iconTexture) then
		return  
	end 
	CS.Eight.Framework.EIFrameWork.StartCoroutine(this:LoadTexture(str), false) 
end

function _lua_ChatFriendItemCom:LoadTexture( path)
	GameLog("------------------------------_lua_ChatFriendItemCom LoadTexture------------------------------")
	local c; c = XLuaScriptUtils.GameResources():LoadAsyn(path, "png", true);
	coroutine.yield(c.coroutine) 
	this._iconTexture.mainTexture = c.res 
end

function _lua_ChatFriendItemCom:SetRedSpriteActive( b)
	GameLog("------------------------------_lua_ChatFriendItemCom SetRedSpriteActive------------------------------")
	if isnil(this._redSprite) then
		return  
	end 
	this._redSprite.gameObject:SetActive(b) 
end

function _lua_ChatFriendItemCom:OnClick()
	GameLog("------------------------------_lua_ChatFriendItemCom OnClick------------------------------")
	if this ~= "_callbackSelect" then
		this._callbackSelect(this._friendSerData) 
	end 
end

function _lua_ChatFriendItemCom:hotfix()
	xlua.hotfix(ChatFriendItemCom, {
       ['SetPlayerNameLbl'] = function(this, playername)
           _lua_ChatFriendItemCom:Ref(this)
           return _lua_ChatFriendItemCom:SetPlayerNameLbl( playername)
       end,
       ['SetPlayerVipLbl'] = function(this, playerVip)
           _lua_ChatFriendItemCom:Ref(this)
           return _lua_ChatFriendItemCom:SetPlayerVipLbl( playerVip)
       end,
       ['PlayerLvLbl'] = function(this, playerLv)
           _lua_ChatFriendItemCom:Ref(this)
           return _lua_ChatFriendItemCom:PlayerLvLbl( playerLv)
       end,
       ['SetOnlineLbl'] = function(this, online)
           _lua_ChatFriendItemCom:Ref(this)
           return _lua_ChatFriendItemCom:SetOnlineLbl( online)
       end,
       ['SetGenderSprite'] = function(this, gender)
           _lua_ChatFriendItemCom:Ref(this)
           return _lua_ChatFriendItemCom:SetGenderSprite( gender)
       end,
       ['SetIcnTexture'] = function(this, str)
           _lua_ChatFriendItemCom:Ref(this)
           return _lua_ChatFriendItemCom:SetIcnTexture( str)
       end,
       ['LoadTexture'] = function(this, path)
           _lua_ChatFriendItemCom:Ref(this)
           return util.cs_generator(function()
               _lua_ChatFriendItemCom:LoadTexture( path)
           end)
       end,
       ['SetRedSpriteActive'] = function(this, b)
           _lua_ChatFriendItemCom:Ref(this)
           return _lua_ChatFriendItemCom:SetRedSpriteActive( b)
       end,
       ['OnClick'] = function(this)
           _lua_ChatFriendItemCom:Ref(this)
           return _lua_ChatFriendItemCom:OnClick()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatFriendItemCom)