
local this = nil
_lua_LoginAnimControlCom = BaseCom:New('_lua_LoginAnimControlCom')
function _lua_LoginAnimControlCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LoginAnimControlCom:OnAnimHandler()
	GameLog("------------------------------_lua_LoginAnimControlCom OnAnimHandler------------------------------")
	if this ~= "_finishCallback" then
		this._finishCallback() 
	end 
end

function _lua_LoginAnimControlCom:OnAnimHandleString( str)
	GameLog("------------------------------_lua_LoginAnimControlCom OnAnimHandleString------------------------------")
end

function _lua_LoginAnimControlCom:OnAnimHandleInt( i)
	GameLog("------------------------------_lua_LoginAnimControlCom OnAnimHandleInt------------------------------")
end

function _lua_LoginAnimControlCom:OnAnimName( animName)
	GameLog("------------------------------_lua_LoginAnimControlCom OnAnimName------------------------------")
end

function _lua_LoginAnimControlCom:SetFinishCallback( finishCallback)
	GameLog("------------------------------_lua_LoginAnimControlCom SetFinishCallback------------------------------")
	this._finishCallback = finishCallback 
end

function _lua_LoginAnimControlCom:PlayStart()
	GameLog("------------------------------_lua_LoginAnimControlCom PlayStart------------------------------")
	this.Door:Reset() 
	this.LoginStartAnimator:Play(this.AnimNameStart) 
end

function _lua_LoginAnimControlCom:PlayEnter()
	GameLog("------------------------------_lua_LoginAnimControlCom PlayEnter------------------------------")
	this.LoginConnectAnimator:Play(this.AnimNameConnect) 
end

function _lua_LoginAnimControlCom:PlayOpen()
	GameLog("------------------------------_lua_LoginAnimControlCom PlayOpen------------------------------")
	this.LoginLeaveAnimator:Play(this.AnimNameLeave) 
end

function _lua_LoginAnimControlCom:Init( entity)
	GameLog("------------------------------_lua_LoginAnimControlCom Init------------------------------")
	this:Setup(entity) 
	this.Door:Setup(entity) 
end

function _lua_LoginAnimControlCom:hotfix()
	xlua.hotfix(LoginAnimControlCom, {
       ['OnAnimHandler'] = function(this)
           _lua_LoginAnimControlCom:Ref(this)
           return _lua_LoginAnimControlCom:OnAnimHandler()
       end,
       ['OnAnimHandleString'] = function(this, str)
           _lua_LoginAnimControlCom:Ref(this)
           return _lua_LoginAnimControlCom:OnAnimHandleString( str)
       end,
       ['OnAnimHandleInt'] = function(this, i)
           _lua_LoginAnimControlCom:Ref(this)
           return _lua_LoginAnimControlCom:OnAnimHandleInt( i)
       end,
       ['OnAnimName'] = function(this, animName)
           _lua_LoginAnimControlCom:Ref(this)
           return _lua_LoginAnimControlCom:OnAnimName( animName)
       end,
       ['SetFinishCallback'] = function(this, finishCallback)
           _lua_LoginAnimControlCom:Ref(this)
           return _lua_LoginAnimControlCom:SetFinishCallback( finishCallback)
       end,
       ['PlayStart'] = function(this)
           _lua_LoginAnimControlCom:Ref(this)
           return _lua_LoginAnimControlCom:PlayStart()
       end,
       ['PlayEnter'] = function(this)
           _lua_LoginAnimControlCom:Ref(this)
           return _lua_LoginAnimControlCom:PlayEnter()
       end,
       ['PlayOpen'] = function(this)
           _lua_LoginAnimControlCom:Ref(this)
           return _lua_LoginAnimControlCom:PlayOpen()
       end,
       ['Init'] = function(this, entity)
           _lua_LoginAnimControlCom:Ref(this)
           return _lua_LoginAnimControlCom:Init( entity)
       end,
   })
end

table.insert(g_tbHotfix, _lua_LoginAnimControlCom)