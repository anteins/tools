
local this = nil
_lua_ClickEffectUI = BaseCom:New('_lua_ClickEffectUI')
function _lua_ClickEffectUI:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClickEffectUI:CreatUI()
	GameLog("------------------------------_lua_ClickEffectUI CreatUI------------------------------")
	local coroutine; coroutine = XLuaScriptUtils.GameResources():LoadAsyn(("GameAssets/Prefabs/UI/" .. ClickEffectUI.effectPath), "prefab", false);
	if coroutine.coroutine then
coroutine.yield(coroutine.coroutine)
end
	local prefab; prefab = coroutine.res;
	if isnil(prefab) then
		CS.Eight.Framework.EIDebuger.LogError((("the prefab don\'t found on the path (path=" .. ClickEffectUI.effectPath) + ")")) 
		return nil 
	end 
	local go; go = GameUtility.InstantiateGameObject(prefab, nil, "EffectUI");
	this._controller = go:GetComponent("ClickEffectController") 
	this:BindComponent(this._controller)
	this._isReady = true 
end

function _lua_ClickEffectUI:hotfix()
	xlua.hotfix(ClickEffectUI, {
       ['CreatUI'] = function(this)
           _lua_ClickEffectUI:Ref(this)
           return util.cs_generator(function()
               _lua_ClickEffectUI:CreatUI()
           end)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClickEffectUI)