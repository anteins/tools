
local this = nil
_lua_ClubDonataTipsUI = BaseCom:New('_lua_ClubDonataTipsUI')
function _lua_ClubDonataTipsUI:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubDonataTipsUI:SetUp( teamReawardStr, myReawardStr, diamondCost)
	GameLog("------------------------------_lua_ClubDonataTipsUI SetUp------------------------------")
	this.DanataValLab.text = CS.System.String.Format("[4ddbff]#ICON_DIAMOND  {0}[-]", diamondCost) 
	this.TeamRewardLab.text = ("冒险团获得:  " .. teamReawardStr) 
	this.MyRewardLab.text = ("个人获得:  " .. myReawardStr) 
end

function _lua_ClubDonataTipsUI:hotfix()
	xlua.hotfix(ClubDonataTipsUI, {
       ['SetUp'] = function(this, teamReawardStr, myReawardStr, diamondCost)
           _lua_ClubDonataTipsUI:Ref(this)
           return _lua_ClubDonataTipsUI:SetUp( teamReawardStr, myReawardStr, diamondCost)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubDonataTipsUI)