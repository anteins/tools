
local this = nil
_lua_LogOutputHandler = BaseCom:New('_lua_LogOutputHandler')
function _lua_LogOutputHandler:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LogOutputHandler:Init()
	GameLog("------------------------------_lua_LogOutputHandler Init------------------------------")
end

function _lua_LogOutputHandler:OnEnable()
	GameLog("------------------------------_lua_LogOutputHandler OnEnable------------------------------")
	CS.UnityEngine.Application.RegisterLogCallback(function(logString, stackTrace, type) this:HandleLog(logString, stackTrace, type) end) 
end

function _lua_LogOutputHandler:OnDisable()
	GameLog("------------------------------_lua_LogOutputHandler OnDisable------------------------------")
	CS.UnityEngine.Application.RegisterLogCallback(nil) 
end

function _lua_LogOutputHandler:HandleLog( logString, stackTrace, type)
	GameLog("------------------------------_lua_LogOutputHandler HandleLog------------------------------")
	if ((type ~= 0) or (type ~= 4)) then
		return  
	end 
	local parameters; parameters = "";
	parameters = (parameters + ("Level=" .. CS.UnityEngine.WWW.EscapeURL(type:tostring()))) 
	parameters = (parameters + "&") 
	parameters = (parameters + ("Message=" .. CS.UnityEngine.WWW.EscapeURL(logString))) 
	parameters = (parameters + "&") 
	parameters = (parameters + ("Stack_Trace=" .. CS.UnityEngine.WWW.EscapeURL(stackTrace))) 
	parameters = (parameters + "&") 
	parameters = (parameters + ("Device_Model=" .. CS.UnityEngine.WWW.EscapeURL(CS.UnityEngine.SystemInfo.deviceModel))) 
	local url; url = ((((((("http://" .. this.project) + ".") + this.serviceAddr) + "/logstores/") + this.logstore) + "/track?APIVersion=0.6.0&") + parameters);
end

function _lua_LogOutputHandler:SendData( url)
	GameLog("------------------------------_lua_LogOutputHandler SendData------------------------------")
	local sendLog; sendLog = CS.UnityEngine.WWW(url);
	coroutine.yield(sendLog) 
end

function _lua_LogOutputHandler:hotfix()
	xlua.hotfix(LogOutputHandler, {
       ['Init'] = function(this)
           _lua_LogOutputHandler:Ref(this)
           return _lua_LogOutputHandler:Init()
       end,
       ['OnEnable'] = function(this)
           _lua_LogOutputHandler:Ref(this)
           return _lua_LogOutputHandler:OnEnable()
       end,
       ['OnDisable'] = function(this)
           _lua_LogOutputHandler:Ref(this)
           return _lua_LogOutputHandler:OnDisable()
       end,
       ['HandleLog'] = function(this, logString, stackTrace, type)
           _lua_LogOutputHandler:Ref(this)
           return _lua_LogOutputHandler:HandleLog( logString, stackTrace, type)
       end,
       ['SendData'] = function(this, url)
           _lua_LogOutputHandler:Ref(this)
           return util.cs_generator(function()
               _lua_LogOutputHandler:SendData( url)
           end)
       end,
   })
end

table.insert(g_tbHotfix, _lua_LogOutputHandler)