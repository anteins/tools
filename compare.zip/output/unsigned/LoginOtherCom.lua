
local this = nil
_lua_LoginOtherCom = BaseCom:New('_lua_LoginOtherCom')
function _lua_LoginOtherCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LoginOtherCom:Init()
	GameLog("------------------------------_lua_LoginOtherCom Init------------------------------")
	this:LoadText("LinshiTxt/Deal", this.DealData) 
	this.NoticData.text = "[00ff00]冒险者,请打开你的网络![-]" 
	this.NoticSB.value = 0 
	CS.Eight.Framework.EIFrameWork.Instance:AddEventListener("SET_NOTIC", function(e) this:FreshNoticStr(e) end) 
	CS.Eight.Framework.EIFrameWork.Instance:AddEventListener("OPEN_NOTICPAGE", function(e) this:WhenDisconnet(e) end) 
end

function _lua_LoginOtherCom:OpenRegisterPage()
	GameLog("------------------------------_lua_LoginOtherCom OpenRegisterPage------------------------------")
	this:ResetData() 
	this:OpenDealPage() 
	this.IsRegister = true 
end

function _lua_LoginOtherCom:CloseRegisterPage()
	GameLog("------------------------------_lua_LoginOtherCom CloseRegisterPage------------------------------")
	GameUtility.TweenScaleClose(this.RegisterObj) 
end

function _lua_LoginOtherCom:OpenDealPage()
	GameLog("------------------------------_lua_LoginOtherCom OpenDealPage------------------------------")
	GameUtility.TweenScaleOpen(this.DealObj) 
end

function _lua_LoginOtherCom:CloseDealPage( obj)
	GameLog("------------------------------_lua_LoginOtherCom CloseDealPage------------------------------")
	GameUtility.TweenScaleClose(this.DealObj) 
	if this.IsRegister then
		if Contains(obj.name, "Confirm") then
			GameUtility.TweenScaleOpen(this.RegisterObj) 
		end 
	end 
	this.IsRegister = false 
end

function _lua_LoginOtherCom:OpenNoticePage()
	GameLog("------------------------------_lua_LoginOtherCom OpenNoticePage------------------------------")
	GameUtility.TweenScaleOpen(this.NoticeObj) 
end

function _lua_LoginOtherCom:CloseNoticePage()
	GameLog("------------------------------_lua_LoginOtherCom CloseNoticePage------------------------------")
	GameUtility.TweenScaleClose(this.NoticeObj) 
end

function _lua_LoginOtherCom:Registersucceed()
	GameLog("------------------------------_lua_LoginOtherCom Registersucceed------------------------------")
	if (obj_len(this.RPassword.value) < 6) then
		this:ErrorTips("密码要6个字符以上") 
	elseif (this.RPassword.value ~= this.RCPassword.value) then
		this:ErrorTips("确定密码和密码不同,请重新输入") 
	else
		this:CloseRegisterPage() 
		GameLog("要向服务器提交一下申请") 
		local rInfo; rInfo = CS.EightGame.Logic.LoginUserParam("eichannel_empty","eichannel_empty",this.RName.value,this.RPassword.value) ;
		CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("LOGIN_REGISTER",nil,rInfo,0) ) 
	end 
end

function _lua_LoginOtherCom:ResetData()
	GameLog("------------------------------_lua_LoginOtherCom ResetData------------------------------")
	this.RName.value = "" 
	this.RPassword.value = "" 
	this.RCPassword.value = "" 
end

function _lua_LoginOtherCom:ErrorTips( errorStr)
	GameLog("------------------------------_lua_LoginOtherCom ErrorTips------------------------------")
	local tip; tip = CS.EightGame.Logic.CommonTipsParam(errorStr,0,nil,nil,"") ;
	tip.isShowOKCancelBtn = false 
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_TIPS",nil,tip,0.00) ) 
end

function _lua_LoginOtherCom:LoadText( path, DataLabel)
	GameLog("------------------------------_lua_LoginOtherCom LoadText------------------------------")
end

function _lua_LoginOtherCom:FreshNoticStr( e)
	GameLog("------------------------------_lua_LoginOtherCom FreshNoticStr------------------------------")
	local strList; strList = e.extraInfo;
	if CS.System.String.IsNullOrEmpty(DictGetValue(strList, 0)) then
		this.NoticeTitle.text = "更新公告" 
	else
		this.NoticeTitle.text = DictGetValue(strList, 0) 
	end 
	this.NoticData.text = DictGetValue(strList, 1) 
end

function _lua_LoginOtherCom:WhenDisconnet( e)
	GameLog("------------------------------_lua_LoginOtherCom WhenDisconnet------------------------------")
	this:LoadText("LinshiTxt/Notice", this.NoticData) 
end

function _lua_LoginOtherCom:hotfix()
	xlua.hotfix(LoginOtherCom, {
       ['Init'] = function(this)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:Init()
       end,
       ['OpenRegisterPage'] = function(this)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:OpenRegisterPage()
       end,
       ['CloseRegisterPage'] = function(this)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:CloseRegisterPage()
       end,
       ['OpenDealPage'] = function(this)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:OpenDealPage()
       end,
       ['CloseDealPage'] = function(this, obj)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:CloseDealPage( obj)
       end,
       ['OpenNoticePage'] = function(this)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:OpenNoticePage()
       end,
       ['CloseNoticePage'] = function(this)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:CloseNoticePage()
       end,
       ['Registersucceed'] = function(this)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:Registersucceed()
       end,
       ['ResetData'] = function(this)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:ResetData()
       end,
       ['ErrorTips'] = function(this, errorStr)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:ErrorTips( errorStr)
       end,
       ['LoadText'] = function(this, path, DataLabel)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:LoadText( path, DataLabel)
       end,
       ['FreshNoticStr'] = function(this, e)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:FreshNoticStr( e)
       end,
       ['WhenDisconnet'] = function(this, e)
           _lua_LoginOtherCom:Ref(this)
           return _lua_LoginOtherCom:WhenDisconnet( e)
       end,
   })
end

table.insert(g_tbHotfix, _lua_LoginOtherCom)