
local this = nil
_lua_LookAtTarget = BaseCom:New('_lua_LookAtTarget')
function _lua_LookAtTarget:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LookAtTarget:LateUpdate()
	GameLog("------------------------------_lua_LookAtTarget LateUpdate------------------------------")
	if not isnil(this.target) then
		local dir; dir = this.target.position - this.mTrans.position;
		local mag; mag = dir.magnitude;
		if (mag > 0.00) then
			local lookRot; lookRot = CS.UnityEngine.Quaternion.LookRotation(dir);
			this.mTrans.rotation = CS.UnityEngine.Quaternion.Slerp(this.mTrans.rotation, lookRot, CS.UnityEngine.Mathf.Clamp01((this.speed * CS.UnityEngine.Time.deltaTime))) 
		end 
	end 
end

function _lua_LookAtTarget:hotfix()
	xlua.hotfix(LookAtTarget, {
       ['LateUpdate'] = function(this)
           _lua_LookAtTarget:Ref(this)
           return _lua_LookAtTarget:LateUpdate()
       end,
   })
end

table.insert(g_tbHotfix, _lua_LookAtTarget)