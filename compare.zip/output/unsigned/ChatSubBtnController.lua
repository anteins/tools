
local this = nil
_lua_ChatSubBtnController = BaseCom:New('_lua_ChatSubBtnController')
function _lua_ChatSubBtnController:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatSubBtnController:Awake()
	GameLog("------------------------------_lua_ChatSubBtnController Awake------------------------------")
	this.gameObject:SetActive(false) 
end

function _lua_ChatSubBtnController:SetData( com, callback)
	GameLog("------------------------------_lua_ChatSubBtnController SetData------------------------------")
	this._moveGroup.transform.parent = com.transform 
	this._moveGroup.transform.localPosition = CS.UnityEngine.Vector3(-150.00,10.00,0) 
	this:SetMoveGroupActive(true) 
	this._chatMsg = com._chatmsg 
	this._callbackSelect = callback 
	CS.Eight.Framework.EIFrameWork.StartCoroutine(this:LoadItemPrefab(), false) 
end

function _lua_ChatSubBtnController:LoadItemPrefab()
	GameLog("------------------------------_lua_ChatSubBtnController LoadItemPrefab------------------------------")
	if isnil(this._itemPrefab) then
		local coroutine; coroutine = XLuaScriptUtils.GameResources():LoadAsyn(CS.System.String.Format("{0}{1}", "GameAssets/Prefabs/UI/", this._itemPrefabPath), "prefab", false);
		if coroutine.coroutine then
coroutine.yield(coroutine.coroutine)
end
		this._itemPrefab = coroutine.res 
		this:InitItems() 
	else
		this:InitItems() 
	end 
end

function _lua_ChatSubBtnController:CallbackClickSubBtn( chatSubType)
	GameLog("------------------------------_lua_ChatSubBtnController CallbackClickSubBtn------------------------------")
	local param; param = ChatSubCallBackParam() ;
	param.chatsubtype = chatSubType 
	param._friendId = this._chatMsg.playerid 
	param.friendName = this._chatMsg.playername 
	this:SetMoveGroupActive(false) 
	if this ~= "_callbackSelect" then
		this._callbackSelect(param) 
	end 
end

function _lua_ChatSubBtnController:ClickClose()
	GameLog("------------------------------_lua_ChatSubBtnController ClickClose------------------------------")
	this:SetMoveGroupActive(false) 
end

function _lua_ChatSubBtnController:SetMoveGroupActive( b)
	GameLog("------------------------------_lua_ChatSubBtnController SetMoveGroupActive------------------------------")
	if isnil(this._moveGroup) then
		return  
	end 
	this._moveGroup.gameObject:SetActive(b) 
	this.gameObject:SetActive(b) 
end

function _lua_ChatSubBtnController:hotfix()
	xlua.hotfix(ChatSubBtnController, {
       ['Awake'] = function(this)
           _lua_ChatSubBtnController:Ref(this)
           return _lua_ChatSubBtnController:Awake()
       end,
       ['SetData'] = function(this, com, callback)
           _lua_ChatSubBtnController:Ref(this)
           return _lua_ChatSubBtnController:SetData( com, callback)
       end,
       ['LoadItemPrefab'] = function(this)
           _lua_ChatSubBtnController:Ref(this)
           return util.cs_generator(function()
               _lua_ChatSubBtnController:LoadItemPrefab()
           end)
       end,
       ['CallbackClickSubBtn'] = function(this, chatSubType)
           _lua_ChatSubBtnController:Ref(this)
           return _lua_ChatSubBtnController:CallbackClickSubBtn( chatSubType)
       end,
       ['ClickClose'] = function(this)
           _lua_ChatSubBtnController:Ref(this)
           return _lua_ChatSubBtnController:ClickClose()
       end,
       ['SetMoveGroupActive'] = function(this, b)
           _lua_ChatSubBtnController:Ref(this)
           return _lua_ChatSubBtnController:SetMoveGroupActive( b)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatSubBtnController)