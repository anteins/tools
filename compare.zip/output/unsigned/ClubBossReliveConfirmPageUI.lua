
local this = nil
_lua_ClubBossReliveConfirmPageUI = BaseCom:New('_lua_ClubBossReliveConfirmPageUI')
function _lua_ClubBossReliveConfirmPageUI:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubBossReliveConfirmPageUI:Init( bossNum, costDiamondPerUnit, freeTime, timeUnit)
	GameLog("------------------------------_lua_ClubBossReliveConfirmPageUI Init------------------------------")
	this._bossNum = bossNum 
	this._costDiamondPerUnit = costDiamondPerUnit 
	this._freeTime = freeTime 
	this._timeUnit = timeUnit 
end

function _lua_ClubBossReliveConfirmPageUI:GetCostDiamond()
	GameLog("------------------------------_lua_ClubBossReliveConfirmPageUI GetCostDiamond------------------------------")
	return this._costDiamond 
end

function _lua_ClubBossReliveConfirmPageUI:UpdateUI()
	GameLog("------------------------------_lua_ClubBossReliveConfirmPageUI UpdateUI------------------------------")
	local curTime; curTime = AlarmManager.Instance:currentTimeMillis();
	if ((this._bossNum == nil) or (curTime < 0)) then
		return  
	end 
	this._costDiamond = CS.UnityEngine.Mathf.CeilToInt((( div(this._bossNum.endtime, 1000) -div(curTime, 1000)  -this._freeTime  ) / this._timeUnit))*this._costDiamondPerUnit  
	this:SetCostLabel(this._costDiamond) 
end

function _lua_ClubBossReliveConfirmPageUI:SetCostLabel( costDiamond)
	GameLog("------------------------------_lua_ClubBossReliveConfirmPageUI SetCostLabel------------------------------")
	if isnil(this.costLabel) then
		return  
	end 
	this.costLabel.text = (costDiamond <= 0) and "免费复活" or CS.System.String.Format("花费 #ICON_DIAMOND [56e5e7]{0}[-] 立刻复活", costDiamond)  
end

function _lua_ClubBossReliveConfirmPageUI:hotfix()
	xlua.hotfix(ClubBossReliveConfirmPageUI, {
       ['Init'] = function(this, bossNum, costDiamondPerUnit, freeTime, timeUnit)
           _lua_ClubBossReliveConfirmPageUI:Ref(this)
           return _lua_ClubBossReliveConfirmPageUI:Init( bossNum, costDiamondPerUnit, freeTime, timeUnit)
       end,
       ['GetCostDiamond'] = function(this)
           _lua_ClubBossReliveConfirmPageUI:Ref(this)
           return _lua_ClubBossReliveConfirmPageUI:GetCostDiamond()
       end,
       ['UpdateUI'] = function(this)
           _lua_ClubBossReliveConfirmPageUI:Ref(this)
           return _lua_ClubBossReliveConfirmPageUI:UpdateUI()
       end,
       ['SetCostLabel'] = function(this, costDiamond)
           _lua_ClubBossReliveConfirmPageUI:Ref(this)
           return _lua_ClubBossReliveConfirmPageUI:SetCostLabel( costDiamond)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubBossReliveConfirmPageUI)