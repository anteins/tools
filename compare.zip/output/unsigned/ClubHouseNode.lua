
local this = nil
_lua_ClubHouseNode = BaseCom:New('_lua_ClubHouseNode')
function _lua_ClubHouseNode:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubHouseNode:CreateView()
	GameLog("------------------------------_lua_ClubHouseNode CreateView------------------------------")
	local coroutine; coroutine = XLuaScriptUtils.GameResources():LoadAsyn(CS.System.String.Format("{0}{1}", "BaseAssets/Prefabs/Scenes/", this._3dprefabPath), "prefab", false);
	if coroutine.coroutine then
coroutine.yield(coroutine.coroutine)
end
	local prefab; prefab = coroutine.res;
	if isnil(prefab) then
		GameLog(CS.System.String.Format(" load { 0 } error , please check", this._3dprefabPath)) 
		return nil 
	end 
	local go; go = GameUtility.InstantiateGameObject(prefab, nil, "ClubSence");
	this._viewController = go:GetComponent("ClubHouseController") 
	this._viewController:Init() 
	ClubHouseNode._clubCamera = this._viewController.ClubCamera 
	local uicoroutine; uicoroutine = XLuaScriptUtils.GameResources():LoadAsyn(CS.System.String.Format("{0}{1}", "GameAssets/Prefabs/UI/", this._uiprefabPath), "prefab", false);
	coroutine.yield(uicoroutine.coroutine) 
	local uiprefab; uiprefab = uicoroutine.res;
	if isnil(uiprefab) then
		GameLog(CS.System.String.Format(" load { 0 } error , please check", this._uiprefabPath)) 
		return nil 
	end 
	local uigo; uigo = GameUtility.InstantiateGameObject(uiprefab, nil, "ClubMainPanel");
	this._clubMainWindow = uigo:GetComponent("ClubMainWindow") 
	this._clubMainWindow:Init() 
	this:BindComponent(this._clubMainWindow)
	local redTipMgr; redTipMgr = CS.Eight.Framework.EIFrameWork.GetComponent(RedTipManager);
	if (redTipMgr ~= nil) then
		redTipMgr:UpdateGuildInfoFlags() 
	end 
	this:InitFunciton() 
	this._isReady = true 
end

function _lua_ClubHouseNode:InitFunciton()
	GameLog("------------------------------_lua_ClubHouseNode InitFunciton------------------------------")
	this:AddEventListener("GO_NPC_PAGE", function(e) this:GoEnterOtherPage(e) end) 
	this:AddEventListener("SET_CLUB_FIRST_TIP_OVER", function(e) this._clubMainWindow:CloseFirstTip(e) end) 
	this:AddEventListener("CHECKOUT_CLUB_MAINMSG", function(e) this._clubMainWindow.BoxPageUI:OnRemove(e) end) 
	this:AddEventListener("ADD_CLUB_MAIN_MSG", function(e) this._clubMainWindow.BoxPageUI:OnAddMsg(e) end) 
	this:AddEventListener("SET_CLUB_CAMERA", function(e) this:SetClubCamera(e) end) 
	this:AddEventListener(CS.EightGame.Component.NetworkUtils.GetSerDataUpdateEventType(typeof(CS.EightGame.Data.Server.GuildProsperity)), function(e) this:check_prosperity_guild_play(e) end) 
	this:AddEventListener(CS.EightGame.Component.NetworkUtils.GetSerDataUpdateEventType(typeof(CS.EightGame.Data.Server.ClubDataNotify)), function(e) this:check_info_data(e) end) 
	this:AddEventListener(CS.EightGame.Component.NetworkUtils.GetSerDataUpdateEventType(typeof(CS.EightGame.Data.Server.BussinessNpc)), function(e) this:check_shop_data(e) end) 
	this:AddEventListener(CS.EightGame.Component.NetworkUtils.GetSerDataUpdateEventType(typeof(CS.EightGame.Data.Server.PostInitMeditationRoom)), function(e) this:check_meditationroom_data(e) end) 
	this:AddEventListener(CS.EightGame.Component.NetworkUtils.GetSerDataUpdateEventType(typeof(CS.EightGame.Data.Server.GuildNum)), function(e) this:chekc_guild_num_play(e) end) 
	this:AddEventListener(CS.EightGame.Component.NetworkUtils.GetSerDataUpdateEventType(typeof(CS.EightGame.Data.Server.CrusadeBoss)), function(e) this:check_boss_guild_play(e) end) 
	this:AddEventListener("SET_OFF_SINGIN_TIPS", function(e) this:SetOffSinginTip(e) end) 
	this:AddEventListener("CLUB_GET_FOOD", function(e) this:OnCallGetFoodMsg(e) end) 
end

function _lua_ClubHouseNode:SetClubCamera( e)
	GameLog("------------------------------_lua_ClubHouseNode SetClubCamera------------------------------")
	local isActive; isActive = ( e ).boolParam;
	ClubUtility.HaveMask = isActive 
end

function _lua_ClubHouseNode:GoPartyPartyPage( e)
	GameLog("------------------------------_lua_ClubHouseNode GoPartyPartyPage------------------------------")
	if ClubUtility.HaveMask then
		return  
	end 
	local paid; paid = e.extraInfo;
	local param; param = SubTypeAndParam() ;
	param._needOpenNode = CommonMainPartyNode 
	param._paramObj = paid 
	this.ViewParent:Push(typeof(SubHeaderNode), typeof(param)) 
end

function _lua_ClubHouseNode:GoUserPartyPartyPage( e)
	GameLog("------------------------------_lua_ClubHouseNode GoUserPartyPartyPage------------------------------")
	if ClubUtility.HaveMask then
		return  
	end 
	local paid; paid = e.extraInfo;
	local param; param = SubTypeAndParam() ;
	param._needOpenNode = MainUserPartyNode 
	param._paramObj = paid 
	this.ViewParent:Push(typeof(SubHeaderNode), typeof(param)) 
end

function _lua_ClubHouseNode:OnEnterDetailPage( e)
	GameLog("------------------------------_lua_ClubHouseNode OnEnterDetailPage------------------------------")
	local id; id = 0;
	local _parm; _parm = SubTypeAndParam() ;
	_parm._needOpenNode = CommonMainPartyNode 
	_parm._paramObj = id 
	this.ViewParent:Push(typeof(SubHeaderNode), typeof(_parm)) 
end

function _lua_ClubHouseNode:InitNpcsUI( e)
	GameLog("------------------------------_lua_ClubHouseNode InitNpcsUI------------------------------")
	if ((this._clubMainWindow.NpcsUI ~= nil) and (obj_len(this._clubMainWindow.NpcsUI) > 0)) then
		return  
	end 
	local npcs; npcs = this._viewController.STNpcs;
	npcs:Add(this._viewController.ClubHeader) 
	npcs:Add(this._viewController.ClubBestTeamer) 
	this._clubMainWindow:InitNpcsUI(npcs) 
end

function _lua_ClubHouseNode:GoEnterOtherPage( e)
	GameLog("------------------------------_lua_ClubHouseNode GoEnterOtherPage------------------------------")
	if this.isGolock then
		return  
	end 
	if ClubUtility.HaveMask then
		return  
	end 
	if ClubUtility.IsOut then
		this:OnCheckData() 
		return  
	end 
	local type; type = e.extraInfo;
	local pagetype; pagetype = type;
	local strtip; strtip = "";
	this.isGolock = true 
	if (CS.System.Convert.ToInt32(pagetype) == 1) then
		this:STNpcShowCall(pagetype, (function()
			this.ViewParent:Push(typeof(SubHeaderNode), typeof(ClubInfoNode)) 
		end)) 
	elseif (CS.System.Convert.ToInt32(pagetype) == 2) then
		this.isGolock = false 
	elseif (CS.System.Convert.ToInt32(pagetype) == 3) then
		this:STNpcShowCall(pagetype, (function()
			this.ViewParent:Push(typeof(SubHeaderNode), typeof(ClubShopNode)) 
		end)) 
	elseif (CS.System.Convert.ToInt32(pagetype) == 4) then
		this.isGolock = false 
	elseif (CS.System.Convert.ToInt32(pagetype) == 81) then
		this:STNpcShowCall(pagetype, (function()
			this.ViewParent:Push(typeof(SubHeaderNode), typeof(ClubPartyNode)) 
		end)) 
	elseif (CS.System.Convert.ToInt32(pagetype) == 82) then
		this._clubMainWindow:OnGoMroomFuntion() 
		this.isGolock = false 
	elseif (CS.System.Convert.ToInt32(pagetype) == 101) then
		this.ViewParent:Push(typeof(SubHeaderNode), typeof(SigninEnterNode)) 
	elseif (CS.System.Convert.ToInt32(pagetype) == 102) then
		this.ViewParent:Push(typeof(SubHeaderNode), typeof(AssignmentsWindowNode)) 
	end 
	if (not CS.System.String.IsNullOrEmpty(strtip)) then
		local param; param = CS.EightGame.Logic.TipStruct(strtip,0.20) ;
		CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_FLOATING_TIPS",nil,param,0.00) ) 
	end 
end

function _lua_ClubHouseNode:STNpcShowCall( type, _call)
	GameLog("------------------------------_lua_ClubHouseNode STNpcShowCall------------------------------")
	local _npc; _npc = this._viewController.STNpcs:Find((function(x) return (x.Data.PageType == type); end));
	local _temp; _temp = nil;
	if not isnil(_npc) then
		_temp = _npc.myAnimator 
	end 
	this:StartCoroutine(this:ShowAnimatorCall(type, _temp, _call)) 
end

function _lua_ClubHouseNode:ShowAnimatorCall( type, myAnimator, _call)
	GameLog("------------------------------_lua_ClubHouseNode ShowAnimatorCall------------------------------")
	this._viewController.ClubCamera:GetComponent(typeof(CS.UnityEngine.Animator)):SetInteger("npcpage", type) 
	if not isnil(myAnimator) then
		myAnimator:SetBool("idleshow", true) 
	end 
	coroutine.yield(CS.UnityEngine.WaitForSeconds(1.00)) 
	_call() 
	return nil 
end

function _lua_ClubHouseNode:OnCheckData()
	GameLog("------------------------------_lua_ClubHouseNode OnCheckData------------------------------")
	if ClubUtility.IsOut then
		ClubUtility.HaveMask = true 
		local tipsDialogParam; tipsDialogParam = CS.EightGame.Logic.TipsDialogParam("ClubKickTips","退团提示","您已被踢出冒险团","确认",(function() 
			local lobby; lobby = ( this.ViewParent );
			if (lobby ~= nil) then
				ClubUtility.IsInClubPage = false 
				CS.Eight.Framework.EIFrameWork.StartCoroutine(ClubUtility.WaitDoloading(), false) 
				local newInfo; newInfo = CS.EightGame.Logic.UIView.UIViewInfo() ;
				newInfo.viewType = CS.EightGame.Logic.MainWorldNode 
				newInfo.param = nil 
				local list; list = XLuaScriptUtils.new_List_1(typeof(CS.EightGame.Logic.UIView.UIViewInfo));
				list:Add(newInfo) 
				lobby:ForceRestStack(list) 
				lobby:Push(typeof(MainWorldNode), typeof(nil)) 
			end 
			return true 
		end), 5, 0) 
		CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_COMMONT_TIPS_DIALOG",nil,tipsDialogParam,0.00) ) 
	end 
end

function _lua_ClubHouseNode:CallbackClickRecharge()
	GameLog("------------------------------_lua_ClubHouseNode CallbackClickRecharge------------------------------")
	if FunctionOpenUtility.JudgeSingleFunctionById(se_functiontype.SE_FUNCTIONTYPE_PAY_MODULE , true) then
		this.ViewParent:Push(typeof(SubHeaderNode), typeof(RechargeViewNode)) 
	end 
end

function _lua_ClubHouseNode:OnExploreBtn()
	GameLog("------------------------------_lua_ClubHouseNode OnExploreBtn------------------------------")
	if (not FunctionOpenUtility.JudgeSingleFunctionById(se_functiontype.SE_FUNCTIONTYPE_EXPLORE_MODULE, true)) then
		return  
	end 
	this.ViewParent:Push(typeof(SubHeaderNode), typeof(ExploreViewNode)) 
end

function _lua_ClubHouseNode:UpdateTeamTipsSprite()
	GameLog("------------------------------_lua_ClubHouseNode UpdateTeamTipsSprite------------------------------")
	if isnil(this._clubMainWindow.HeaderUICom) then
		return  
	end 
	local funList; funList = XLuaScriptUtils.new_List_1(typeof(CS.System.Func));
	funList:Add((function()
		return (RankupCheckAvailable.GetDic().Count > 0) 
	end)) 
	funList:Add((function()
		return UpstarCheckAvailable.ContainsUpstar() 
	end)) 
	funList:Add((function()
		return LotteryCheckAvailable.IsHaveAvailable() 
	end)) 
	funList:Add((function()
		return RecruitCheckAvailable.ContainsRecruit() 
	end)) 
	local flag; flag = false;
	foreach(funList, function (item)
		local act = item.current
		if act() then
			flag = true 
			return "break";
		end 
			end)
end

function _lua_ClubHouseNode:UpdatePartnerTipsSprite()
	GameLog("------------------------------_lua_ClubHouseNode UpdatePartnerTipsSprite------------------------------")
	if isnil(this._clubMainWindow.HeaderUICom) then
		return  
	end 
	local funList; funList = XLuaScriptUtils.new_List_1(typeof(CS.System.Func));
	funList:Add((function()
		return (RankupCheckAvailable.GetDic().Count > 0) 
	end)) 
	funList:Add((function()
		return UpstarCheckAvailable.ContainsUpstar() 
	end)) 
	funList:Add((function()
		return RecruitCheckAvailable.ContainsRecruit() 
	end)) 
	local flag; flag = false;
	foreach(funList, function (item)
		local act = item.current
		if act() then
			flag = true 
			return "break";
		end 
			end)
end

function _lua_ClubHouseNode:UpdateLotteryTipsSprite()
	GameLog("------------------------------_lua_ClubHouseNode UpdateLotteryTipsSprite------------------------------")
	if isnil(this._clubMainWindow.HeaderUICom) then
		return  
	end 
	local flagList; flagList = XLuaScriptUtils.new_List_1(typeof(CS.System.Boolean));
	flagList:Add(LotteryCheckAvailable.IsHaveAvailable()) 
end

function _lua_ClubHouseNode:OnEnterRegister()
	GameLog("------------------------------_lua_ClubHouseNode OnEnterRegister------------------------------")
	this:UpdateUI(true) 
	this:AddEventListener(CS.EightGame.Logic.RechargeViewNode.Open_Recharge_View, function(e) this:OpenRechargeView(e) end) 
	this:AddEventListener(CS.EightGame.Component.NetworkUtils.GetSerDataUpdateEventType(typeof(CS.EightGame.Data.Server.PlayerSerData)), function(response) this:OnPlayerDataUpdate(response) end) 
	this:AddEventListener(CS.EightGame.Component.NetworkUtils.GetSerDataUpdateEventType(typeof(CS.EightGame.Data.Server.LotterySerData)), function(response) this:OnLotteryDataUpdate(response) end) 
	this:AddEventListener("UI_XMB_INVITE_GRID", function(e) this:OnUpdateXMBInvitePanel(e) end) 
	this:AddEventListener("UI_HEARTBEAT_MESSAGE", function(e) this:OnUpdateHeartbeat(e) end) 
	this:DispatchEvent(CS.Eight.Framework.EIBoolEvent("UI_EXPRESSION_ENABLE",false) ) 
	this._clubMainWindow.HeaderUICom._baseMode.clickBG.onClick:Clear() 
	EventDelegate.Add(this._clubMainWindow.HeaderUICom._baseMode.clickBG.onClick, function() this:OnClickHeader() end) 
	--活动方法
	this:AddEventListener("GET_DETAIL_OVER", function(e) GameUtility.OverDetailCast(e) end) 
	this:AddEventListener("ENTER_DETAILPAGE", function(e) this:OnEnterDetailPage(e) end) 
	this:AddEventListener("ENTER_OTHER_PAGE", function(e) this:TopUIGoOtherPage(e) end) 
	this:AddEventListener("FRESH_MAIN_TOP", function(e) this._clubMainWindow.HeaderUICom._mainTopContr:WhenEnterFresh(e) end) 
	this:AddEventListener("FRESH_MAINPAGE_PARTY", function(e) this._clubMainWindow.HeaderUICom._mainTopContr:OnMainPartyFresh(e) end) 
	this:AddEventListener("OVER_MAINPAGE_PARTY", function(e) this._clubMainWindow.HeaderUICom._mainTopContr:OnMainPartyOver(e) end) 
	this:AddEventListener("MAIN_GO_PARTYPAGE", function(e) this:GoPartyPartyPage(e) end) 
	this:AddEventListener("MAIN_GO_USER_PARTYPAGE", function(e) this:GoUserPartyPartyPage(e) end) 
	ChatMsgManager.Instance:OpenChat() 
	if not isnil(this._clubMainWindow.HeaderUICom._emailCom) then
		local emaiBt; emaiBt = this._clubMainWindow.HeaderUICom._emailCom.transform:GetComponent("UIButton");
		EventDelegate.Add__System_Collections_Generic_List_EventDelegate__EventDelegate_Callback(emaiBt.onClick, function() this:OnEmailButton() end) 
	end 
end

function _lua_ClubHouseNode:SetOffSinginTip( e)
	GameLog("------------------------------_lua_ClubHouseNode SetOffSinginTip------------------------------")
	this._clubMainWindow.SignTipObj:SetActive(false) 
end

function _lua_ClubHouseNode:OnClickHeader()
	GameLog("------------------------------_lua_ClubHouseNode OnClickHeader------------------------------")
	PlayerInfoDialogNode.Open() 
end

function _lua_ClubHouseNode:OnEmailButton()
	GameLog("------------------------------_lua_ClubHouseNode OnEmailButton------------------------------")
	this.ViewParent:Push(typeof(SubHeaderNode), typeof(EmailWindowNode)) 
end

function _lua_ClubHouseNode:RemoverRegister()
	GameLog("------------------------------_lua_ClubHouseNode RemoverRegister------------------------------")
	LabelChangeAni.StopToEnd(ClubHouseNode.MAIN_UI_LABEL_ANI_CHANGE_PHYSICAL) 
	LabelChangeAni.StopToEnd(ClubHouseNode.MAIN_UI_LABEL_ANI_CHANGE_GOLD) 
	LabelChangeAni.StopToEnd(ClubHouseNode.MAIN_UI_LABEL_ANI_CHANGE_DIAMOND) 
	this:RemoveEventListener("GET_DETAIL_OVER") 
	this:RemoveEventListener("UI_UPDATE_PLAYER_INFO") 
	this:RemoveEventListener(CS.EightGame.Logic.RechargeViewNode.Open_Recharge_View) 
	this:RemoveEventListener("UI_XMB_INVITE_GRID") 
	this:RemoveEventListener("UI_HEARTBEAT_MESSAGE") 
	this:SetBaseSceneActive(false) 
	this._clubMainWindow.HeaderUICom:OnExit() 
	ChatMsgManager.Instance:CloseChat() 
end

function _lua_ClubHouseNode:SetBaseSceneActive( b)
	GameLog("------------------------------_lua_ClubHouseNode SetBaseSceneActive------------------------------")
	if not isnil(this._viewController) then
		this:DispatchEvent(CS.Eight.Framework.EIBoolEvent("ChangeTtileActive",b) ) 
		this._viewController.gameObject:SetActive(b) 
	end 
end

function _lua_ClubHouseNode:OpenRechargeView( e)
	GameLog("------------------------------_lua_ClubHouseNode OpenRechargeView------------------------------")
	if FunctionOpenUtility.JudgeSingleFunctionById(se_functiontype.SE_FUNCTIONTYPE_PAY_MODULE , true) then
		this.ViewParent:Push(typeof(SubHeaderNode), typeof(RechargeViewNode)) 
	end 
end

function _lua_ClubHouseNode:OnPlayerDataUpdate( response)
	GameLog("------------------------------_lua_ClubHouseNode OnPlayerDataUpdate------------------------------")
	this:UpdateUI(false) 
end

function _lua_ClubHouseNode:OnCallGetFoodMsg( e)
	GameLog("------------------------------_lua_ClubHouseNode OnCallGetFoodMsg------------------------------")
	local action; action = CS.EightGame.Data.Server.ServerService.SignphysicalMethod();
	CS.Eight.Framework.EIFrameWork.GetComponent(CS.EightGame.Component.NetworkClient):NetworkRequest(action, (function(returnCode, response)
		local res; res = response;
		if (returnCode < 1000) then
			local temp; temp = CS.EightGame.Logic.TipStruct(CS.System.String.Format("获得 #ICON_PHYSICAL {0}  ", res.amount),0.20) ;
			this:DispatchEvent(CS.Eight.Framework.EIEvent("UI_FLOATING_TIPS",nil,temp,0.00) ) 
		else
			local msg; msg = CS.EightGame.Component.NetCode.GetDesc(returnCode);
			local param; param = CS.EightGame.Logic.TipStruct(msg,0.20) ;
			CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_FLOATING_TIPS",nil,param,0.00) ) 
		end 
	end), true, false) 
end

function _lua_ClubHouseNode:OnUpdateXMBInvitePanel( e)
	GameLog("------------------------------_lua_ClubHouseNode OnUpdateXMBInvitePanel------------------------------")
	local be; be = e;
	if not isnil(this._clubMainWindow.HeaderUICom) then
		this._clubMainWindow.HeaderUICom:SetInviteGridActive(be.boolParam) 
	end 
end

function _lua_ClubHouseNode:get_hasNavigationOnEnter()
	GameLog("------------------------------_lua_ClubHouseNode get_hasNavigationOnEnter------------------------------")
	return true 
end

function _lua_ClubHouseNode:RemovePartyFunction()
	GameLog("------------------------------_lua_ClubHouseNode RemovePartyFunction------------------------------")
	this:RemoveEventListener("ENTER_DETAILPAGE") 
	this:RemoveEventListener("ENTER_OTHER_PAGE") 
	this:RemoveEventListener("FRESH_MAIN_TOP") 
	this:RemoveEventListener("FRESH_MAINPAGE_PARTY") 
	this:RemoveEventListener("OVER_MAINPAGE_PARTY") 
	this:RemoveEventListener("MAIN_GO_PARTYPAGE") 
	this:RemoveEventListener("MAIN_GO_USER_PARTYPAGE") 
end

function _lua_ClubHouseNode:hotfix()
	xlua.hotfix(ClubHouseNode, {
       ['CreateView'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return util.cs_generator(function()
               _lua_ClubHouseNode:CreateView()
           end)
       end,
       ['InitFunciton'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:InitFunciton()
       end,
       ['SetClubCamera'] = function(this, e)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:SetClubCamera( e)
       end,
       ['GoPartyPartyPage'] = function(this, e)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:GoPartyPartyPage( e)
       end,
       ['GoUserPartyPartyPage'] = function(this, e)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:GoUserPartyPartyPage( e)
       end,
       ['OnEnterDetailPage'] = function(this, e)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:OnEnterDetailPage( e)
       end,
       ['InitNpcsUI'] = function(this, e)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:InitNpcsUI( e)
       end,
       ['GoEnterOtherPage'] = function(this, e)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:GoEnterOtherPage( e)
       end,
       ['STNpcShowCall'] = function(this, type, _call)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:STNpcShowCall( type, _call)
       end,
       ['ShowAnimatorCall'] = function(this, type, myAnimator, _call)
           _lua_ClubHouseNode:Ref(this)
           return util.cs_generator(function()
               _lua_ClubHouseNode:ShowAnimatorCall( type, myAnimator, _call)
           end)
       end,
       ['OnCheckData'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:OnCheckData()
       end,
       ['CallbackClickRecharge'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:CallbackClickRecharge()
       end,
       ['OnExploreBtn'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:OnExploreBtn()
       end,
       ['UpdateTeamTipsSprite'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:UpdateTeamTipsSprite()
       end,
       ['UpdatePartnerTipsSprite'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:UpdatePartnerTipsSprite()
       end,
       ['UpdateLotteryTipsSprite'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:UpdateLotteryTipsSprite()
       end,
       ['OnEnterRegister'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:OnEnterRegister()
       end,
       ['SetOffSinginTip'] = function(this, e)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:SetOffSinginTip( e)
       end,
       ['OnClickHeader'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:OnClickHeader()
       end,
       ['OnEmailButton'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:OnEmailButton()
       end,
       ['RemoverRegister'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:RemoverRegister()
       end,
       ['SetBaseSceneActive'] = function(this, b)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:SetBaseSceneActive( b)
       end,
       ['OpenRechargeView'] = function(this, e)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:OpenRechargeView( e)
       end,
       ['OnPlayerDataUpdate'] = function(this, response)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:OnPlayerDataUpdate( response)
       end,
       ['OnCallGetFoodMsg'] = function(this, e)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:OnCallGetFoodMsg( e)
       end,
       ['OnUpdateXMBInvitePanel'] = function(this, e)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:OnUpdateXMBInvitePanel( e)
       end,
       ['RemovePartyFunction'] = function(this)
           _lua_ClubHouseNode:Ref(this)
           return _lua_ClubHouseNode:RemovePartyFunction()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubHouseNode)