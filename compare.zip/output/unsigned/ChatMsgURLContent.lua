
local this = nil
_lua_ChatMsgURLContent = BaseCom:New('_lua_ChatMsgURLContent')
function _lua_ChatMsgURLContent:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatMsgURLContent:ctor__System_String__System_Int32__System_Int64__System_String__System_String__System_String( itemtype, itemstiticid, itemGid, characterStr, itemcontent, extraData)
	GameLog("------------------------------_lua_ChatMsgURLContent ctor__System_String__System_Int32__System_Int64__System_String__System_String__System_String------------------------------")
	local __compiler_switch_957 = itemtype;
	if __compiler_switch_957 == "item" then
		this.itemtype = 1 
	elseif __compiler_switch_957 == "equipment" then
		this.itemtype = 2 
	elseif __compiler_switch_957 == "role" then
		this.itemtype = 3 
	elseif __compiler_switch_957 == "emoji" then
		this.itemtype = 4 
	else
		this.itemtype = 0 
	end 
	this.itemstiticid = itemstiticid 
	this.itemGid = itemGid 
	this.extraData = extraData 
	this.characterStr = characterStr 
	this.itemcontent = itemcontent 
	return this 
end

function _lua_ChatMsgURLContent:hotfix()
	xlua.hotfix(ChatMsgURLContent, {
   })
end

table.insert(g_tbHotfix, _lua_ChatMsgURLContent)