
local this = nil
_lua_ClubBossReadyWindowNode = BaseCom:New('_lua_ClubBossReadyWindowNode')
function _lua_ClubBossReadyWindowNode:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubBossReadyWindowNode:CreateView()
	GameLog("------------------------------_lua_ClubBossReadyWindowNode CreateView------------------------------")
	local c; c = XLuaScriptUtils.GameResources():LoadAsyn(("GameAssets/Prefabs/UI/" .. this._prefabPath), "prefab", false);
	coroutine.yield(c.coroutine) 
	local tempPrefab; tempPrefab = c.res;
	if isnil(tempPrefab) then
		CS.Eight.Framework.EIDebuger.LogError("load ui_teamlistui error ") 
		return nil 
	end 
	local go; go = GameUtility.InstantiateGameObject(tempPrefab, nil, "ClubBossReadyPageUI");
	this._pagecom = go:GetComponent("ClubBossReadyPageUI") 
	this:BindComponent(this._pagecom)
	this._pagecom:Init() 
	this._isReady = true 
end

function _lua_ClubBossReadyWindowNode:hotfix()
	xlua.hotfix(ClubBossReadyWindowNode, {
       ['CreateView'] = function(this)
           _lua_ClubBossReadyWindowNode:Ref(this)
           return util.cs_generator(function()
               _lua_ClubBossReadyWindowNode:CreateView()
           end)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubBossReadyWindowNode)