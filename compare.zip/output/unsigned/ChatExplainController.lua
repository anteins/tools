
local this = nil
_lua_ChatExplainController = BaseCom:New('_lua_ChatExplainController')
function _lua_ChatExplainController:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatExplainController:SetData__System_Object( obj)
	GameLog("------------------------------_lua_ChatExplainController SetData__System_Object------------------------------")
	if typeis(obj, CS.EightGame.Data.Server.ItemSerData, false) then
		this:SetData__EightGame_Data_Server_ItemSerData(obj) 
	elseif typeis(obj, CS.EightGame.Data.Server.EquipmentSerData, false) then
		this:SetData__EightGame_Data_Server_EquipmentSerData(obj) 
	elseif typeis(obj, CS.EightGame.Data.Server.FighterSerData, false) then
		this:SetData__System_Object(obj) 
	end 
end

function _lua_ChatExplainController:InitEuipment( equip, rankuplv)
	GameLog("------------------------------_lua_ChatExplainController InitEuipment------------------------------")
	if isnil(this._equipmentCom) then
		local c; c = XLuaScriptUtils.GameResources():LoadAsyn(("GameAssets/Prefabs/UI/" .. this._equipmentItemPath), "prefab", false);
		coroutine.yield(c.coroutine) 
		local prefab; prefab = c.res;
		local go; go = GameUtility.InstantiateGameObject(prefab, this._equipmentAchor.gameObject, "equipmentitem");
		this._equipmentCom = go:GetComponent("EquipmentModelCom") 
	end 
	if not isnil(this._equipmentCom) then
		this._equipmentCom.gameObject:SetActive(true) 
	end 
	if not isnil(this._itemmodelCom) then
		this._itemmodelCom.gameObject:SetActive(false) 
	end 
	this._equipmentCom:ResetIcon() 
	this._equipmentCom:SetValue(equip.id, equip.rank, equip.icon, equip.uselv, rankuplv, 99999) 
end

function _lua_ChatExplainController:InitItem( item)
	GameLog("------------------------------_lua_ChatExplainController InitItem------------------------------")
	if isnil(this._itemmodelCom) then
		local c; c = XLuaScriptUtils.GameResources():LoadAsyn(("GameAssets/Prefabs/UI/" .. this._itemPath), "prefab", false);
		coroutine.yield(c.coroutine) 
		local prefab; prefab = c.res;
		local go; go = GameUtility.InstantiateGameObject(prefab, this._equipmentAchor.gameObject, "item");
		this._itemmodelCom = go:GetComponent("ItemModelCom") 
	end 
	if not isnil(this._equipmentCom) then
		this._equipmentCom.gameObject:SetActive(false) 
	end 
	if not isnil(this._itemmodelCom) then
		this._itemmodelCom.gameObject:SetActive(true) 
	end 
	this._itemmodelCom:SetValue(item.type, 0, item.id, 1, false, false, false, false) 
end

function _lua_ChatExplainController:SetNameLbl( namestr)
	GameLog("------------------------------_lua_ChatExplainController SetNameLbl------------------------------")
	if (this._equipmentNameLbl.text == nil) then
		return  
	end 
	this._equipmentNameLbl.text = namestr 
end

function _lua_ChatExplainController:SetUseLvLbl( uselv)
	GameLog("------------------------------_lua_ChatExplainController SetUseLvLbl------------------------------")
	if isnil(this._equipmentUseLvLbl) then
		return  
	end 
	this._equipmentUseLvLbl.text = uselv 
end

function _lua_ChatExplainController:SetProperty__EightGame_Data_Server_EquipmentSerData( serdata)
	GameLog("------------------------------_lua_ChatExplainController SetProperty__EightGame_Data_Server_EquipmentSerData------------------------------")
	local ex; ex = CS.EightGame.Data.Server.EquipmentSerDataEx.CreateFakeSerData(serdata.staticid, serdata.id, serdata.randattr, serdata.rankuplv, serdata.breakskill, serdata.wearfighter);
	local datas; datas = XLuaScriptUtils.new_List_1(typeof(ChatExplainController.PropertyData));
	local curAttr; curAttr = CS.EightGame.Data.Server.EquipmentSerDataEx.CombineAttrs(ex.baseAttrs, ex.rankupAttrs);
	local data; data = ChatExplainController.PropertyData() ;
	data = wrapvaluetype(data) 
	data.des = "基础:" 
	data.propertydata = this:GetPropertyStr(curAttr, "ffffff") 
	datas:Add(data) 
	local data_1; data_1 = ChatExplainController.PropertyData() ;
	data_1 = wrapvaluetype(data_1) 
	data_1.des = "附加:" 
	local str_1; str_1 = "";
	foreach(ex.randAttrs, function (item)
		local keyvalue = item.current
		str_1 = str_1 + this:GetPropertyStr(keyvalue.Value, "77F3FB") 
	end)
	data_1.propertydata = str_1 
	datas:Add(data_1) 
	this:InitProperty(datas) 
	this:SetCombatwworthyActive(true) 
	this:SetCombatwworthyLbl(ex.battleForce) 
end

function _lua_ChatExplainController:GetPropertyStr( curAttr, colorstr)
	GameLog("------------------------------_lua_ChatExplainController GetPropertyStr------------------------------")
	local str; str = "";
	if (curAttr.hp > 0) then
		str = str + CS.System.String.Format("{0}[{1}]{2} {3}", CS.System.String.IsNullOrEmpty(str) and "" or "\n", colorstr, RankupUtil.GetShortNameRoleAttr(1), curAttr.hp) 
	end 
	if (curAttr.atk > 0) then
		str = str + CS.System.String.Format("{0}[{1}]{2} {3}", CS.System.String.IsNullOrEmpty(str) and "" or "\n", colorstr, RankupUtil.GetShortNameRoleAttr(2), curAttr.atk) 
	end 
	if (curAttr.crt > 0) then
		str = str + CS.System.String.Format("{0}[{1}]{2} {3}", CS.System.String.IsNullOrEmpty(str) and "" or "\n", colorstr, RankupUtil.GetShortNameRoleAttr(5), curAttr.crt) 
	end 
	if (curAttr.defense > 0) then
		str = str + CS.System.String.Format("{0}[{1}]{2} {3}", CS.System.String.IsNullOrEmpty(str) and "" or "\n", colorstr, RankupUtil.GetShortNameRoleAttr(4), curAttr.defense) 
	end 
	if (curAttr.reply > 0) then
		str = str + CS.System.String.Format("{0}[{1}]{2} {3}", CS.System.String.IsNullOrEmpty(str) and "" or "\n", colorstr, RankupUtil.GetShortNameRoleAttr(3), curAttr.reply) 
	end 
	return str 
end

function _lua_ChatExplainController:SetProperty__EightGame_Data_Server_sd_equipment_equip( equip)
	GameLog("------------------------------_lua_ChatExplainController SetProperty__EightGame_Data_Server_sd_equipment_equip------------------------------")
	local datas; datas = XLuaScriptUtils.new_List_1(typeof(ChatExplainController.PropertyData));
	local kevalues; kevalues = equip.baseattr;
	local str_1; str_1 = "";
	local index; index = 0;
	while (index < obj_len(kevalues)) do
		if (CS.System.Convert.ToInt32(index) == 0) then
			str_1 = CS.System.String.Format("{0} {1}", RankupUtil.GetShortNameRoleAttr(DictGetValue(kevalues, index).key), DictGetValue(kevalues, index).value) 
		else
			str_1 = str_1 + CS.System.String.Format("\n{0} {1}", RankupUtil.GetShortNameRoleAttr(DictGetValue(kevalues, index).key), DictGetValue(kevalues, index).value) 
		end 
	index = index+1  
	end 
	local data; data = ChatExplainController.PropertyData() ;
	data = wrapvaluetype(data) 
	data.des = CS.System.String.Format("基础:") 
	data.propertydata = str_1 
	local data_1; data_1 = ChatExplainController.PropertyData() ;
	data_1 = wrapvaluetype(data_1) 
	data_1.des = CS.System.String.Format("附加:") 
	data_1.propertydata = "[56e5e7]????" 
	local data_2; data_2 = ChatExplainController.PropertyData() ;
	data_2 = wrapvaluetype(data_2) 
	data_2.des = CS.System.String.Format("描述:") 
	data_2.propertydata = CS.System.String.Format("{0}", equip.desc) 
	datas:Add(data) 
	datas:Add(data_1) 
	datas:Add(data_2) 
	this:InitProperty(datas) 
end

function _lua_ChatExplainController:SetProperty__EightGame_Data_Server_sd_item_item( item)
	GameLog("------------------------------_lua_ChatExplainController SetProperty__EightGame_Data_Server_sd_item_item------------------------------")
	local data; data = ChatExplainController.PropertyData() ;
	data = wrapvaluetype(data) 
	data.des = CS.System.String.Format("描述:") 
	data.propertydata = CS.System.String.Format("{0}", item.desc) 
	local datas; datas = XLuaScriptUtils.new_List_1(typeof(ChatExplainController.PropertyData));
	datas:Add(data) 
	this:InitProperty(datas) 
	this:SetCombatwworthyActive(false) 
end

function _lua_ChatExplainController:InitProperty( datas)
	GameLog("------------------------------_lua_ChatExplainController InitProperty------------------------------")
	if (this._cachPropertyItems.Count < obj_len(this._cachPropertyItems)) then
		local index; index = 0;
		while (index < obj_len(datas)) do
		repeat
			local go; go = nil;
			if (index < obj_len(this._cachPropertyItems)) then
				DictGetValue(this._cachPropertyItems, index).gameObject:SetActive(true) 
				go = DictGetValue(this._cachPropertyItems, index) 
			else
				go = GameUtility.InstantiateGameObject(this._propertyPrefab, this._powerTable.gameObject, "PropertyItem") 
				this._cachPropertyItems:Add(go) 
			end 
			if isnil(go) then
				break 
			end 
			local lbl_1; lbl_1 = go:GetComponent("UILabel");
			local lbl_2; lbl_2 = go.transform:GetChild(0):GetComponent("UILabel");
			if (isnil(lbl_1) or isnil(lbl_2)) then
				return  
			end 
			lbl_1.text = DictGetValue(datas, index).des 
			lbl_2.text = DictGetValue(datas, index).propertydata 
		until true 
		index = index+1  
		end 
	else
		local index; index = 0;
		while (index < obj_len(this._cachPropertyItems)) do
		repeat
			local go; go = nil;
			if (index < obj_len(datas)) then
				DictGetValue(this._cachPropertyItems, index).gameObject:SetActive(true) 
				go = DictGetValue(this._cachPropertyItems, index) 
			else
				DictGetValue(this._cachPropertyItems, index).gameObject:SetActive(false) 
			end 
			if isnil(go) then
				break 
			end 
			local lbl_1; lbl_1 = go:GetComponent("UILabel");
			local lbl_2; lbl_2 = go.transform:GetChild(0):GetComponent("UILabel");
			if (isnil(lbl_1) or isnil(lbl_2)) then
				return  
			end 
			lbl_1.text = DictGetValue(datas, index).des 
			lbl_2.text = DictGetValue(datas, index).propertydata 
		until true 
		index = index+1  
		end 
	end 
	this._powerTable.repositionNow = true 
end

function _lua_ChatExplainController:OnClickClose()
	GameLog("------------------------------_lua_ChatExplainController OnClickClose------------------------------")
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent(ChatExplainController.CLICK_CHATEXPLAIN_ACTION,nil,nil,0.00) ) 
	if not isnil(this) then
		this.gameObject:SetActive(false) 
	end 
end

function _lua_ChatExplainController:SetBgSpriteHeight()
	GameLog("------------------------------_lua_ChatExplainController SetBgSpriteHeight------------------------------")
	coroutine.yield(nil) 
	if not isnil(this._powerTable) then
		local bounds; bounds = NGUIMath.CalculateRelativeWidgetBounds__UnityEngine_Transform(this._powerTable.transform);
		if isnil(this._bgSprite) then
			return nil 
		end 
		this._bgSprite:SetDimensions(this._bgSprite.width, CS.UnityEngine.Mathf.CeilToInt(bounds.size.y)+180 ) 
	end 
end

function _lua_ChatExplainController:SetCombatwworthyActive( b)
	GameLog("------------------------------_lua_ChatExplainController SetCombatwworthyActive------------------------------")
	if isnil(this._combatworthyLbl) then
		return  
	end 
	this._combatworthyLbl.gameObject:SetActive(b) 
end

function _lua_ChatExplainController:SetCombatwworthyLbl( power)
	GameLog("------------------------------_lua_ChatExplainController SetCombatwworthyLbl------------------------------")
	if isnil(this._combatworthyLbl) then
		return  
	end 
	this._combatworthyLbl.text = CS.System.String.Format("{0}", power) 
end

function _lua_ChatExplainController:hotfix()
	xlua.hotfix(ChatExplainController, {
       ['InitEuipment'] = function(this, equip, rankuplv)
           _lua_ChatExplainController:Ref(this)
           return util.cs_generator(function()
               _lua_ChatExplainController:InitEuipment( equip, rankuplv)
           end)
       end,
       ['InitItem'] = function(this, item)
           _lua_ChatExplainController:Ref(this)
           return util.cs_generator(function()
               _lua_ChatExplainController:InitItem( item)
           end)
       end,
       ['SetNameLbl'] = function(this, namestr)
           _lua_ChatExplainController:Ref(this)
           return _lua_ChatExplainController:SetNameLbl( namestr)
       end,
       ['SetUseLvLbl'] = function(this, uselv)
           _lua_ChatExplainController:Ref(this)
           return _lua_ChatExplainController:SetUseLvLbl( uselv)
       end,
       ['GetPropertyStr'] = function(this, curAttr, colorstr)
           _lua_ChatExplainController:Ref(this)
           return _lua_ChatExplainController:GetPropertyStr( curAttr, colorstr)
       end,
       ['InitProperty'] = function(this, datas)
           _lua_ChatExplainController:Ref(this)
           return _lua_ChatExplainController:InitProperty( datas)
       end,
       ['OnClickClose'] = function(this)
           _lua_ChatExplainController:Ref(this)
           return _lua_ChatExplainController:OnClickClose()
       end,
       ['SetBgSpriteHeight'] = function(this)
           _lua_ChatExplainController:Ref(this)
           return util.cs_generator(function()
               _lua_ChatExplainController:SetBgSpriteHeight()
           end)
       end,
       ['SetCombatwworthyActive'] = function(this, b)
           _lua_ChatExplainController:Ref(this)
           return _lua_ChatExplainController:SetCombatwworthyActive( b)
       end,
       ['SetCombatwworthyLbl'] = function(this, power)
           _lua_ChatExplainController:Ref(this)
           return _lua_ChatExplainController:SetCombatwworthyLbl( power)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatExplainController)