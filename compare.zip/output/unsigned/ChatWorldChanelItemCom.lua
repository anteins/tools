
local this = nil
_lua_ChatWorldChanelItemCom = BaseCom:New('_lua_ChatWorldChanelItemCom')
function _lua_ChatWorldChanelItemCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatWorldChanelItemCom:SetData( chatsysmsg, callbackSelect, iscurchannel)
	GameLog("------------------------------_lua_ChatWorldChanelItemCom SetData------------------------------")
	this._chatsysmsg = chatsysmsg 
	this._callbackSelect = callbackSelect 
	this:SetLbl(chatsysmsg.chat_statue, tostring(chatsysmsg.word_room_id), iscurchannel) 
	this:SetPointColor(chatsysmsg.chat_statue) 
end

function _lua_ChatWorldChanelItemCom:SetLbl( state, str, b)
	GameLog("------------------------------_lua_ChatWorldChanelItemCom SetLbl------------------------------")
	if isnil(this._lbl) then
		return  
	end 
	local cur; cur = b and "(当前)" or "";
	this._lbl.text = CS.System.String.Format("CH.{0}{1}", str, cur) 
	local c; c = CS.UnityEngine.Color();
	if (CS.System.Convert.ToInt32(state) == 100) then
		c = CS.UnityEngine.Color.red 
	elseif ((0 <= state) and (state <= 60)) then
		c = CS.UnityEngine.Color.white 
	elseif ((state > 60) and (state < 100)) then
		c = CS.UnityEngine.Color.yellow 
	end 
	this._lbl.color = c 
end

function _lua_ChatWorldChanelItemCom:SetPointColor( state)
	GameLog("------------------------------_lua_ChatWorldChanelItemCom SetPointColor------------------------------")
	if isnil(this._pointSprite) then
		return  
	end 
	local c; c = CS.UnityEngine.Color();
	if (CS.System.Convert.ToInt32(state) == 100) then
		c = CS.UnityEngine.Color.red 
	elseif ((0 <= state) and (state <= 60)) then
		c = CS.UnityEngine.Color.white 
	elseif ((state > 60) and (state < 100)) then
		c = CS.UnityEngine.Color.yellow 
	end 
	this._pointSprite.color = c 
end

function _lua_ChatWorldChanelItemCom:OnClick()
	GameLog("------------------------------_lua_ChatWorldChanelItemCom OnClick------------------------------")
	if this ~= "_callbackSelect" then
		this._callbackSelect(this._chatsysmsg) 
	end 
end

function _lua_ChatWorldChanelItemCom:hotfix()
	xlua.hotfix(ChatWorldChanelItemCom, {
       ['SetData'] = function(this, chatsysmsg, callbackSelect, iscurchannel)
           _lua_ChatWorldChanelItemCom:Ref(this)
           return _lua_ChatWorldChanelItemCom:SetData( chatsysmsg, callbackSelect, iscurchannel)
       end,
       ['SetLbl'] = function(this, state, str, b)
           _lua_ChatWorldChanelItemCom:Ref(this)
           return _lua_ChatWorldChanelItemCom:SetLbl( state, str, b)
       end,
       ['SetPointColor'] = function(this, state)
           _lua_ChatWorldChanelItemCom:Ref(this)
           return _lua_ChatWorldChanelItemCom:SetPointColor( state)
       end,
       ['OnClick'] = function(this)
           _lua_ChatWorldChanelItemCom:Ref(this)
           return _lua_ChatWorldChanelItemCom:OnClick()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatWorldChanelItemCom)