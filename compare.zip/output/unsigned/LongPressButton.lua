
local this = nil
_lua_LongPressButton = BaseCom:New('_lua_LongPressButton')
function _lua_LongPressButton:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LongPressButton:OnPress( isPress)
	GameLog("------------------------------_lua_LongPressButton OnPress------------------------------")
	if (this._pressCoroutine ~= nil) then
		this:StopCoroutine(this._pressCoroutine) 
	end 
	if isPress then
		this._pressCoroutine = this:TriggerLongPressMode() 
		this:StartCoroutine(this._pressCoroutine) 
	else
		if (this._isEnteredPressMode and this ~= "onExitLongPress") then
			this.onExitLongPress() 
		end 
		if ((not this._isEnteredPressMode) and this ~= "onClick") then
			this.onClick() 
		end 
	end 
end

function _lua_LongPressButton:TriggerLongPressMode()
	GameLog("------------------------------_lua_LongPressButton TriggerLongPressMode------------------------------")
	this._isEnteredPressMode = false 
	coroutine.yield(CS.UnityEngine.WaitForSeconds(this.pressEnterTime)) 
	this._isEnteredPressMode = true 
	if this ~= "onEnterLongPress" then
		this.onEnterLongPress() 
	end 
	while true do
		coroutine.yield(CS.UnityEngine.WaitForSeconds(this.triggerGapTime)) 
		if this ~= "onTurboTrigger" then
			this.onTurboTrigger() 
		end 
	end 
end

function _lua_LongPressButton:hotfix()
	xlua.hotfix(LongPressButton, {
       ['OnPress'] = function(this, isPress)
           _lua_LongPressButton:Ref(this)
           return _lua_LongPressButton:OnPress( isPress)
       end,
       ['TriggerLongPressMode'] = function(this)
           _lua_LongPressButton:Ref(this)
           return util.cs_generator(function()
               _lua_LongPressButton:TriggerLongPressMode()
           end)
       end,
   })
end

table.insert(g_tbHotfix, _lua_LongPressButton)