
local this = nil
_lua_ChatInput = BaseCom:New('_lua_ChatInput')
function _lua_ChatInput:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatInput:OnSubmit()
	GameLog("------------------------------_lua_ChatInput OnSubmit------------------------------")
	if not isnil(this.textList) then
		local text; text = NGUIText.StripSymbols(this.mInput.value);
		if (not CS.System.String.IsNullOrEmpty(text)) then
			this.textList:Add__System_String(text) 
			this.mInput.value = "" 
			this.mInput.isSelected = false 
		end 
	end 
end

function _lua_ChatInput:hotfix()
	xlua.hotfix(ChatInput, {
       ['OnSubmit'] = function(this)
           _lua_ChatInput:Ref(this)
           return _lua_ChatInput:OnSubmit()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatInput)