
local this = nil
_lua_LoginLogoCom = BaseCom:New('_lua_LoginLogoCom')
function _lua_LoginLogoCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LoginLogoCom:SetAnimaiton01FinishCallBack( callback01)
	GameLog("------------------------------_lua_LoginLogoCom SetAnimaiton01FinishCallBack------------------------------")
	this._callback01 = callback01 
end

function _lua_LoginLogoCom:Animation01Finish()
	GameLog("------------------------------_lua_LoginLogoCom Animation01Finish------------------------------")
	if this ~= "_callback01" then
		this._callback01() 
	end 
end

function _lua_LoginLogoCom:hotfix()
	xlua.hotfix(LoginLogoCom, {
       ['SetAnimaiton01FinishCallBack'] = function(this, callback01)
           _lua_LoginLogoCom:Ref(this)
           return _lua_LoginLogoCom:SetAnimaiton01FinishCallBack( callback01)
       end,
       ['Animation01Finish'] = function(this)
           _lua_LoginLogoCom:Ref(this)
           return _lua_LoginLogoCom:Animation01Finish()
       end,
   })
end

table.insert(g_tbHotfix, _lua_LoginLogoCom)