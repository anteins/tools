
local this = nil
_lua_ChatItemLineControlller = BaseCom:New('_lua_ChatItemLineControlller')
function _lua_ChatItemLineControlller:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatItemLineControlller:SetData( cEnum, datalist, callbackClickItem)
	GameLog("------------------------------_lua_ChatItemLineControlller SetData------------------------------")
	this:HideAllItem() 
	this._dataList = datalist 
	this._callbackClickItem = callbackClickItem 
	if (CS.System.Convert.ToInt32(cEnum) == 0) then
		if (obj_len(this._itemModelList) == 0) then
			this:InitModels(cEnum) 
		end 
	elseif (CS.System.Convert.ToInt32(cEnum) == 2) then
		if (obj_len(this._avatorModelList) == 0) then
			this:InitModels(cEnum) 
		end 
	elseif (CS.System.Convert.ToInt32(cEnum) == 1) then
		if (obj_len(this._equipmentModelList) == 0) then
			this:InitModels(cEnum) 
		end 
	end 
	this:InitDatas(cEnum) 
end

function _lua_ChatItemLineControlller:HideAllItem()
	GameLog("------------------------------_lua_ChatItemLineControlller HideAllItem------------------------------")
	foreach(this._itemModelList, function(F) F = F.current   return F.gameObject:SetActive(false)  end) 
	foreach(this._equipmentModelList, function(F) F = F.current   return F.gameObject:SetActive(false)  end) 
	foreach(this._avatorModelList, function(F) F = F.current   return F.gameObject:SetActive(false)  end) 
end

function _lua_ChatItemLineControlller:InitModels( cEnum)
	GameLog("------------------------------_lua_ChatItemLineControlller InitModels------------------------------")
	local index; index = 0;
	while (index < ChatItemLineControlller._eachLineItemCount) do
		if (CS.System.Convert.ToInt32(cEnum) == 0) then
			local go; go = GameUtility.InstantiateGameObject(this._itemModelPrefab, this._grid.gameObject, CS.System.String.Format("{0}{1}", "item", index));
			go.gameObject:SetActive(false) 
			local com; com = go:GetComponent("ItemModelCom");
			com.onClick =  (function() this:OnClickItem() end) 
			this._itemModelList:Add(com) 
		elseif (CS.System.Convert.ToInt32(cEnum) == 2) then
			local go; go = GameUtility.InstantiateGameObject(this._avatorModelPrefab, this._grid.gameObject, CS.System.String.Format("{0}{1}", "avator", index));
			go.gameObject:SetActive(false) 
			local com; com = go:GetComponent("AvatarModelCom");
			this._avatorModelList:Add(com) 
		elseif (CS.System.Convert.ToInt32(cEnum) == 1) then
			local go; go = GameUtility.InstantiateGameObject(this._equipmentModelPrefab, this._grid.gameObject, CS.System.String.Format("{0}{1}", "equipment", index));
			go.gameObject:SetActive(false) 
			local com; com = go:GetComponent("EquipmentModelCom");
			com.onClick =  (function(eid) this:OnClickEquipment(eid) end) 
			this._equipmentModelList:Add(com) 
		end 
	index = index+1  
	end 
end

function _lua_ChatItemLineControlller:hotfix()
	xlua.hotfix(ChatItemLineControlller, {
       ['SetData'] = function(this, cEnum, datalist, callbackClickItem)
           _lua_ChatItemLineControlller:Ref(this)
           return _lua_ChatItemLineControlller:SetData( cEnum, datalist, callbackClickItem)
       end,
       ['HideAllItem'] = function(this)
           _lua_ChatItemLineControlller:Ref(this)
           return _lua_ChatItemLineControlller:HideAllItem()
       end,
       ['InitModels'] = function(this, cEnum)
           _lua_ChatItemLineControlller:Ref(this)
           return _lua_ChatItemLineControlller:InitModels( cEnum)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatItemLineControlller)