
local this = nil
_lua_ChatSubCallBackParam = BaseCom:New('_lua_ChatSubCallBackParam')
function _lua_ChatSubCallBackParam:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatSubCallBackParam:hotfix()
end

table.insert(g_tbHotfix, _lua_ChatSubCallBackParam)