
local this = nil
_lua_ChatItemCom = BaseCom:New('_lua_ChatItemCom')
function _lua_ChatItemCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatItemCom:SetSelfStyle( self)
	GameLog("------------------------------_lua_ChatItemCom SetSelfStyle------------------------------")
	if self then
		this._playerNameLbl:GetComponent("UIWidget").pivot = 5 
		this._contentLbl.transform.localPosition = CS.UnityEngine.Vector3((210.00 - this._contentLbl.printedSize.x),-21.63,0) 
		this._parnterIcon.transform.localPosition = CS.UnityEngine.Vector3(264.60,0,0) 
		this._playerNameLbl.transform.localPosition = CS.UnityEngine.Vector3(218.00,24.70,0) 
		this._emojiTexture.transform.localPosition = CS.UnityEngine.Vector3(164.00,-15.84,0) 
		this._arrowSprite.transform.localPosition = CS.UnityEngine.Vector3(220.00,-23.00,0) 
		this._arrowSprite.transform.localRotation = CS.UnityEngine.Quaternion(0,180.00,0,0) 
		this._contentBgSprite.color = CS.UnityEngine.Color(1.00,0.89,0.69) 
		this._arrowSprite.color = CS.UnityEngine.Color(1.00,0.89,0.69) 
	else
		this._arrowSprite.transform.localPosition = CS.UnityEngine.Vector3(-215.00,-23.00,0) 
		this._arrowSprite.transform.localRotation = CS.UnityEngine.Quaternion(0,0,0,0) 
		this._contentLbl.transform.localPosition = CS.UnityEngine.Vector3(-206.00,-21.63,0) 
		this._playerNameLbl:GetComponent("UIWidget").pivot = 3 
		this._parnterIcon.transform.localPosition = CS.UnityEngine.Vector3(-266.00,0,0) 
		this._playerNameLbl.transform.localPosition = CS.UnityEngine.Vector3(-158.00,24.70,0) 
		this._emojiTexture.transform.localPosition = CS.UnityEngine.Vector3(-200.00,15.84,0) 
		this._contentBgSprite.color = CS.UnityEngine.Color.white 
		this._arrowSprite.color = CS.UnityEngine.Color.white 
	end 
end

function _lua_ChatItemCom:ClickIconTextrue()
	GameLog("------------------------------_lua_ChatItemCom ClickIconTextrue------------------------------")
	if ((this._chatmsg.playerid == 0) or (this._chatmsg.playerid == -1000)) then
		return  
	end 
	if this ~= "_callbackClickFriend" then
		this._callbackClickFriend(this) 
	end 
end

function _lua_ChatItemCom:hotfix()
	xlua.hotfix(ChatItemCom, {
       ['SetSelfStyle'] = function(this, self)
           _lua_ChatItemCom:Ref(this)
           return _lua_ChatItemCom:SetSelfStyle( self)
       end,
       ['ClickIconTextrue'] = function(this)
           _lua_ChatItemCom:Ref(this)
           return _lua_ChatItemCom:ClickIconTextrue()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatItemCom)