
local this = nil
_lua_LoginCom = BaseCom:New('_lua_LoginCom')
function _lua_LoginCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LoginCom:set_IsServerNull( value)
	GameLog("------------------------------_lua_LoginCom set_IsServerNull------------------------------")
	this._isServerNull = value 
end

function _lua_LoginCom:Init()
	GameLog("------------------------------_lua_LoginCom Init------------------------------")
	if CS.UnityEngine.Application.isEditor then
		LoginCom.IS_ENABLE_SDK = false 
	end 
	this:OnSDKInitSlot() 
	this:LogoFinsh() 
end

function _lua_LoginCom:InitMessage()
	GameLog("------------------------------_lua_LoginCom InitMessage------------------------------")
	this.entity:AddEventListener("LOGIN_SDK_ACCOUNT_SUCCESS", function(e) this:OnSDKLoginSuccessSlot(e) end) 
	this.entity:AddEventListener("LOGIN_SDK_ACCOUNT_FAILED", function(e) this:OnSDKLoginFailedSlot(e) end) 
	this.entity:AddEventListener("LOGOUT_SDK_ACCOUNT", function(e) this:OnSDKLogoutSlot(e) end) 
	this.entity:AddEventListener("LOGIN_ACCOUNT", function(e) this:LoginAccount(e) end) 
	this.entity:AddEventListener("LOGIN_REGISTER", function(e) this:RegisterAccount(e) end) 
	this.entity:AddEventListener("LOGIN_CHOICE_SERVER", function(e) this:ChoiceServer(e) end) 
end

function _lua_LoginCom:LogoFinsh()
	GameLog("------------------------------_lua_LoginCom LogoFinsh------------------------------")
	this:InitMessage() 
	this.Account.SDKAccountObj:SetActive(false) 
	this.Account.AccountObj:SetActive(false) 
	this.Account.SDKAccountObj_ysdk:SetActive(false) 
	this.Account.CurryAccout.transform.parent.gameObject:SetActive((not LoginCom.IS_ENABLE_SDK)) 
	this.Server.ServerObj:SetActive(false) 
	this.Other:Init() 
	this.LogoObj.gameObject:SetActive(false) 
	this.Anim:Init(this.entity) 
	this.Anim:SetFinishCallback(function() this:OnLeaveLogin() end) 
	this._sceneState = 1 
	this._canStart = false 
	this.Account:SetFieldActive(false) 
	this:StartCoroutine(this:LoadLogonEffect("eff_logo_002")) 
	this:SetVersion() 
end

function _lua_LoginCom:LoadLogonEffect( path)
	GameLog("------------------------------_lua_LoginCom LoadLogonEffect------------------------------")
	local coroutine; coroutine = XLuaScriptUtils.GameResources():LoadAsyn(("BaseAssets/Prefabs/Effects/UI/" .. path), "prefab", false);
	if coroutine.coroutine then
coroutine.yield(coroutine.coroutine)
end
	local prefab; prefab = coroutine.res;
	this._canStart = true 
	if isnil(prefab) then
		return nil 
	end 
	local go; go = GameUtility.InstantiateGameObject(prefab, this._logoParent.gameObject, "logo");
	this._logoEffect = go:GetComponent(typeof(CS.UnityEngine.Animator)) 
	go:AddComponent(typeof(LoginLogoCom)):SetAnimaiton01FinishCallBack((function()
		this.Account:GetAccountObj():SetActive(true) 
		if ((not CS.UnityEngine.Application.isEditor) and (not this.Other.IsDelayOpen)) then
			this.Other:OpenNoticePage() 
		end 
		this.Account:SetFieldActive(true) 
		if (not this._isServerNull) then
			local tweenAlpha; tweenAlpha = UITweener.Begin(TweenAlpha, this.Account.GameObjectFieldContainer, 0.50);
			tweenAlpha.from = 0 
			tweenAlpha.to = 1.00 
			tweenAlpha:PlayForward() 
		end 
	end)) 
end

function _lua_LoginCom:ResetAnim()
	GameLog("------------------------------_lua_LoginCom ResetAnim------------------------------")
	this.Anim:PlayStart() 
end

function _lua_LoginCom:Next()
	GameLog("------------------------------_lua_LoginCom Next------------------------------")
	this._sceneState = this._sceneState+1  
	local __compiler_switch_164 = this._sceneState;
	if __compiler_switch_164 == 1 then
		this:OnStartLogin() 
	elseif __compiler_switch_164 == 2 then
		this:OnEnterLogin() 
	elseif __compiler_switch_164 == 3 then
		this:OnOpenLogin() 
	elseif __compiler_switch_164 == 4 then
		this:OnLeaveLogin() 
	else
	end 
end

function _lua_LoginCom:Previous()
	GameLog("------------------------------_lua_LoginCom Previous------------------------------")
	this._sceneState = this._sceneState-1  
end

function _lua_LoginCom:OnSDKInitSlot()
	GameLog("------------------------------_lua_LoginCom OnSDKInitSlot------------------------------")
	if LoginCom.IS_ENABLE_SDK then
	end 
end

function _lua_LoginCom:OnSDKLoginBtnClickSlot()
	GameLog("------------------------------_lua_LoginCom OnSDKLoginBtnClickSlot------------------------------")
	this:ExecuteLogin("common login") 
	GameLog("OnSDKLoginBtnClickSlot") 
end

function _lua_LoginCom:OnSDKLoginQQBtnClickSlot()
	GameLog("------------------------------_lua_LoginCom OnSDKLoginQQBtnClickSlot------------------------------")
	this:ExecuteLogin("login_qq") 
end

function _lua_LoginCom:OnSDKLoginWXBtnClickSlot()
	GameLog("------------------------------_lua_LoginCom OnSDKLoginWXBtnClickSlot------------------------------")
	this:ExecuteLogin("login_wx") 
end

function _lua_LoginCom:ExecuteLogin( loginCustomParam)
	GameLog("------------------------------_lua_LoginCom ExecuteLogin------------------------------")
	if LoginCom.IS_ENABLE_SDK then
	end 
end

function _lua_LoginCom:OnSDKLogoutBtnClickSlot()
	GameLog("------------------------------_lua_LoginCom OnSDKLogoutBtnClickSlot------------------------------")
	if LoginCom.IS_ENABLE_SDK then
	else
		this.Account:LoginOut() 
		CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIStringEvent("LOGOUT_SDK_ACCOUNT","logout of none SDK") ) 
	end 
end

function _lua_LoginCom:OnSDKLoginSuccessSlot( e)
	GameLog("------------------------------_lua_LoginCom OnSDKLoginSuccessSlot------------------------------")
	local eParam; eParam = e.extraInfo;
	this.loginUserInfo = CS.EightGame.Logic.LoginUserParam(eParam.channelLabel,eParam.channelCode,eParam.channelUid,eParam.token)  
	if LoginCom.IS_ENABLE_SDK then
		this.Account:SetLatestAccount(eParam.channelUid) 
	end 
	CS.Eight.Framework.EIDebuger.GameLog("OnSDKLoginFinishedSlot") 
	GameUtility.TweenAlphaClose(this.Account:GetAccountObj(), this.Server.ServerObj) 
end

function _lua_LoginCom:OnSDKLoginFailedSlot( e)
	GameLog("------------------------------_lua_LoginCom OnSDKLoginFailedSlot------------------------------")
	local customParams; customParams = ( e ).stringParam;
end

function _lua_LoginCom:OnSDKLogoutSlot( e)
	GameLog("------------------------------_lua_LoginCom OnSDKLogoutSlot------------------------------")
	CS.Eight.Framework.EIDebuger.GameLog("OnSDKLogoutSlot") 
	local customParams; customParams = ( e ).stringParam;
	GameUtility.TweenAlphaClose(this.Server.ServerObj, this.Account:GetAccountObj()) 
end

function _lua_LoginCom:OnTouchStart()
	GameLog("------------------------------_lua_LoginCom OnTouchStart------------------------------")
	if (not this._canStart) then
		return  
	end 
	this:OnEnterLogin() 
	this.entity:DispatchEvent(CS.Eight.Framework.EIEvent("AUDIO_PLAY_SOUND",nil,ClickGameAudioSoundParam(1) ,0.00) ) 
end

function _lua_LoginCom:OnStartLogin()
	GameLog("------------------------------_lua_LoginCom OnStartLogin------------------------------")
end

function _lua_LoginCom:OnEnterLogin()
	GameLog("------------------------------_lua_LoginCom OnEnterLogin------------------------------")
	local server; server = this.Server:GetSelectServer();
	if (server == nil) then
		return  
	end 
	if (CS.System.Convert.ToInt32(server.BaseState) == 3) then
		local param; param = CS.EightGame.Logic.CommonTipsParam("服务器人数已满，请稍后再登录",0,nil,nil,"") ;
		param.isShowOKCancelBtn = false 
		this.entity:DispatchEvent(CS.Eight.Framework.EIEvent("UI_TIPS",nil,param,0.00) ) 
		return  
	end 
	if (this.entity ~= nil) then
		this.entity:DispatchEvent(CS.Eight.Framework.EIEvent("LOGIN_START",nil,nil,0.00) ) 
	end 
	if not isnil(this.Account) then
		this.Account:SetFieldActive(false) 
	end 
	if not isnil(this._logoEffect) then
		this._logoEffect.gameObject:SetActive(false) 
	end 
	if not isnil(this.Anim) then
		this.Anim:PlayEnter() 
	end 
end

function _lua_LoginCom:OnOpenLogin()
	GameLog("------------------------------_lua_LoginCom OnOpenLogin------------------------------")
	if not isnil(this.Anim) then
		this.Anim:PlayOpen() 
	end 
end

function _lua_LoginCom:OnLeaveLogin()
	GameLog("------------------------------_lua_LoginCom OnLeaveLogin------------------------------")
	if (this.entity ~= nil) then
		this.entity:DispatchEvent(CS.Eight.Framework.EIEvent("LOGIN_LEAVE",nil,nil,0.00) ) 
	end 
end

function _lua_LoginCom:PlayerLogoEffect( effectName)
	GameLog("------------------------------_lua_LoginCom PlayerLogoEffect------------------------------")
	if isnil(this._logoEffect) then
		return  
	end 
	CS.Eight.Framework.EIDebuger.GameLog(effectName) 
	this._logoEffect:Play(effectName) 
end

function _lua_LoginCom:SetVersion()
	GameLog("------------------------------_lua_LoginCom SetVersion------------------------------")
	if isnil(this._versionLbl) then
		return  
	end 
	this._versionLbl.text = CS.System.String.Format("版本号: {0}.{1}.{2}", VersionUtility.GetVersion(), VersionUtility.GetSubVersion(), VersionUtility.GetMSubVersion()) 
end

function _lua_LoginCom:SetChangeIp()
	GameLog("------------------------------_lua_LoginCom SetChangeIp------------------------------")
	CS.EightGame.Logic.LoginHelp.ChangeIp() 
end

function _lua_LoginCom:ReturnAccountPage()
	GameLog("------------------------------_lua_LoginCom ReturnAccountPage------------------------------")
	this:OnSDKLogoutBtnClickSlot() 
end

function _lua_LoginCom:OpenAllServerPage()
	GameLog("------------------------------_lua_LoginCom OpenAllServerPage------------------------------")
	GameUtility.TweenScaleOpen(this.Server.AllServerPage) 
	GameUtility.TweenAlphaClose(this.Server.ServerObj, nil) 
end

function _lua_LoginCom:ColseAllServerPage()
	GameLog("------------------------------_lua_LoginCom ColseAllServerPage------------------------------")
	GameUtility.TweenScaleClose(this.Server.AllServerPage) 
	GameUtility.TweenAlphaOpen(this.Server.ServerObj) 
end

function _lua_LoginCom:LoginAccount( e)
	GameLog("------------------------------_lua_LoginCom LoginAccount------------------------------")
	local eb; eb = ( e ).boolParam;
	if eb then
		GameUtility.TweenAlphaClose(this.Account:GetAccountObj(), this.Server.ServerObj) 
	else
		this:ErrorTips("账号或密码错误") 
	end 
end

function _lua_LoginCom:RegisterAccount( e)
	GameLog("------------------------------_lua_LoginCom RegisterAccount------------------------------")
	local rInfo; rInfo = e.extraInfo;
	local accountName; accountName = rInfo.channelUid;
	local IsRegister; IsRegister = true;
	if IsRegister then
		this.Account:SetLatestAccount(accountName) 
		CS.UnityEngine.Debug.Log("注册成功！ ") 
	else
		this:ErrorTips("该账号已经存在") 
	end 
end

function _lua_LoginCom:ShowFloatTip( msg)
	GameLog("------------------------------_lua_LoginCom ShowFloatTip------------------------------")
	local param; param = CS.EightGame.Logic.TipStruct(msg,0.20) ;
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_FLOATING_TIPS",nil,param,0.00) ) 
end

function _lua_LoginCom:ErrorTips( errorStr)
	GameLog("------------------------------_lua_LoginCom ErrorTips------------------------------")
	local tip; tip = CS.EightGame.Logic.CommonTipsParam(errorStr,0,nil,nil,"") ;
	tip.isShowOKCancelBtn = false 
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_TIPS",nil,tip,0.00) ) 
end

function _lua_LoginCom:ChoiceServer( e)
	GameLog("------------------------------_lua_LoginCom ChoiceServer------------------------------")
	local ei; ei = e.extraInfo;
	this.Server.CurrentServer.text = ei.ServerName 
	this.Server.CurrentServerInAll.MyButtonData = ei 
	this.Server.CurrentServerInAll.SVName.text = CS.System.String.Format("[b][u]{0}[/u][/b]", ei.ServerName) 
	this:ColseAllServerPage() 
end

function _lua_LoginCom:LoginServer()
	GameLog("------------------------------_lua_LoginCom LoginServer------------------------------")
end

function _lua_LoginCom:hotfix()
	xlua.hotfix(LoginCom, {
       ['Init'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:Init()
       end,
       ['InitMessage'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:InitMessage()
       end,
       ['LogoFinsh'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:LogoFinsh()
       end,
       ['LoadLogonEffect'] = function(this, path)
           _lua_LoginCom:Ref(this)
           return util.cs_generator(function()
               _lua_LoginCom:LoadLogonEffect( path)
           end)
       end,
       ['ResetAnim'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:ResetAnim()
       end,
       ['Next'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:Next()
       end,
       ['Previous'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:Previous()
       end,
       ['OnSDKInitSlot'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnSDKInitSlot()
       end,
       ['OnSDKLoginBtnClickSlot'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnSDKLoginBtnClickSlot()
       end,
       ['OnSDKLoginQQBtnClickSlot'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnSDKLoginQQBtnClickSlot()
       end,
       ['OnSDKLoginWXBtnClickSlot'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnSDKLoginWXBtnClickSlot()
       end,
       ['ExecuteLogin'] = function(this, loginCustomParam)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:ExecuteLogin( loginCustomParam)
       end,
       ['OnSDKLogoutBtnClickSlot'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnSDKLogoutBtnClickSlot()
       end,
       ['OnSDKLoginSuccessSlot'] = function(this, e)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnSDKLoginSuccessSlot( e)
       end,
       ['OnSDKLoginFailedSlot'] = function(this, e)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnSDKLoginFailedSlot( e)
       end,
       ['OnSDKLogoutSlot'] = function(this, e)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnSDKLogoutSlot( e)
       end,
       ['OnTouchStart'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnTouchStart()
       end,
       ['OnStartLogin'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnStartLogin()
       end,
       ['OnEnterLogin'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnEnterLogin()
       end,
       ['OnOpenLogin'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnOpenLogin()
       end,
       ['OnLeaveLogin'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OnLeaveLogin()
       end,
       ['PlayerLogoEffect'] = function(this, effectName)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:PlayerLogoEffect( effectName)
       end,
       ['SetVersion'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:SetVersion()
       end,
       ['SetChangeIp'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:SetChangeIp()
       end,
       ['ReturnAccountPage'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:ReturnAccountPage()
       end,
       ['OpenAllServerPage'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:OpenAllServerPage()
       end,
       ['ColseAllServerPage'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:ColseAllServerPage()
       end,
       ['LoginAccount'] = function(this, e)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:LoginAccount( e)
       end,
       ['RegisterAccount'] = function(this, e)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:RegisterAccount( e)
       end,
       ['ShowFloatTip'] = function(this, msg)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:ShowFloatTip( msg)
       end,
       ['ErrorTips'] = function(this, errorStr)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:ErrorTips( errorStr)
       end,
       ['ChoiceServer'] = function(this, e)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:ChoiceServer( e)
       end,
       ['LoginServer'] = function(this)
           _lua_LoginCom:Ref(this)
           return _lua_LoginCom:LoginServer()
       end,
   })
end

table.insert(g_tbHotfix, _lua_LoginCom)