
local this = nil
_lua_ChatSliderViewCom = BaseCom:New('_lua_ChatSliderViewCom')
function _lua_ChatSliderViewCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatSliderViewCom:ChatBtnClick()
	GameLog("------------------------------_lua_ChatSliderViewCom ChatBtnClick------------------------------")
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIBoolEvent(ChatMsgManager.SHOW_CHAT_VIEW,true) ) 
end

function _lua_ChatSliderViewCom:Register()
	GameLog("------------------------------_lua_ChatSliderViewCom Register------------------------------")
	this._changeChatCheck = true 
	this:InitChatLabel() 
end

function _lua_ChatSliderViewCom:Unregister()
	GameLog("------------------------------_lua_ChatSliderViewCom Unregister------------------------------")
	this._changeChatCheck = false 
	this._msgList:Clear() 
	this._msg2List:Clear() 
	this._tipsMsg:Clear() 
end

function _lua_ChatSliderViewCom:ChangeChat()
	GameLog("------------------------------_lua_ChatSliderViewCom ChangeChat------------------------------")
	if (not this._changeChatCheck) then
		return  
	end 
	if ((obj_len(this._msgList) <= 0) or Equals(this._currentChatLabel.text, DictGetValue(this._msg2List, 0))) then
		if (obj_len(this._msg2List) < 2) then
			this._msg2List:Add(("[eee3b5]" .. DictGetValue(this._tipsMsg, CS.UnityEngine.Random.Range(0, obj_len(this._tipsMsg)-1 )).tips)) 
		end 
		this._currentChatLabel.text = DictGetValue(this._msg2List, 0) 
		local lineMul; lineMul = ( (this._currentChatLabel.width > this._msgWidth) ) and true or false;
		this._msg2List:RemoveAt(0) 
		if (obj_len(this._msgList) > 0) then
			this._nextChatLabel.text = DictGetValue(this._msgList, 0) 
		else
			this._nextChatLabel.text = DictGetValue(this._msg2List, 0) 
		end 
		if lineMul then
			this._toCurrent = invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", ( 264-this._currentChatLabel.width  ), CS.UnityEngine.Vector3.right) 
			this:OpenChatCurrentLabelLeftMove(this._mulLineDelayTime, (function()
				this._toCurrent = this._currentChatLabel.transform.localPosition + invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", CS.UnityEngine.Vector3.up, this._labelDistance) 
				this:OpenChatCurrentLabelMove(this._mulLineDelayTime, nil) 
				this._toNext = this._nextChatLabel.transform.localPosition + invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", CS.UnityEngine.Vector3.up, this._labelDistance) 
				this:OpenChatNextLabelMove(this._mulLineDelayTime, (function()
					this:ResetChatUI() 
				end)) 
			end)) 
		else
			this._toCurrent = this._currentChatLabel.transform.localPosition + invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", CS.UnityEngine.Vector3.up, this._labelDistance) 
			this:OpenChatCurrentLabelMove(this._oneLineDelayTime, nil) 
			this._toNext = this._nextChatLabel.transform.localPosition + invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", CS.UnityEngine.Vector3.up, this._labelDistance) 
			this:OpenChatNextLabelMove(this._oneLineDelayTime, (function()
				this:ResetChatUI() 
			end)) 
		end 
	else
		local lineMul; lineMul = ( (this._currentChatLabel.width > this._msgWidth) ) and true or false;
		this._msgList:RemoveAt(0) 
		if (obj_len(this._msgList) > 0) then
			this._nextChatLabel.text = DictGetValue(this._msgList, 0) 
		else
			this._nextChatLabel.text = DictGetValue(this._msg2List, 0) 
		end 
		if lineMul then
			this._toCurrent = invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", ( 264-this._currentChatLabel.width  ), CS.UnityEngine.Vector3.right) 
			this:OpenChatCurrentLabelLeftMove(this._mulLineDelayTime, (function()
				this._toCurrent = this._currentChatLabel.transform.localPosition + invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", CS.UnityEngine.Vector3.up, this._labelDistance) 
				this:OpenChatCurrentLabelMove(this._mulLineDelayTime, nil) 
				this._toNext = this._nextChatLabel.transform.localPosition + invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", CS.UnityEngine.Vector3.up, this._labelDistance) 
				this:OpenChatNextLabelMove(this._mulLineDelayTime, (function()
					this._currentChatLabel.transform.localPosition = CS.UnityEngine.Vector3(-261,-17,0) 
					this:ResetChatUI() 
				end)) 
			end)) 
		else
			this._toCurrent = this._currentChatLabel.transform.localPosition + invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", CS.UnityEngine.Vector3.up, this._labelDistance) 
			this:OpenChatCurrentLabelMove(this._oneLineDelayTime, nil) 
			this._toNext = this._nextChatLabel.transform.localPosition + invokeexternoperator(CS.UnityEngine.Vector3, "op_Multiply", CS.UnityEngine.Vector3.up, this._labelDistance) 
			this:OpenChatNextLabelMove(this._oneLineDelayTime, (function()
				this:ResetChatUI() 
			end)) 
		end 
	end 
end

function _lua_ChatSliderViewCom:OpenChatCurrentLabelMove( delay, fallback)
	GameLog("------------------------------_lua_ChatSliderViewCom OpenChatCurrentLabelMove------------------------------")
	this:Invoke("OpenChatCurrentLabel", delay) 
	this._currentAction = fallback 
end

function _lua_ChatSliderViewCom:OpenChatCurrentLabel()
	GameLog("------------------------------_lua_ChatSliderViewCom OpenChatCurrentLabel------------------------------")
	this._openCurrent = true 
end

function _lua_ChatSliderViewCom:OpenChatCurrentLabelLeftMove( delay, fallback)
	GameLog("------------------------------_lua_ChatSliderViewCom OpenChatCurrentLabelLeftMove------------------------------")
	this:Invoke("OpenChatCurrentLabelLeft", delay) 
	this._currentActionLeft = fallback 
end

function _lua_ChatSliderViewCom:OpenChatCurrentLabelLeft()
	GameLog("------------------------------_lua_ChatSliderViewCom OpenChatCurrentLabelLeft------------------------------")
	this._openCurrentLeft = true 
end

function _lua_ChatSliderViewCom:OpenChatNextLabelMove( delay, fallback)
	GameLog("------------------------------_lua_ChatSliderViewCom OpenChatNextLabelMove------------------------------")
	this:Invoke("OpenChatNextLabel", delay) 
	this._nextAction = fallback 
end

function _lua_ChatSliderViewCom:OpenChatNextLabel()
	GameLog("------------------------------_lua_ChatSliderViewCom OpenChatNextLabel------------------------------")
	this._openNext = true 
end

function _lua_ChatSliderViewCom:ResetChatUI()
	GameLog("------------------------------_lua_ChatSliderViewCom ResetChatUI------------------------------")
	this._currentChatLabel.transform.localPosition = CS.UnityEngine.Vector3(-261,-17,0) 
	local tempLabel; tempLabel = this._currentChatLabel;
	this._currentChatLabel = this._nextChatLabel 
	this._nextChatLabel = tempLabel 
	this:ChangeChat() 
end

function _lua_ChatSliderViewCom:hotfix()
	xlua.hotfix(ChatSliderViewCom, {
       ['ChatBtnClick'] = function(this)
           _lua_ChatSliderViewCom:Ref(this)
           return _lua_ChatSliderViewCom:ChatBtnClick()
       end,
       ['Register'] = function(this)
           _lua_ChatSliderViewCom:Ref(this)
           return _lua_ChatSliderViewCom:Register()
       end,
       ['Unregister'] = function(this)
           _lua_ChatSliderViewCom:Ref(this)
           return _lua_ChatSliderViewCom:Unregister()
       end,
       ['ChangeChat'] = function(this)
           _lua_ChatSliderViewCom:Ref(this)
           return _lua_ChatSliderViewCom:ChangeChat()
       end,
       ['OpenChatCurrentLabelMove'] = function(this, delay, fallback)
           _lua_ChatSliderViewCom:Ref(this)
           return _lua_ChatSliderViewCom:OpenChatCurrentLabelMove( delay, fallback)
       end,
       ['OpenChatCurrentLabel'] = function(this)
           _lua_ChatSliderViewCom:Ref(this)
           return _lua_ChatSliderViewCom:OpenChatCurrentLabel()
       end,
       ['OpenChatCurrentLabelLeftMove'] = function(this, delay, fallback)
           _lua_ChatSliderViewCom:Ref(this)
           return _lua_ChatSliderViewCom:OpenChatCurrentLabelLeftMove( delay, fallback)
       end,
       ['OpenChatCurrentLabelLeft'] = function(this)
           _lua_ChatSliderViewCom:Ref(this)
           return _lua_ChatSliderViewCom:OpenChatCurrentLabelLeft()
       end,
       ['OpenChatNextLabelMove'] = function(this, delay, fallback)
           _lua_ChatSliderViewCom:Ref(this)
           return _lua_ChatSliderViewCom:OpenChatNextLabelMove( delay, fallback)
       end,
       ['OpenChatNextLabel'] = function(this)
           _lua_ChatSliderViewCom:Ref(this)
           return _lua_ChatSliderViewCom:OpenChatNextLabel()
       end,
       ['ResetChatUI'] = function(this)
           _lua_ChatSliderViewCom:Ref(this)
           return _lua_ChatSliderViewCom:ResetChatUI()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatSliderViewCom)