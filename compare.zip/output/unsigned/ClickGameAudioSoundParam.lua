
local this = nil
_lua_ClickGameAudioSoundParam = BaseCom:New('_lua_ClickGameAudioSoundParam')
function _lua_ClickGameAudioSoundParam:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClickGameAudioSoundParam:hotfix()
end

table.insert(g_tbHotfix, _lua_ClickGameAudioSoundParam)