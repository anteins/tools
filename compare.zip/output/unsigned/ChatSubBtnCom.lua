
local this = nil
_lua_ChatSubBtnCom = BaseCom:New('_lua_ChatSubBtnCom')
function _lua_ChatSubBtnCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatSubBtnCom:SetData( chatSubType, callbaclClick)
	GameLog("------------------------------_lua_ChatSubBtnCom SetData------------------------------")
	this._subtype = chatSubType 
	this._callbackClick = callbaclClick 
	this:SetLbl(this._subtype) 
end

function _lua_ChatSubBtnCom:SetLbl( subtype)
	GameLog("------------------------------_lua_ChatSubBtnCom SetLbl------------------------------")
	if isnil(this._contentLbl) then
		return  
	end 
	local str; str = "";
	local __compiler_switch_31 = subtype;
	if __compiler_switch_31 == 0 then
	elseif __compiler_switch_31 == 1 then
		str = "添加好友" 
	elseif __compiler_switch_31 == 2 then
		str = "私聊" 
	end 
	this._contentLbl.text = str 
end

function _lua_ChatSubBtnCom:OnClick()
	GameLog("------------------------------_lua_ChatSubBtnCom OnClick------------------------------")
	if this ~= "_callbackClick" then
		this._callbackClick(this._subtype) 
	end 
end

function _lua_ChatSubBtnCom:hotfix()
	xlua.hotfix(ChatSubBtnCom, {
       ['SetData'] = function(this, chatSubType, callbaclClick)
           _lua_ChatSubBtnCom:Ref(this)
           return _lua_ChatSubBtnCom:SetData( chatSubType, callbaclClick)
       end,
       ['SetLbl'] = function(this, subtype)
           _lua_ChatSubBtnCom:Ref(this)
           return _lua_ChatSubBtnCom:SetLbl( subtype)
       end,
       ['OnClick'] = function(this)
           _lua_ChatSubBtnCom:Ref(this)
           return _lua_ChatSubBtnCom:OnClick()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatSubBtnCom)