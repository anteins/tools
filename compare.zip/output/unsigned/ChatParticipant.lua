
local this = nil
_lua_ChatParticipant = BaseCom:New('_lua_ChatParticipant')
function _lua_ChatParticipant:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatParticipant:get_hudText()
	GameLog("------------------------------_lua_ChatParticipant get_hudText------------------------------")
	return this.mText 
end

function _lua_ChatParticipant:hotfix()
	xlua.hotfix(ChatParticipant, {
   })
end

table.insert(g_tbHotfix, _lua_ChatParticipant)