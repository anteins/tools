
local this = nil
_lua_ClubIntegralModel = BaseCom:New('_lua_ClubIntegralModel')
function _lua_ClubIntegralModel:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubIntegralModel:Init( isTaken, sd)
	GameLog("------------------------------_lua_ClubIntegralModel Init------------------------------")
	this:SetPointLabel(isTaken, sd.targetintegral) 
	this:SetInfoLabel(isTaken) 
	this:SetItems(GameUtility.GetKeyvalueiiArrayHack(sd.rewardshow)) 
	this:SetBgSprite(isTaken) 
end

function _lua_ClubIntegralModel:SetPointLabel( isTaken, point)
	GameLog("------------------------------_lua_ClubIntegralModel SetPointLabel------------------------------")
	if isnil(this.pointLabel) then
		return  
	end 
	this.pointLabel.text = CS.System.String.Format("[{0}]{1}积分[-]", isTaken and "3b3736" or "774f2c", point) 
end

function _lua_ClubIntegralModel:SetInfoLabel( isTaken)
	GameLog("------------------------------_lua_ClubIntegralModel SetInfoLabel------------------------------")
	if isnil(this.infoLabel) then
		return  
	end 
	this.infoLabel.text = isTaken and "[3b3736]已领取[-]" or "[c7202c]未达成[-]" 
end

function _lua_ClubIntegralModel:SetBgSprite( isTaken)
	GameLog("------------------------------_lua_ClubIntegralModel SetBgSprite------------------------------")
	if isnil(this.bgSprite) then
		return  
	end 
	this.bgSprite.color = isTaken and (function() return this._greyColor  end) or this._whiteColor  
end

function _lua_ClubIntegralModel:hotfix()
	xlua.hotfix(ClubIntegralModel, {
       ['Init'] = function(this, isTaken, sd)
           _lua_ClubIntegralModel:Ref(this)
           return _lua_ClubIntegralModel:Init( isTaken, sd)
       end,
       ['SetPointLabel'] = function(this, isTaken, point)
           _lua_ClubIntegralModel:Ref(this)
           return _lua_ClubIntegralModel:SetPointLabel( isTaken, point)
       end,
       ['SetInfoLabel'] = function(this, isTaken)
           _lua_ClubIntegralModel:Ref(this)
           return _lua_ClubIntegralModel:SetInfoLabel( isTaken)
       end,
       ['SetBgSprite'] = function(this, isTaken)
           _lua_ClubIntegralModel:Ref(this)
           return _lua_ClubIntegralModel:SetBgSprite( isTaken)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubIntegralModel)