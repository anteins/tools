
local this = nil
_lua_LotteryDotModelCom = BaseCom:New('_lua_LotteryDotModelCom')
function _lua_LotteryDotModelCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LotteryDotModelCom:SetHihglight( isHighlight)
	GameLog("------------------------------_lua_LotteryDotModelCom SetHihglight------------------------------")
	this.DotHighlight:SetActive(isHighlight) 
end

function _lua_LotteryDotModelCom:SetNotice( isNotice)
	GameLog("------------------------------_lua_LotteryDotModelCom SetNotice------------------------------")
	this.DotNotice:SetActive(isNotice) 
end

function _lua_LotteryDotModelCom:UpdateUI( isHightlight, isNotice)
	GameLog("------------------------------_lua_LotteryDotModelCom UpdateUI------------------------------")
	this:SetHihglight(isHightlight) 
	this:SetNotice(((not isHightlight) and isNotice)) 
end

function _lua_LotteryDotModelCom:hotfix()
	xlua.hotfix(LotteryDotModelCom, {
       ['SetHihglight'] = function(this, isHighlight)
           _lua_LotteryDotModelCom:Ref(this)
           return _lua_LotteryDotModelCom:SetHihglight( isHighlight)
       end,
       ['SetNotice'] = function(this, isNotice)
           _lua_LotteryDotModelCom:Ref(this)
           return _lua_LotteryDotModelCom:SetNotice( isNotice)
       end,
       ['UpdateUI'] = function(this, isHightlight, isNotice)
           _lua_LotteryDotModelCom:Ref(this)
           return _lua_LotteryDotModelCom:UpdateUI( isHightlight, isNotice)
       end,
   })
end

table.insert(g_tbHotfix, _lua_LotteryDotModelCom)