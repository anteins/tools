
local this = nil
_lua_ChatWorldChanelController = BaseCom:New('_lua_ChatWorldChanelController')
function _lua_ChatWorldChanelController:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatWorldChanelController:SetData( notify, callbackSelect)
	GameLog("------------------------------_lua_ChatWorldChanelController SetData------------------------------")
	this._notify = notify 
	this._notify.msgList:Sort((function(x, y)
		if (x.word_room_id > y.word_room_id) then
			return 1 
		elseif (x.word_room_id < y.word_room_id) then
			return -1 
		else
			return 0 
		end 
	end)) 
	this._callbackSelect = callbackSelect 
	this:MatchBgSpriteAndPanel() 
	if not isnil(this._uiRecycledList) then
		this._uiRecycledList.onUpdateItem =  (function(go, itemIndex, dataIndex) this:OnUpdateItem(go, itemIndex, dataIndex) end) 
	end 
	CS.Eight.Framework.EIFrameWork.StartCoroutine(this:LoadPrefab(), false) 
end

function _lua_ChatWorldChanelController:OnUpdateItem( go, itemIndex, dataIndex)
	GameLog("------------------------------_lua_ChatWorldChanelController OnUpdateItem------------------------------")
	if (dataIndex < obj_len(this._notify.msgList)) then
		local com; com = nil;
		if (function() local __compiler_invoke_47  __compiler_invoke_47, com = this._applicationItemDic:TryGetValue(go)  return __compiler_invoke_47  end)() then
			if isnil(com) then
				return  
			end 
			com:SetData(DictGetValue(this._notify.msgList, dataIndex), function(msg) this:CallbackSelect(msg) end, (this._notify.chanelId == DictGetValue(this._notify.msgList, dataIndex).word_room_id)) 
		end 
	end 
end

function _lua_ChatWorldChanelController:CallbackSelect( msg)
	GameLog("------------------------------_lua_ChatWorldChanelController CallbackSelect------------------------------")
	if this ~= "_callbackSelect" then
		this._callbackSelect(msg) 
	end 
end

function _lua_ChatWorldChanelController:LoadPrefab()
	GameLog("------------------------------_lua_ChatWorldChanelController LoadPrefab------------------------------")
	if isnil(this._prefab) then
		local coroutine; coroutine = XLuaScriptUtils.GameResources():LoadAsyn(CS.System.String.Format("{0}{1}", "GameAssets/Prefabs/UI/", this._itemLinePrefabPath), "prefab", false);
		if coroutine.coroutine then
coroutine.yield(coroutine.coroutine)
end
		this._prefab = coroutine.res 
		this:InitItems() 
	end 
	this._uiRecycledList:UpdateDataCount(obj_len(this._notify.msgList), true) 
end

function _lua_ChatWorldChanelController:InitItems()
	GameLog("------------------------------_lua_ChatWorldChanelController InitItems------------------------------")
	if (isnil(this._prefab) or (obj_len(this._applicationItemDic) > 0)) then
		return  
	end 
	local index; index = 0;
	while (index < 12) do
		local go; go = GameUtility.InstantiateGameObject(this._prefab, this._uiRecycledList.gameObject, ("WorldChanel" .. index));
		local r; r = go:GetComponent("ChatWorldChanelItemCom");
		this._applicationItemDic:Add(go, r) 
	index = index+1  
	end 
end

function _lua_ChatWorldChanelController:OnClickClose()
	GameLog("------------------------------_lua_ChatWorldChanelController OnClickClose------------------------------")
	if not isnil(this) then
		this.gameObject:SetActive(false) 
	end 
end

function _lua_ChatWorldChanelController:MatchBgSpriteAndPanel()
	GameLog("------------------------------_lua_ChatWorldChanelController MatchBgSpriteAndPanel------------------------------")
	if (isnil(this._bgSprite) or isnil(this._bgPanel)) then
		return  
	end 
	local height; height = 30*obj_len(this._notify.msgList) ;
	if (height < 150) then
		height = 150 
	end 
	if (height > 450) then
		height = 450 
	end 
	this._bgSprite:SetDimensions(this._bgSprite.width, height) 
	this._bgPanel:SetRect(0, CS.UnityEngine.Mathf.CeilToInt((height / 2.00)), 176.00, ( (height - 5.00) )) 
	this._bgPanel.clipOffset = CS.UnityEngine.Vector2.zero 
	this._bgPanel.transform.localPosition = CS.UnityEngine.Vector3.zero 
	this._uiRecycledList.transform.localPosition = CS.UnityEngine.Vector3(0,(height - 20.00),0) 
end

function _lua_ChatWorldChanelController:hotfix()
	xlua.hotfix(ChatWorldChanelController, {
       ['SetData'] = function(this, notify, callbackSelect)
           _lua_ChatWorldChanelController:Ref(this)
           return _lua_ChatWorldChanelController:SetData( notify, callbackSelect)
       end,
       ['OnUpdateItem'] = function(this, go, itemIndex, dataIndex)
           _lua_ChatWorldChanelController:Ref(this)
           return _lua_ChatWorldChanelController:OnUpdateItem( go, itemIndex, dataIndex)
       end,
       ['CallbackSelect'] = function(this, msg)
           _lua_ChatWorldChanelController:Ref(this)
           return _lua_ChatWorldChanelController:CallbackSelect( msg)
       end,
       ['LoadPrefab'] = function(this)
           _lua_ChatWorldChanelController:Ref(this)
           return util.cs_generator(function()
               _lua_ChatWorldChanelController:LoadPrefab()
           end)
       end,
       ['InitItems'] = function(this)
           _lua_ChatWorldChanelController:Ref(this)
           return _lua_ChatWorldChanelController:InitItems()
       end,
       ['OnClickClose'] = function(this)
           _lua_ChatWorldChanelController:Ref(this)
           return _lua_ChatWorldChanelController:OnClickClose()
       end,
       ['MatchBgSpriteAndPanel'] = function(this)
           _lua_ChatWorldChanelController:Ref(this)
           return _lua_ChatWorldChanelController:MatchBgSpriteAndPanel()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatWorldChanelController)