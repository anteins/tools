
local this = nil
_lua_ChatMsgManager = BaseCom:New('_lua_ChatMsgManager')
function _lua_ChatMsgManager:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatMsgManager:CloseChat()
	GameLog("------------------------------_lua_ChatMsgManager CloseChat------------------------------")
	if not isnil(this._viewController) then
		this._viewController:CloseChat() 
	end 
end

function _lua_ChatMsgManager:InitChatView()
	GameLog("------------------------------_lua_ChatMsgManager InitChatView------------------------------")
	if isnil(this._viewController) then
		local coroutine; coroutine = XLuaScriptUtils.GameResources():LoadAsyn(CS.System.String.Format("{0}{1}", "GameAssets/Prefabs/UI/", this._viewPrefabPath), "prefab", false);
		if coroutine.coroutine then
coroutine.yield(coroutine.coroutine)
end
		local prefab; prefab = coroutine.res;
		if isnil(prefab) then
			GameLog(CS.System.String.Format(" load { 0 } error , please check", this._viewPrefabPath)) 
			return nil 
		end 
		local go; go = GameUtility.InstantiateGameObject(prefab, GlobalCamera.globalUICamera.gameObject, "ChatView");
		this._viewController = NGUITools.AddMissingComponent(go, ChatMainViewController) 
		this._viewController._com = go:GetComponent("ChatMainViewCom") 
	end 
	if not isnil(this._viewController) then
		this:BindComponent(this._viewController)
		this:RemoveAllEventListener() 
		this:AddEventListener(ChatMsgManager.SHOW_CHAT_VIEW, function(e) this:ShowChatView(e) end) 
		this._viewController:InitChat() 
		this:AddEventListener(ChatMsgManager.Instance.CHAT_MSG_ADD, function(e) this:ListenerMsgAdd(e) end) 
		this:AddEventListener(ChatExplainController.CLICK_CHATEXPLAIN_ACTION, function(e) this:ClickChatExplainAction(e) end) 
	end 
end

function _lua_ChatMsgManager:ListenerMsgAdd( e)
	GameLog("------------------------------_lua_ChatMsgManager ListenerMsgAdd------------------------------")
	if not isnil(this._viewController) then
		this._viewController._com:ListenerMsgAdd(e) 
	end 
end

function _lua_ChatMsgManager:ClickChatExplainAction( e)
	GameLog("------------------------------_lua_ChatMsgManager ClickChatExplainAction------------------------------")
	if not isnil(this._viewController) then
		this._viewController._com:ClickChatExplainAction(e) 
	end 
end

function _lua_ChatMsgManager:ShowChatView( e)
	GameLog("------------------------------_lua_ChatMsgManager ShowChatView------------------------------")
	local eb; eb = e;
	if not isnil(this._viewController) then
		this._viewController:ForceSetChatViewState(eb.boolParam) 
	end 
end

function _lua_ChatMsgManager:GetAllChatChannels()
	GameLog("------------------------------_lua_ChatMsgManager GetAllChatChannels------------------------------")
	local enumlist; enumlist = XLuaScriptUtils.new_List_1(typeof(CS.EightGame.Data.Server.se));
	enumlist:Add(se_chattype.SE_CHATTYPE_CHATWORLD ) 
	enumlist:Add(se_chattype.SE_CHATTYPE_CHATUNION ) 
	enumlist:Add(se_chattype.SE_CHATTYPE_CHATPRIVATE) 
	enumlist:Add(se_chattype.SE_CHATTYPE_CHATSYSTEM) 
	return enumlist 
end

function _lua_ChatMsgManager:AddChatMessage( msg)
	GameLog("------------------------------_lua_ChatMsgManager AddChatMessage------------------------------")
	if (msg.chattype == se_chattype.SE_CHATTYPE_CHATSYSTEM) then
		ListExtension.Push(this._allSystemChatmsgs, ChatMessage, msg) 
		if (obj_len(this._allSystemChatmsgs) > this._cachMsgCount) then
			ListExtension.DequeueHead(this._allSystemChatmsgs, ChatMessage) 
		end 
		ListExtension.Push(this._allChatMsgs, ChatMessage, msg) 
		if (obj_len(this._allChatMsgs) > this._cachMsgCount) then
			ListExtension.DequeueHead(this._allChatMsgs, ChatMessage) 
		end 
	elseif (msg.chattype == se_chattype.SE_CHATTYPE_CHATPRIVATE ) then
		local checkplayerid; checkplayerid = (msg.toplayerid == 0) and (function() return msg.playerid; end) or msg.toplayerid;;
		if this._allPrivateChatMsgDic:ContainsKey(checkplayerid) then
			ListExtension.Push(DictGetValue(this._allPrivateChatMsgDic, checkplayerid), ChatMessage, msg) 
			if (DictGetValue(this._allPrivateChatMsgDic, checkplayerid).Count > this._cachMsgCount) then
				ListExtension.DequeueHead(DictGetValue(this._allPrivateChatMsgDic, checkplayerid), ChatMessage) 
			end 
		else
			local ls; ls = XLuaScriptUtils.new_List_1(typeof(ChatMessage));
			ls:Add(msg) 
			this._allPrivateChatMsgDic:Add(checkplayerid, ls) 
		end 
		if this._allUnReadPrivateChatMsgDic:ContainsKey(checkplayerid) then
			ListExtension.Push(DictGetValue(this._allUnReadPrivateChatMsgDic, checkplayerid), ChatMessage, msg) 
			if (DictGetValue(this._allUnReadPrivateChatMsgDic, checkplayerid).Count > this._cachMsgCount) then
				ListExtension.DequeueHead(DictGetValue(this._allUnReadPrivateChatMsgDic, checkplayerid), ChatMessage) 
			end 
		else
			local ls; ls = XLuaScriptUtils.new_List_1(typeof(ChatMessage));
			ls:Add(msg) 
			this._allUnReadPrivateChatMsgDic:Add(checkplayerid, ls) 
		end 
	elseif (msg.chattype == se_chattype.SE_CHATTYPE_CHATUNION ) then
		ListExtension.Push(this._allUnionChatmsgs, ChatMessage, msg) 
		if (obj_len(this._allUnionChatmsgs) > this._cachMsgCount) then
			ListExtension.DequeueHead(this._allUnionChatmsgs, ChatMessage) 
		end 
	elseif (msg.chattype == se_chattype.SE_CHATTYPE_CHATWORLD ) then
		ListExtension.Push(this._allChatMsgs, ChatMessage, msg) 
		if (obj_len(this._allChatMsgs) > this._cachMsgCount) then
			ListExtension.DequeueHead(this._allChatMsgs, ChatMessage) 
		end 
	end 
	CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent(this.CHAT_MSG_ADD,nil,msg,0.00) ) 
end

function _lua_ChatMsgManager:ClearWorldChannelMsg()
	GameLog("------------------------------_lua_ChatMsgManager ClearWorldChannelMsg------------------------------")
	this._allChatMsgs:Clear() 
end

function _lua_ChatMsgManager:GetAllChatMessageByChannel( chattype, playerid)
	GameLog("------------------------------_lua_ChatMsgManager GetAllChatMessageByChannel------------------------------")
	if (chattype == se_chattype.SE_CHATTYPE_CHATPRIVATE ) then
		this:ClearUnReadPrivateChatMsg(playerid) 
		if this._allPrivateChatMsgDic:ContainsKey(playerid) then
			return DictGetValue(this._allPrivateChatMsgDic, playerid) 
		end 
	elseif (chattype == se_chattype.SE_CHATTYPE_CHATSYSTEM  ) then
		return this._allSystemChatmsgs 
	elseif (chattype == se_chattype.SE_CHATTYPE_CHATUNION ) then
		return this._allUnionChatmsgs 
	elseif (chattype == se_chattype.SE_CHATTYPE_CHATWORLD ) then
		return this._allChatMsgs 
	end 
	return XLuaScriptUtils.new_List_1(typeof(ChatMessage)) 
end

function _lua_ChatMsgManager:SortByTime( list)
	GameLog("------------------------------_lua_ChatMsgManager SortByTime------------------------------")
	list:Sort((function(x, y)
		if (x.chatTime > y.chatTime) then
			return 1 
		elseif (x.chatTime < y.chatTime) then
			return -1 
		else
			return 0 
		end 
	end)) 
	return list 
end

function _lua_ChatMsgManager:GetUnReadPrivateMsgs()
	GameLog("------------------------------_lua_ChatMsgManager GetUnReadPrivateMsgs------------------------------")
	return this._allUnReadPrivateChatMsgDic 
end

function _lua_ChatMsgManager:GetUnReadPrivateMsgsBYFid( friendId)
	GameLog("------------------------------_lua_ChatMsgManager GetUnReadPrivateMsgsBYFid------------------------------")
	if this._allUnReadPrivateChatMsgDic:ContainsKey(friendId) then
		return DictGetValue(this._allUnReadPrivateChatMsgDic, friendId) 
	end 
	return nil 
end

function _lua_ChatMsgManager:ClearUnReadPrivateChatMsg( playerid)
	GameLog("------------------------------_lua_ChatMsgManager ClearUnReadPrivateChatMsg------------------------------")
	if this._allUnReadPrivateChatMsgDic:ContainsKey(playerid) then
		this._allUnReadPrivateChatMsgDic:Remove(playerid) 
	end 
end

function _lua_ChatMsgManager:CheckChatLock( str)
	GameLog("------------------------------_lua_ChatMsgManager CheckChatLock------------------------------")
	return this._chatLockList:Contains(str) 
end

function _lua_ChatMsgManager:RemoveChatLock( str)
	GameLog("------------------------------_lua_ChatMsgManager RemoveChatLock------------------------------")
	if this._chatLockList:Contains(str) then
		this._chatLockList:Remove(str) 
	end 
end

function _lua_ChatMsgManager:GetCanChatLock( chattype)
	GameLog("------------------------------_lua_ChatMsgManager GetCanChatLock------------------------------")
	local cooldownLock; cooldownLock = "";
	if (chattype == se_chattype.SE_CHATTYPE_CHATWORLD ) then
		cooldownLock = cooldownLock + CS.System.String.Format("{0}_{1}", this._beginCoolDownChatLock, se_chattype.SE_CHATTYPE_CHATWORLD:tostring()) 
	elseif (chattype == se_chattype.SE_CHATTYPE_CHATUNION ) then
		cooldownLock = cooldownLock + CS.System.String.Format("{0}_{1}", this._beginCoolDownChatLock, se_chattype.SE_CHATTYPE_CHATUNION:tostring()) 
	end 
	return this:CheckChatLock(cooldownLock) 
end

function _lua_ChatMsgManager:ClearAllData()
	GameLog("------------------------------_lua_ChatMsgManager ClearAllData------------------------------")
	this._allChatMsgs:Clear() 
	this._allPrivateChatMsgDic:Clear() 
	this._allSystemChatmsgs:Clear() 
	this._allPrivateChatMsgDic:Clear() 
	this._allUnReadPrivateChatMsgDic:Clear() 
	CoolDownManager.Instance:CancelCoolDown(this._beginCoolDownChatLock) 
	this._chatLockList:Clear() 
end

function _lua_ChatMsgManager:Decolor( str)
	GameLog("------------------------------_lua_ChatMsgManager Decolor------------------------------")
	local pureStr; pureStr = CS.System.Text.RegularExpressions.Regex.Replace(Trim(str), "\\[\\w{6}\\]", "");
	pureStr = Replace(pureStr, "\n","") 
	pureStr = Replace(pureStr, "\t","") 
	pureStr = Replace(pureStr, "\f","") 
	return pureStr 
end

function _lua_ChatMsgManager:FifterString( scontent)
	GameLog("------------------------------_lua_ChatMsgManager FifterString------------------------------")
	if CS.System.String.IsNullOrEmpty(scontent) then
		return "" 
	end 
	scontent = this:Decolor(scontent) 
	return scontent 
end

function _lua_ChatMsgManager:FifterKeyWord( scontent, chattype)
	GameLog("------------------------------_lua_ChatMsgManager FifterKeyWord------------------------------")
	if CS.System.String.IsNullOrEmpty(scontent) then
		return false 
	end 
	if (this._chatKeyWordNotify == nil) then
		return false 
	end 
	if (not this._chatKeyWordNotify.chattyps:Contains(chattype)) then
		return false 
	end 
	return this:CheckKeyWord(scontent) 
end

function _lua_ChatMsgManager:CheckKeyWord( str)
	GameLog("------------------------------_lua_ChatMsgManager CheckKeyWord------------------------------")
	if ((this._keyWordArray == nil) or (obj_len(this._keyWordArray) == 0)) then
		return false 
	end 
	local index; index = 0;
	local imax; imax = obj_len(this._keyWordArray);
	while (index < imax) do
		local match; match = CS.System.Text.RegularExpressions.Regex.Match(Trim(str), DictGetValue(this._keyWordArray, index + 1));
		if match.Success then
			return true 
		end 
	index = index+1  
	end 
	return false 
end

function _lua_ChatMsgManager:JoinItemContent( obj)
	GameLog("------------------------------_lua_ChatMsgManager JoinItemContent------------------------------")
	local str; str = "";
	local des; des = nil;
	if typeis(obj, CS.EightGame.Data.Server.ItemSerData, false) then
		des = ChatItemDes()  
	elseif typeis(obj, CS.EightGame.Data.Server.EquipmentSerData, false) then
		des = ChatEquipmentDes()  
	elseif typeis(obj, CS.EightGame.Data.Server.FighterSerData, false) then
		des = ChatFighterDes()  
	elseif typeis(obj, CS.EightGame.Data.Server.sd_chatemoji, false) then
		des = ChatEmojiDes()  
	end 
	if (des ~= nil) then
		str = des:JoinSendStr(obj) 
	end 
	str = CS.System.String.Format("#c_begin{0}#c_end", str) 
	return str 
end

function _lua_ChatMsgManager:JudgeSendCondition( obj, inputvalue)
	GameLog("------------------------------_lua_ChatMsgManager JudgeSendCondition------------------------------")
	return this:JudgeSendWorldLenght(obj, inputvalue) 
end

function _lua_ChatMsgManager:AnalysisMsgContent( str)
	GameLog("------------------------------_lua_ChatMsgManager AnalysisMsgContent------------------------------")
	if CS.System.String.IsNullOrEmpty(str) then
		return nil 
	end 
	local characterStr; characterStr = "";
	local itemContent; itemContent = "";
	local match; match = CS.System.Text.RegularExpressions.Regex.Match(Trim(str), "(.*)#c_begin(.+)obj_len(c_begin)(.*)");
	if (obj_len(match.Groups) > 1) then
		characterStr = DictGetValue(match.Groups, 1).Value 
		itemContent = DictGetValue(match.Groups, 2).Value 
	else
		characterStr = str 
	end 
	local t; t = this:AnalysisURLContent(itemContent);
	if (t == nil) then
		t = ChatMsgURLContent()  
	end 
	t.characterStr = characterStr 
	return t 
end

function _lua_ChatMsgManager:AnalysisURLContent( str)
	GameLog("------------------------------_lua_ChatMsgManager AnalysisURLContent------------------------------")
	if CS.System.String.IsNullOrEmpty(str) then
		return nil 
	end 
	local contentArray; contentArray = Split(str, wraparray{"itemtype=",",",},1);
	local itemtype; itemtype = "";
	if (obj_len(contentArray) > 0) then
		itemtype = DictGetValue(contentArray, 1) 
	end 
	local t; t = ChatMsgURLContent(itemtype,0,0,"","","") ;
	local des; des = nil;
	if (CS.System.Convert.ToInt32(t.itemtype) == 1) then
		des = ChatItemDes()  
	elseif (CS.System.Convert.ToInt32(t.itemtype) == 2) then
		des = ChatEquipmentDes()  
	elseif (CS.System.Convert.ToInt32(t.itemtype) == 3) then
		des = ChatFighterDes()  
	elseif (CS.System.Convert.ToInt32(t.itemtype) == 4) then
		des = ChatEmojiDes()  
	end 
	if (des ~= nil) then
		t = des:AnalysSendStr(str) 
	end 
	return t 
end

function _lua_ChatMsgManager:ClearAllCachData()
	GameLog("------------------------------_lua_ChatMsgManager ClearAllCachData------------------------------")
	this._allChatMsgs:Clear() 
	this._allPrivateChatMsgDic:Clear() 
	this._allUnionChatmsgs:Clear() 
	this._allSystemChatmsgs:Clear() 
end

function _lua_ChatMsgManager:GetColorByRank( rank)
	GameLog("------------------------------_lua_ChatMsgManager GetColorByRank------------------------------")
	local colorStr; colorStr = "ffffff";
	local __compiler_switch_688 = rank;
	if __compiler_switch_688 == 1 then
		colorStr = "919191" 
	elseif __compiler_switch_688 == 2 then
		colorStr = "5ac036" 
	elseif __compiler_switch_688 == 3 then
		colorStr = "4c8cd3" 
	elseif __compiler_switch_688 == 4 then
		colorStr = "d34c85" 
	elseif __compiler_switch_688 == 5 then
		colorStr = "d34c4c" 
	elseif __compiler_switch_688 == 6 then
		colorStr = "e2990c" 
	end 
	return colorStr 
end

function _lua_ChatMsgManager:ReceiveSysMessage( notify)
	GameLog("------------------------------_lua_ChatMsgManager ReceiveSysMessage------------------------------")
	this._getChatSysMessageNotify = notify 
end

function _lua_ChatMsgManager:GetChatSysMessageNotifyData()
	GameLog("------------------------------_lua_ChatMsgManager GetChatSysMessageNotifyData------------------------------")
	return this._getChatSysMessageNotify 
end

function _lua_ChatMsgManager:ReceiveKeyWordMessage( notify)
	GameLog("------------------------------_lua_ChatMsgManager ReceiveKeyWordMessage------------------------------")
	this._chatKeyWordNotify = notify 
	local str; str = notify.keyword;
	this._keyWordArray = Split(str, ',') 
end

function _lua_ChatMsgManager:hotfix()
	xlua.hotfix(ChatMsgManager, {
       ['CloseChat'] = function(this)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:CloseChat()
       end,
       ['InitChatView'] = function(this)
           _lua_ChatMsgManager:Ref(this)
           return util.cs_generator(function()
               _lua_ChatMsgManager:InitChatView()
           end)
       end,
       ['ListenerMsgAdd'] = function(this, e)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:ListenerMsgAdd( e)
       end,
       ['ClickChatExplainAction'] = function(this, e)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:ClickChatExplainAction( e)
       end,
       ['ShowChatView'] = function(this, e)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:ShowChatView( e)
       end,
       ['GetAllChatChannels'] = function(this)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:GetAllChatChannels()
       end,
       ['AddChatMessage'] = function(this, msg)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:AddChatMessage( msg)
       end,
       ['ClearWorldChannelMsg'] = function(this)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:ClearWorldChannelMsg()
       end,
       ['GetAllChatMessageByChannel'] = function(this, chattype, playerid)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:GetAllChatMessageByChannel( chattype, playerid)
       end,
       ['SortByTime'] = function(this, list)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:SortByTime( list)
       end,
       ['GetUnReadPrivateMsgs'] = function(this)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:GetUnReadPrivateMsgs()
       end,
       ['GetUnReadPrivateMsgsBYFid'] = function(this, friendId)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:GetUnReadPrivateMsgsBYFid( friendId)
       end,
       ['ClearUnReadPrivateChatMsg'] = function(this, playerid)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:ClearUnReadPrivateChatMsg( playerid)
       end,
       ['CheckChatLock'] = function(this, str)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:CheckChatLock( str)
       end,
       ['RemoveChatLock'] = function(this, str)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:RemoveChatLock( str)
       end,
       ['GetCanChatLock'] = function(this, chattype)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:GetCanChatLock( chattype)
       end,
       ['ClearAllData'] = function(this)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:ClearAllData()
       end,
       ['Decolor'] = function(this, str)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:Decolor( str)
       end,
       ['FifterString'] = function(this, scontent)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:FifterString( scontent)
       end,
       ['FifterKeyWord'] = function(this, scontent, chattype)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:FifterKeyWord( scontent, chattype)
       end,
       ['CheckKeyWord'] = function(this, str)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:CheckKeyWord( str)
       end,
       ['JoinItemContent'] = function(this, obj)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:JoinItemContent( obj)
       end,
       ['JudgeSendCondition'] = function(this, obj, inputvalue)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:JudgeSendCondition( obj, inputvalue)
       end,
       ['AnalysisMsgContent'] = function(this, str)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:AnalysisMsgContent( str)
       end,
       ['AnalysisURLContent'] = function(this, str)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:AnalysisURLContent( str)
       end,
       ['ClearAllCachData'] = function(this)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:ClearAllCachData()
       end,
       ['GetColorByRank'] = function(this, rank)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:GetColorByRank( rank)
       end,
       ['ReceiveSysMessage'] = function(this, notify)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:ReceiveSysMessage( notify)
       end,
       ['GetChatSysMessageNotifyData'] = function(this)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:GetChatSysMessageNotifyData()
       end,
       ['ReceiveKeyWordMessage'] = function(this, notify)
           _lua_ChatMsgManager:Ref(this)
           return _lua_ChatMsgManager:ReceiveKeyWordMessage( notify)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatMsgManager)