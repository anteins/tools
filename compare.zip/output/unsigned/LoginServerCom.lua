
local this = nil
_lua_LoginServerCom = BaseCom:New('_lua_LoginServerCom')
function _lua_LoginServerCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LoginServerCom:SetupData( serverList, defaultServer)
	GameLog("------------------------------_lua_LoginServerCom SetupData------------------------------")
	local filterServerList; filterServerList = XLuaScriptUtils.new_List_1(typeof(CS.EightGame.Logic.LoginServerParam));
	this._serverDict = XLuaScriptUtils.new_Dictionary_2(typeof(CS.System.String), typeof(CS.EightGame.Logic.LoginServerParam)) 
	foreach(serverList, function (item)
		local server = item.current
		if this._serverDict:ContainsKey(server.ServerName) then
			CS.Eight.Framework.EIDebuger.LogError(CS.System.String.Format("the server name of <{0}> is repeat , please check gateway message ", server.ServerName)) 
		else
			filterServerList:Add(server) 
			this._serverDict:Add(server.ServerName, server) 
		end 
	end)
	GameLog(("推荐服务器 :  " .. defaultServer.ServerUIState)) 
	this._currentServer = (defaultServer.ServerUIState == 1) and nil or defaultServer  
	if (this._currentServer ~= nil) then
		this:OnSelectServer(this._currentServer) 
	end 
	filterServerList:Sort((function(x, y) return CS.System.String.Compare(x.Uid, y.Uid)  end)) 
	GameLog((" filterServerList :" .. obj_len(filterServerList))) 
	this.AllServerList:AddRange(filterServerList:FindAll((function(x) return ((x.BaseState ~= 0) and (x.ServerUIState == 2))  end))) 
	this.AllServerList:AddRange(filterServerList:FindAll((function(x) return ((x.BaseState ~= 0) and (x.ServerUIState == 0))  end))) 
	this.AllServerList:AddRange(filterServerList:FindAll((function(x) return ((x.BaseState ~= 0) and (x.ServerUIState == 5))  end))) 
	this.AllServerList:AddRange(filterServerList:FindAll((function(x) return ((x.BaseState ~= 0) and (x.ServerUIState == 3))  end))) 
	this.AllServerList:AddRange(filterServerList:FindAll((function(x) return (x.ServerUIState == 1)  end))) 
	this.AllServerList:AddRange(filterServerList:FindAll((function(x) return ((x.BaseState == 0) and (x.ServerUIState ~= 4))  end))) 
	GameLog((" AllServerList :" .. obj_len(this.AllServerList))) 
	this.HideServerList:AddRange(filterServerList:FindAll((function(x) return (x.ServerUIState == 4)  end))) 
	this.AllServerList:AddRange(filterServerList:FindAll((function(x) return ( ((not this.AllServerList:Contains(x)) and (not this.HideServerList:Contains(x))) )  end))) 
	this:AllServerInit() 
end

function _lua_LoginServerCom:GetSelectServer()
	GameLog("------------------------------_lua_LoginServerCom GetSelectServer------------------------------")
	return this._currentServer 
end

function _lua_LoginServerCom:InitRecommendServers( Re1, Re2)
	GameLog("------------------------------_lua_LoginServerCom InitRecommendServers------------------------------")
	local sbcd1; sbcd1 = ServerButtonCom.ServerButtonData(0,Re1.Uid,Re1.ServerName,Re1.ServerUIState,Re1.ServerPort,Re1.ServerIP,Re1.BaseState) ;
	this.RecommendServer1.MyButtonData = sbcd1 
	this.RecommendServer1.SVName.text = CS.System.String.Format("{0}", Re1.ServerName) 
	local sbcd2; sbcd2 = ServerButtonCom.ServerButtonData(0,Re2.Uid,Re2.ServerName,Re2.ServerUIState,Re2.ServerPort,Re2.ServerIP,Re2.BaseState) ;
	this.RecommendServer2.MyButtonData = sbcd2 
	this.RecommendServer2.SVName.text = CS.System.String.Format("{0}", Re2.ServerName) 
end

function _lua_LoginServerCom:OnSelectServer( sbc)
	GameLog("------------------------------_lua_LoginServerCom OnSelectServer------------------------------")
	local sbcd; sbcd = ServerButtonCom.ServerButtonData(0,sbc.Uid,sbc.ServerName,sbc.ServerUIState,sbc.ServerPort,sbc.ServerIP,sbc.BaseState) ;
	local serverName; serverName = sbc.ServerName;
	this.CurrentServer.text = CS.System.String.Format("[{0}]{1}[-]", ServerButtonCom.BaseStColor(sbcd.MyBaseSt), serverName) 
	GameLog((" OnSelectServer  " .. this.CurrentServer.text)) 
	this.CurrentServerInAll.MyButtonData = sbcd 
	this.CurrentServerInAll.SVName.text = CS.System.String.Format("{0}", serverName) 
	if (not this._serverDict:ContainsKey(serverName)) then
		CS.Eight.Framework.EIDebuger.LogError("[Login] Server error") 
		return  
	end 
	this._currentServer = DictGetValue(this._serverDict, serverName) 
end

function _lua_LoginServerCom:OpenAllServerPage()
	GameLog("------------------------------_lua_LoginServerCom OpenAllServerPage------------------------------")
	GameUtility.TweenScaleOpen(this.AllServerPage) 
	GameUtility.TweenAlphaClose(this.ServerObj, nil) 
end

function _lua_LoginServerCom:CloseAllServerPage()
	GameLog("------------------------------_lua_LoginServerCom CloseAllServerPage------------------------------")
	GameUtility.TweenScaleClose(this.AllServerPage) 
	GameUtility.TweenAlphaOpen(this.ServerObj) 
end

function _lua_LoginServerCom:BackPage()
	GameLog("------------------------------_lua_LoginServerCom BackPage------------------------------")
	GameUtility.TweenAlphaClose(this.ServerObj, this.AccountPage) 
end

function _lua_LoginServerCom:ClickAllServerButton()
	GameLog("------------------------------_lua_LoginServerCom ClickAllServerButton------------------------------")
	local i; i = 0;
	while (i < obj_len(this.AllServerButton)) do
		DictGetValue(this.AllServerButton, i).gameObject:SetActive(true) 
	i = i+1  
	end 
	this.ServersGrid:Reposition() 
	this.ServerSCBar.value = 0 
	this:SetToggle(obj_len(this.EffectBgList)-1 ) 
end

function _lua_LoginServerCom:ClickMyServerButton()
	GameLog("------------------------------_lua_LoginServerCom ClickMyServerButton------------------------------")
	local i; i = 0;
	while (i < obj_len(this.AllServerButton)) do
		DictGetValue(this.AllServerButton, i).gameObject:SetActive(false) 
	i = i+1  
	end 
	this:SetToggle(obj_len(this.EffectBgList)-2 ) 
	local _MyHistory; _MyHistory = CS.UnityEngine.PlayerPrefs.GetString("MyServerHistory", "");
	GameLog(("_MyHistory  :" .. _MyHistory)) 
	if (_MyHistory == "") then
		return  
	end 
	local _allMy; _allMy = Split(_MyHistory, ',');
	local i; i = 0;
	while (i < obj_len(this.AllServerButton)) do
		local _sname; _sname = DictGetValue(this.AllServerButton, i).SVName.text;
		Trim(_sname) 
		foreach(_allMy, function (item)
			local _name = item.current
			if Contains(_sname, _name) then
				DictGetValue(this.AllServerButton, i).gameObject:SetActive(true) 
			end 
		end)
	i = i+1  
	end 
	this.ServersGrid:Reposition() 
	this.ServerSCBar.value = 0 
end

function _lua_LoginServerCom:AllServerInit()
	GameLog("------------------------------_lua_LoginServerCom AllServerInit------------------------------")
	CS.UIEventListener.Get(this.CurrentServerInAll.gameObject).onClick =  (function(SignleServer) this:ChoiceServer(SignleServer) end) 
	CS.UIEventListener.Get(this.RecommendServer1.gameObject).onClick =  (function(SignleServer) this:ChoiceServer(SignleServer) end) 
	CS.UIEventListener.Get(this.RecommendServer2.gameObject).onClick =  (function(SignleServer) this:ChoiceServer(SignleServer) end) 
	local i; i = 0;
	while (i < obj_len(this.ServerCategories)) do
		CS.UIEventListener.Get(DictGetValue(this.ServerCategories, i).transform.parent.gameObject).onClick =  (function(ChanelBt) this:ClickCategoriesButton(ChanelBt) end) 
		DictGetValue(this.ServerCategories, i).transform.parent.gameObject:SetActive(false) 
	i = i+1  
	end 
	this:ShowServer(obj_len(this.AllServerList)) 
	this:SetToggle(obj_len(this.EffectBgList)-1 ) 
	local GetRecList; GetRecList = this:GetRecommendList();
	if (obj_len(GetRecList) > 0) then
		this:InitRecommendServers(DictGetValue(GetRecList, 0), DictGetValue(GetRecList, 1)) 
	end 
end

function _lua_LoginServerCom:GetRecommendList()
	GameLog("------------------------------_lua_LoginServerCom GetRecommendList------------------------------")
	local _recomlist; _recomlist = XLuaScriptUtils.new_List_1(typeof(CS.EightGame.Logic.LoginServerParam));
	local i; i = obj_len(this.AllServerList)-1 ;
	while (i >= 0) do
		if (DictGetValue(this.AllServerList, i).ServerUIState == 2) then
			_recomlist:Add(DictGetValue(this.AllServerList, i)) 
			if (obj_len(_recomlist) >= 2) then
				break 
			end 
		end 
	i = i-1  
	end 
	if (obj_len(_recomlist) == 0) then
		if (obj_len(this.AllServerList) >= 2) then
			_recomlist:Add(DictGetValue(this.AllServerList, obj_len(this.AllServerList)-1)) 
			_recomlist:Add(DictGetValue(this.AllServerList, obj_len(this.AllServerList)-2)) 
		else
			_recomlist:Add(DictGetValue(this.AllServerList, 0)) 
		end 
	end 
	if (obj_len(_recomlist) == 1) then
		_recomlist:Add(DictGetValue(_recomlist, 0)) 
	end 
	return _recomlist 
end

function _lua_LoginServerCom:ShowServer( serverCount)
	GameLog("------------------------------_lua_LoginServerCom ShowServer------------------------------")
	local initnum; initnum = 20;
	local listCount; listCount = obj_len(this.ServerCategories);
	local rootCount; rootCount = div(serverCount, initnum) ;
	local remendN; remendN = serverCount%initnum ;
	local rootC; rootC =  div(rootCount, ( listCount-1  ))  +1 ;
	local rootNum; rootNum = rootCount%( listCount-1  ) ;
	local min; min = 1;
	local max; max = 0;
	local IsEnough; IsEnough = ( (serverCount > listCount*initnum ) );
	local i; i = 0;
	while (i < listCount) do
		if (i == listCount-1 ) then
			if IsEnough then
				max = max+remendN  
			else
				max = max+20  
			end 
		else
			if (i < rootNum) then
				max = max+rootC*20   
			elseif IsEnough then
				max = max+( rootC-1  )*20   
			else
				max = max+20  
			end 
			if (CS.System.Convert.ToInt32(i) == 0) then
				this:ShowServersByChoice(min, max) 
			end 
		end 
		DictGetValue(this.ServerCategories, i).text = CS.System.String.Format("S{0}-{1}", min, max) 
		this:InitAllServerButton(min, max) 
		min = max+1  
	i = i+1  
	end 
	if (not IsEnough) then
		this:OpenCategoriesButton(serverCount) 
	end 
end

function _lua_LoginServerCom:OpenCategoriesButton( svcount)
	GameLog("------------------------------_lua_LoginServerCom OpenCategoriesButton------------------------------")
	local i; i = 0;
	while (i < obj_len(this.ServerCategories)) do
		local chanelS; chanelS = DictGetValue(this.ServerCategories, i):GetComponent("UILabel").text;
		local min; min = 0;
		local max; max = 0;
		min, max = this:SplitDo(chanelS, min, max) 
		if (svcount >= min) then
			DictGetValue(this.ServerCategories, i).transform.parent.gameObject:SetActive(true) 
		end 
		if (svcount <= max) then
			break 
		end 
	i = i+1  
	end 
end

function _lua_LoginServerCom:ClickCategoriesButton( ChanelBt)
	GameLog("------------------------------_lua_LoginServerCom ClickCategoriesButton------------------------------")
	foreach(this.HideServerButton, function (item)
		local sbc = item.current
		sbc.gameObject:SetActive(false) 
	end)
	local lab; lab = ChanelBt:GetComponent("UILabel");
	local chanelS; chanelS = lab.text;
	local min; min = 0;
	local max; max = 0;
	min, max = this:SplitDo(chanelS, min, max) 
	this:ShowServersByChoice(min, max) 
	local i; i = 0;
	while (i < obj_len(this.ServerCategories)) do
		if lab == DictGetValue(this.ServerCategories, i) then
			this:SetToggle(i) 
			break 
		end 
	i = i+1  
	end 
end

function _lua_LoginServerCom:ShowHideServers()
	GameLog("------------------------------_lua_LoginServerCom ShowHideServers------------------------------")
	foreach(this.AllServerButton, function (item)
		local sbc = item.current
		sbc.gameObject:SetActive(false) 
	end)
	if (obj_len(this.HideServerButton) == 0) then
		foreach(this.HideServerList, function (item)
			local sbc = item.current
			this:CreatServerButton(99, sbc, this.HideServerButton) 
		end)
	else
		foreach(this.HideServerButton, function (item)
			local sbc = item.current
			sbc.gameObject:SetActive(true) 
		end)
	end 
	this.ServersGrid:Reposition() 
	this.ServerSCBar.value = 0 
end

function _lua_LoginServerCom:ClickShowHideServers()
	GameLog("------------------------------_lua_LoginServerCom ClickShowHideServers------------------------------")
	if (this.ClickHideNum >= 10) then
		this.ClickHideNum = 0 
		this:ShowHideServers() 
	else
		this.ClickHideNum = this.ClickHideNum+1  
	end 
end

function _lua_LoginServerCom:SplitDo( chanelS, _min, _max)
	GameLog("------------------------------_lua_LoginServerCom SplitDo------------------------------")
	local _num; _num = Split(chanelS, '-');
	_max = tonumber(DictGetValue(_num, 2)) 
	local mins; mins = ToCharArray(DictGetValue(_num, 1));
	local Ms; Ms = "";
	local i; i = 1;
	while (i < obj_len(mins)) do
		Ms = (Ms .. DictGetValue(mins, i + 1)) 
	i = i+1  
	end 
	_min = tonumber(tostring(Ms)) 
	return _min, _max 
end

function _lua_LoginServerCom:ChoiceServer( SignleServer)
	GameLog("------------------------------_lua_LoginServerCom ChoiceServer------------------------------")
	local sbc; sbc = ServerButtonCom() ;
	if Contains(SignleServer.name, "ServerName") then
		sbc = SignleServer.transform:GetComponent("ServerButtonCom") 
	else
		sbc = SignleServer.transform.parent:GetComponent("ServerButtonCom") 
	end 
	this:OnSelectServer(sbc.MyButtonData) 
	this:CloseAllServerPage() 
end

function _lua_LoginServerCom:InitAllServerButton( min, max)
	GameLog("------------------------------_lua_LoginServerCom InitAllServerButton------------------------------")
	local i; i = min;
	while (i < max) do
		if (i > obj_len(this.AllServerList)) then
			break 
		end 
		this:CreatServerButton(i, DictGetValue(this.AllServerList, i-1), this.AllServerButton) 
	i = i+1  
	end 
	this.ServersGrid:Reposition() 
	this.ServerSCBar.value = 0 
end

function _lua_LoginServerCom:ShowServersByChoice( min, max)
	GameLog("------------------------------_lua_LoginServerCom ShowServersByChoice------------------------------")
	local i; i = 0;
	while (i < obj_len(this.AllServerButton)) do
		if ((i >= min-1 ) and (i <= max-1 )) then
			if (min+i  > obj_len(this.AllServerButton)) then
				GameLog(" 服务器少于显示数量 ") 
				break 
			end 
			DictGetValue(this.AllServerButton, i).gameObject:SetActive(true) 
			GameLog(" 更新服务器状态 ") 
		else
			DictGetValue(this.AllServerButton, i).gameObject:SetActive(false) 
		end 
	i = i+1  
	end 
	this.ServersGrid:Reposition() 
end

function _lua_LoginServerCom:CreatServerButton( Id, SParam, _all)
	GameLog("------------------------------_lua_LoginServerCom CreatServerButton------------------------------")
	local ServerTemp; ServerTemp = GameUtility.InstantiateGameObject(this.ServerSample, this.ServersGrid.gameObject, tostring(Id));
	local sbc; sbc = ServerTemp:GetComponent("ServerButtonCom");
	local sbcd; sbcd = ServerButtonCom.ServerButtonData(Id,SParam.Uid,SParam.ServerName,SParam.ServerUIState,SParam.ServerPort,SParam.ServerIP,SParam.BaseState) ;
	sbc.MyButtonData = sbcd 
	sbc:Init() 
	sbc.MyBt:GetComponent("UIDragScrollView").scrollView = this.ServerScView 
	_all:Add(sbc) 
	CS.UIEventListener.Get(sbc.MyBt.gameObject).onClick =  (function(SignleServer) this:ChoiceServer(SignleServer) end) 
end

function _lua_LoginServerCom:SetToggle( _index)
	GameLog("------------------------------_lua_LoginServerCom SetToggle------------------------------")
	foreach(this.EffectBgList, function (item)
		local ef = item.current
		ef.gameObject:SetActive(false) 
	end)
	DictGetValue(this.EffectBgList, _index).gameObject:SetActive(true) 
end

function _lua_LoginServerCom:hotfix()
	xlua.hotfix(LoginServerCom, {
       ['SetupData'] = function(this, serverList, defaultServer)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:SetupData( serverList, defaultServer)
       end,
       ['GetSelectServer'] = function(this)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:GetSelectServer()
       end,
       ['InitRecommendServers'] = function(this, Re1, Re2)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:InitRecommendServers( Re1, Re2)
       end,
       ['OnSelectServer'] = function(this, sbc)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:OnSelectServer( sbc)
       end,
       ['OpenAllServerPage'] = function(this)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:OpenAllServerPage()
       end,
       ['CloseAllServerPage'] = function(this)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:CloseAllServerPage()
       end,
       ['BackPage'] = function(this)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:BackPage()
       end,
       ['ClickAllServerButton'] = function(this)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:ClickAllServerButton()
       end,
       ['ClickMyServerButton'] = function(this)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:ClickMyServerButton()
       end,
       ['AllServerInit'] = function(this)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:AllServerInit()
       end,
       ['GetRecommendList'] = function(this)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:GetRecommendList()
       end,
       ['ShowServer'] = function(this, serverCount)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:ShowServer( serverCount)
       end,
       ['OpenCategoriesButton'] = function(this, svcount)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:OpenCategoriesButton( svcount)
       end,
       ['ClickCategoriesButton'] = function(this, ChanelBt)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:ClickCategoriesButton( ChanelBt)
       end,
       ['ShowHideServers'] = function(this)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:ShowHideServers()
       end,
       ['ClickShowHideServers'] = function(this)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:ClickShowHideServers()
       end,
       ['SplitDo'] = function(this, chanelS, _min, _max)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:SplitDo( chanelS, _min, _max)
       end,
       ['ChoiceServer'] = function(this, SignleServer)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:ChoiceServer( SignleServer)
       end,
       ['InitAllServerButton'] = function(this, min, max)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:InitAllServerButton( min, max)
       end,
       ['ShowServersByChoice'] = function(this, min, max)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:ShowServersByChoice( min, max)
       end,
       ['CreatServerButton'] = function(this, Id, SParam, _all)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:CreatServerButton( Id, SParam, _all)
       end,
       ['SetToggle'] = function(this, _index)
           _lua_LoginServerCom:Ref(this)
           return _lua_LoginServerCom:SetToggle( _index)
       end,
   })
end

table.insert(g_tbHotfix, _lua_LoginServerCom)