
local this = nil
_lua_LotteryBtnEffect = BaseCom:New('_lua_LotteryBtnEffect')
function _lua_LotteryBtnEffect:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LotteryBtnEffect:hotfix()
end

table.insert(g_tbHotfix, _lua_LotteryBtnEffect)