
local this = nil
_lua_ClubCreateNode = BaseCom:New('_lua_ClubCreateNode')
function _lua_ClubCreateNode:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubCreateNode:CreateView()
	GameLog("------------------------------_lua_ClubCreateNode CreateView------------------------------")
	local c; c = XLuaScriptUtils.GameResources():LoadAsyn(("GameAssets/Prefabs/UI/" .. this._prefabPath), "prefab", false);
	coroutine.yield(c.coroutine) 
	local tempPrefab; tempPrefab = c.res;
	if isnil(tempPrefab) then
		CS.Eight.Framework.EIDebuger.LogError("load CreateTipsPanel error ") 
		return nil 
	end 
	local go; go = GameUtility.InstantiateGameObject(tempPrefab, nil, "ClubNewTipsUIWindow");
	this._clubNewTipsBehaviour = go:GetComponent("ClubNewTipsUIWindow") 
	this:BindComponent(this._clubNewTipsBehaviour)
	this:AddEventListener("OUT_CLUB_CREAT", function(e) this:OnExitCreate(e) end) 
	this:AddEventListener("GO_CLUB_SENCE", function(e) this:GoClubSence(e) end) 
	this:AddEventListener("GO_CLUB_APPLY_PAGE", function(e) this:GoJoinList(e) end) 
	this._clubNewTipsBehaviour:Init() 
	this._isReady = true 
end

function _lua_ClubCreateNode:GoJoinList( e)
	GameLog("------------------------------_lua_ClubCreateNode GoJoinList------------------------------")
	this.ViewParent:Push(typeof(ClubJoinNode), typeof(nil)) 
end

function _lua_ClubCreateNode:GoClubSence( e)
	GameLog("------------------------------_lua_ClubCreateNode GoClubSence------------------------------")
	local lobby; lobby = ( this.ViewParent.parent );
	if (lobby ~= nil) then
		local newInfo; newInfo = CS.EightGame.Logic.UIView.UIViewInfo() ;
		newInfo.viewType = ClubHouseNode 
		newInfo.param = nil 
		local list; list = XLuaScriptUtils.new_List_1(typeof(CS.EightGame.Logic.UIView.UIViewInfo));
		list:Add(newInfo) 
		lobby:ForceRestStack(list) 
		lobby:Push(typeof(ClubHouseNode), typeof(nil)) 
		ClubUtility.IsOut = false 
		ClubUtility.HaveMask = false 
		CS.Eight.Framework.EIFrameWork.StartCoroutine(ClubUtility.WaitDoloading(), false) 
	end 
end

function _lua_ClubCreateNode:OnExitCreate( e)
	GameLog("------------------------------_lua_ClubCreateNode OnExitCreate------------------------------")
	this._clubNewTipsBehaviour:ReturnTipsPage() 
end

function _lua_ClubCreateNode:hotfix()
	xlua.hotfix(ClubCreateNode, {
       ['CreateView'] = function(this)
           _lua_ClubCreateNode:Ref(this)
           return util.cs_generator(function()
               _lua_ClubCreateNode:CreateView()
           end)
       end,
       ['GoJoinList'] = function(this, e)
           _lua_ClubCreateNode:Ref(this)
           return _lua_ClubCreateNode:GoJoinList( e)
       end,
       ['GoClubSence'] = function(this, e)
           _lua_ClubCreateNode:Ref(this)
           return _lua_ClubCreateNode:GoClubSence( e)
       end,
       ['OnExitCreate'] = function(this, e)
           _lua_ClubCreateNode:Ref(this)
           return _lua_ClubCreateNode:OnExitCreate( e)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubCreateNode)