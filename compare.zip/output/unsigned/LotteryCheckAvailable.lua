
local this = nil
_lua_LotteryCheckAvailable = BaseCom:New('_lua_LotteryCheckAvailable')
function _lua_LotteryCheckAvailable:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LotteryCheckAvailable:hotfix()
end

table.insert(g_tbHotfix, _lua_LotteryCheckAvailable)