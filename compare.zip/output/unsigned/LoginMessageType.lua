
local this = nil
_lua_LoginMessageType = BaseCom:New('_lua_LoginMessageType')
function _lua_LoginMessageType:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LoginMessageType:hotfix()
end

table.insert(g_tbHotfix, _lua_LoginMessageType)