
local this = nil
_lua_ChangeNamePopupUICom = BaseCom:New('_lua_ChangeNamePopupUICom')
function _lua_ChangeNamePopupUICom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChangeNamePopupUICom:OnEnable()
	GameLog("------------------------------_lua_ChangeNamePopupUICom OnEnable------------------------------")
	this:SwitchCostTip() 
end

function _lua_ChangeNamePopupUICom:SwitchCostTip()
	GameLog("------------------------------_lua_ChangeNamePopupUICom SwitchCostTip------------------------------")
	local player; player = CS.Eight.Framework.EIFrameWork.GetComponent(CS.EightGame.Component.NetworkClient):GetDataByCls__System_Predicate_T(typeof(CS.EightGame.Data.Server.PlayerSerData), nil);
	local isHaveNameHistory; isHaveNameHistory = false;
	if (player.namehistory ~= nil) then
		local nameHistory; nameHistory = player.namehistory;
		if (obj_len(nameHistory) > 0) then
			local nameHistoryList; nameHistoryList = CS.MiniJSON.Json.Deserialize(nameHistory);
			if (obj_len(nameHistoryList) > 0) then
				isHaveNameHistory = true 
			end 
		end 
	end 
	this.costTipGO:SetActive(isHaveNameHistory) 
	this.freeTipGO:SetActive((not isHaveNameHistory)) 
end

function _lua_ChangeNamePopupUICom:hotfix()
	xlua.hotfix(ChangeNamePopupUICom, {
       ['OnEnable'] = function(this)
           _lua_ChangeNamePopupUICom:Ref(this)
           return _lua_ChangeNamePopupUICom:OnEnable()
       end,
       ['SwitchCostTip'] = function(this)
           _lua_ChangeNamePopupUICom:Ref(this)
           return _lua_ChangeNamePopupUICom:SwitchCostTip()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChangeNamePopupUICom)