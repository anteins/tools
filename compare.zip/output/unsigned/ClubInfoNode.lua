
local this = nil
_lua_ClubInfoNode = BaseCom:New('_lua_ClubInfoNode')
function _lua_ClubInfoNode:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubInfoNode:CreateView()
	GameLog("------------------------------_lua_ClubInfoNode CreateView------------------------------")
	local c; c = XLuaScriptUtils.GameResources():LoadAsyn(("GameAssets/Prefabs/UI/" .. this._prefabPath), "prefab", false);
	coroutine.yield(c.coroutine) 
	local tempPrefab; tempPrefab = c.res;
	if isnil(tempPrefab) then
		CS.Eight.Framework.EIDebuger.LogError("load ui_teamlistui error ") 
		return nil 
	end 
	local go; go = GameUtility.InstantiateGameObject(tempPrefab, nil, "ClubInfoPageUI");
	this._clubInfoPageUI = go:GetComponent("ClubInfoPageUI") 
	this:BindComponent(this._clubInfoPageUI)
	this:AddEventListener("CHANGE_SHOW_CLUB_MEMBERS", function(e) this:ChangeCloseLabShow(e) end) 
	this:AddEventListener("FRESH_CLUB_MEMBERS", function(e) this._clubInfoPageUI:OnAddFresh(e) end) 
	this:AddEventListener("FRESH_CLUB_INFO", function(e) this._clubInfoPageUI:SetInfoData(e) end) 
	this:AddEventListener("SELF_EXIT_CLUB_FRESH", function(e) this:OnSelfExit(e) end) 
	this._clubInfoPageUI:Init((function(isActive)
		this:SetSubHeaderCloseBtnActive(isActive) 
	end)) 
	this._isReady = true 
end

function _lua_ClubInfoNode:OnSelfExit( e)
	GameLog("------------------------------_lua_ClubInfoNode OnSelfExit------------------------------")
	local lobby; lobby = ( this.ViewParent.parent );
	if (lobby ~= nil) then
		CS.Eight.Framework.EIFrameWork.StartCoroutine(ClubUtility.WaitDoloading(), false) 
		local newInfo; newInfo = CS.EightGame.Logic.UIView.UIViewInfo() ;
		newInfo.viewType = CS.EightGame.Logic.MainWorldNode 
		newInfo.param = nil 
		local list; list = XLuaScriptUtils.new_List_1(typeof(CS.EightGame.Logic.UIView.UIViewInfo));
		list:Add(newInfo) 
		lobby:ForceRestStack(list) 
		lobby:Push(typeof(MainWorldNode), typeof(nil)) 
		ClubUtility.IsInClubPage = false 
	end 
end

function _lua_ClubInfoNode:ChangeCloseLabShow( e)
	GameLog("------------------------------_lua_ClubInfoNode ChangeCloseLabShow------------------------------")
	local es; es = e;
	this:SetSubHeaderCloseBtnLbl(es.stringParam) 
end

function _lua_ClubInfoNode:hotfix()
	xlua.hotfix(ClubInfoNode, {
       ['CreateView'] = function(this)
           _lua_ClubInfoNode:Ref(this)
           return util.cs_generator(function()
               _lua_ClubInfoNode:CreateView()
           end)
       end,
       ['OnSelfExit'] = function(this, e)
           _lua_ClubInfoNode:Ref(this)
           return _lua_ClubInfoNode:OnSelfExit( e)
       end,
       ['ChangeCloseLabShow'] = function(this, e)
           _lua_ClubInfoNode:Ref(this)
           return _lua_ClubInfoNode:ChangeCloseLabShow( e)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubInfoNode)