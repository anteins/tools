
local this = nil
_lua_ChatEmojiPanelControoler = BaseCom:New('_lua_ChatEmojiPanelControoler')
function _lua_ChatEmojiPanelControoler:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatEmojiPanelControoler:LoadPrefab()
	GameLog("------------------------------_lua_ChatEmojiPanelControoler LoadPrefab------------------------------")
	if isnil(this._itemLinePrefab) then
		local coroutine; coroutine = XLuaScriptUtils.GameResources():LoadAsyn(CS.System.String.Format("{0}{1}", "GameAssets/Prefabs/UI/", this._itemLinePrefabPath), "prefab", false);
		if coroutine.coroutine then
coroutine.yield(coroutine.coroutine)
end
		this._itemLinePrefab = coroutine.res 
		this:InitItemLine() 
		this:InitBtns() 
	else
		this:InitBtns() 
	end 
end

function _lua_ChatEmojiPanelControoler:InitBtns()
	GameLog("------------------------------_lua_ChatEmojiPanelControoler InitBtns------------------------------")
	local enumlist; enumlist = XLuaScriptUtils.new_List_1(typeof(ChatShowItemBtnCom.ChatShowItemEnum));
	enumlist:Add(3) 
	local index; index = 0;
	while (index < obj_len(this._btns)) do
		if (index < obj_len(enumlist)) then
			DictGetValue(this._btns, index).gameObject:SetActive(true) 
			DictGetValue(this._btns, index):SetData(DictGetValue(enumlist, index), function(com) this:CallbackSelectBtn(com) end) 
			DictGetValue(this._btns, index):SetBtnSprite(false) 
		else
			DictGetValue(this._btns, index).gameObject:SetActive(false) 
		end 
	index = index+1  
	end 
	this:CallbackSelectBtn(DictGetValue(this._btns, 0)) 
end

function _lua_ChatEmojiPanelControoler:CallbackSelectBtn( com)
	GameLog("------------------------------_lua_ChatEmojiPanelControoler CallbackSelectBtn------------------------------")
	if not isnil(ChatEmojiPanelControoler._latestShowItemBtnCom) then
		ChatEmojiPanelControoler._latestShowItemBtnCom:SetBtnSprite(false) 
	end 
	ChatEmojiPanelControoler._latestShowItemBtnCom = com 
	if not isnil(ChatEmojiPanelControoler._latestShowItemBtnCom) then
		ChatEmojiPanelControoler._latestShowItemBtnCom:SetBtnSprite(true) 
	end 
	this._curBtnEnum = com._enum 
	if (CS.System.Convert.ToInt32(this._curBtnEnum) == 3) then
	end 
	this._uiRecycledList:UpdateDataCount(CS.UnityEngine.Mathf.CeilToInt((obj_len(this.chatemojis) / ChatEmojiLineControoler._eachLineItemCount)), true) 
end

function _lua_ChatEmojiPanelControoler:InitItemLine()
	GameLog("------------------------------_lua_ChatEmojiPanelControoler InitItemLine------------------------------")
	if (isnil(this._itemLinePrefab) or (obj_len(this._applicationItemDic) > 0)) then
		return  
	end 
	local index; index = 0;
	while (index < 5) do
		local go; go = GameUtility.InstantiateGameObject(this._itemLinePrefab, this._uiRecycledList.gameObject, ("itemLine" .. index));
		local r; r = go:GetComponent("ChatEmojiLineControoler");
		this._applicationItemDic:Add(go, r) 
	index = index+1  
	end 
end

function _lua_ChatEmojiPanelControoler:OnUpdateItem( go, itemIndex, dataIndex)
	GameLog("------------------------------_lua_ChatEmojiPanelControoler OnUpdateItem------------------------------")
	local com; com = nil;
	if (function() local __compiler_invoke_114  __compiler_invoke_114, com = this._applicationItemDic:TryGetValue(go)  return __compiler_invoke_114  end)() then
		if isnil(com) then
			return  
		end 
		if ((obj_len(this.chatemojis) > 0) and (dataIndex < obj_len(this.chatemojis))) then
			com:SetData(this._curBtnEnum, this:GetItemSerDatasByDataIndex(this.chatemojis, dataIndex), function(com) this:CallbackSelectEmoji(com) end) 
		end 
	end 
end

function _lua_ChatEmojiPanelControoler:CallbackSelectEmoji( com)
	GameLog("------------------------------_lua_ChatEmojiPanelControoler CallbackSelectEmoji------------------------------")
	if this ~= "_callbackSelectEmoji" then
		this._callbackSelectEmoji(com) 
	end 
end

function _lua_ChatEmojiPanelControoler:GetItemSerDatasByDataIndex( sourcedatas, dataIndex)
	GameLog("------------------------------_lua_ChatEmojiPanelControoler GetItemSerDatasByDataIndex------------------------------")
	local resulutDatas; resulutDatas = XLuaScriptUtils.new_List_1(typeof(CS.EightGame.Data.Server.sd));
	if ((sourcedatas == nil) or (obj_len(sourcedatas) == 0)) then
		return resulutDatas 
	end 
	if (obj_len(sourcedatas) < ( ( dataIndex+1  )*ChatEmojiLineControoler._eachLineItemCount  )) then
		if (( obj_len(sourcedatas)-dataIndex*ChatEmojiLineControoler._eachLineItemCount   ) > 0) then
			resulutDatas = sourcedatas:GetRange(dataIndex*ChatEmojiLineControoler._eachLineItemCount , obj_len(sourcedatas)-dataIndex*ChatEmojiLineControoler._eachLineItemCount  ) 
		end 
	else
		resulutDatas = sourcedatas:GetRange(dataIndex*ChatEmojiLineControoler._eachLineItemCount , ChatEmojiLineControoler._eachLineItemCount) 
	end 
	return resulutDatas 
end

function _lua_ChatEmojiPanelControoler:OnClickClose()
	GameLog("------------------------------_lua_ChatEmojiPanelControoler OnClickClose------------------------------")
	if not isnil(this) then
		this.gameObject:SetActive(false) 
	end 
end

function _lua_ChatEmojiPanelControoler:hotfix()
	xlua.hotfix(ChatEmojiPanelControoler, {
       ['LoadPrefab'] = function(this)
           _lua_ChatEmojiPanelControoler:Ref(this)
           return util.cs_generator(function()
               _lua_ChatEmojiPanelControoler:LoadPrefab()
           end)
       end,
       ['InitBtns'] = function(this)
           _lua_ChatEmojiPanelControoler:Ref(this)
           return _lua_ChatEmojiPanelControoler:InitBtns()
       end,
       ['CallbackSelectBtn'] = function(this, com)
           _lua_ChatEmojiPanelControoler:Ref(this)
           return _lua_ChatEmojiPanelControoler:CallbackSelectBtn( com)
       end,
       ['InitItemLine'] = function(this)
           _lua_ChatEmojiPanelControoler:Ref(this)
           return _lua_ChatEmojiPanelControoler:InitItemLine()
       end,
       ['OnUpdateItem'] = function(this, go, itemIndex, dataIndex)
           _lua_ChatEmojiPanelControoler:Ref(this)
           return _lua_ChatEmojiPanelControoler:OnUpdateItem( go, itemIndex, dataIndex)
       end,
       ['CallbackSelectEmoji'] = function(this, com)
           _lua_ChatEmojiPanelControoler:Ref(this)
           return _lua_ChatEmojiPanelControoler:CallbackSelectEmoji( com)
       end,
       ['GetItemSerDatasByDataIndex'] = function(this, sourcedatas, dataIndex)
           _lua_ChatEmojiPanelControoler:Ref(this)
           return _lua_ChatEmojiPanelControoler:GetItemSerDatasByDataIndex( sourcedatas, dataIndex)
       end,
       ['OnClickClose'] = function(this)
           _lua_ChatEmojiPanelControoler:Ref(this)
           return _lua_ChatEmojiPanelControoler:OnClickClose()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatEmojiPanelControoler)