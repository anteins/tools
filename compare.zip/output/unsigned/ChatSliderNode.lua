
local this = nil
_lua_ChatSliderNode = BaseCom:New('_lua_ChatSliderNode')
function _lua_ChatSliderNode:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatSliderNode:ShowChatSlider()
	GameLog("------------------------------_lua_ChatSliderNode ShowChatSlider------------------------------")
	if not isnil(this._chatSliderView) then
		this:AddEventListener(ChatMsgManager.Instance.CHAT_MSG_ADD, function(e) this:ListenerMsgAdd(e) end) 
		this._chatSliderView:Register() 
		this._chatSliderView.gameObject:SetActive(true) 
	end 
end

function _lua_ChatSliderNode:DisposeChatSlider()
	GameLog("------------------------------_lua_ChatSliderNode DisposeChatSlider------------------------------")
	if not isnil(this._chatSliderView) then
		this:RemoveEventListener(ChatMsgManager.Instance.CHAT_MSG_ADD) 
		this._chatSliderView:Unregister() 
		this._chatSliderView.gameObject:SetActive(false) 
	end 
end

function _lua_ChatSliderNode:DestroyChatSlider()
	GameLog("------------------------------_lua_ChatSliderNode DestroyChatSlider------------------------------")
	if not isnil(this._chatSliderView) then
		this:RemoveEventListener(ChatMsgManager.Instance.CHAT_MSG_ADD) 
		this._chatSliderView:Unregister() 
		this._chatSliderView.gameObject:SetActive(false) 
		CS.UnityEngine.Object.Destroy(this._chatSliderView.gameObject) 
		this._chatSliderView = nil 
	end 
end

function _lua_ChatSliderNode:CreateChatSliderViewUICom( parent)
	GameLog("------------------------------_lua_ChatSliderNode CreateChatSliderViewUICom------------------------------")
	local c; c = XLuaScriptUtils.GameResources():LoadAsyn(("GameAssets/Prefabs/UI/" .. this.chatSliderViewPath), "prefab", false);
	coroutine.yield(c.coroutine) 
	local chatSliderViewPrefab; chatSliderViewPrefab = c.res;
	if isnil(chatSliderViewPrefab) then
		CS.Eight.Framework.EIDebuger.LogError("[ChatSliderViewCom] load ChatSliderView error") 
		return nil 
	end 
	local go; go = GameUtility.InstantiateGameObject(chatSliderViewPrefab, parent, "ChatSliderPanel");
	this._chatSliderView = go:GetComponent("ChatSliderViewCom") 
	this:BindComponent(this._chatSliderView)
	this:ShowChatSlider() 
end

function _lua_ChatSliderNode:ListenerMsgAdd( e)
	GameLog("------------------------------_lua_ChatSliderNode ListenerMsgAdd------------------------------")
	if not isnil(this._chatSliderView) then
		this._chatSliderView:ListenerMsgAdd(e) 
	end 
end

function _lua_ChatSliderNode:hotfix()
	xlua.hotfix(ChatSliderNode, {
       ['ShowChatSlider'] = function(this)
           _lua_ChatSliderNode:Ref(this)
           return _lua_ChatSliderNode:ShowChatSlider()
       end,
       ['DisposeChatSlider'] = function(this)
           _lua_ChatSliderNode:Ref(this)
           return _lua_ChatSliderNode:DisposeChatSlider()
       end,
       ['DestroyChatSlider'] = function(this)
           _lua_ChatSliderNode:Ref(this)
           return _lua_ChatSliderNode:DestroyChatSlider()
       end,
       ['CreateChatSliderViewUICom'] = function(this, parent)
           _lua_ChatSliderNode:Ref(this)
           return util.cs_generator(function()
               _lua_ChatSliderNode:CreateChatSliderViewUICom( parent)
           end)
       end,
       ['ListenerMsgAdd'] = function(this, e)
           _lua_ChatSliderNode:Ref(this)
           return _lua_ChatSliderNode:ListenerMsgAdd( e)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatSliderNode)