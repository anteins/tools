
local this = nil
_lua_ClubHouseController = BaseCom:New('_lua_ClubHouseController')
function _lua_ClubHouseController:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubHouseController:get_ClubCameraAni()
	GameLog("------------------------------_lua_ClubHouseController get_ClubCameraAni------------------------------")
	return this.ClubCamera:GetComponent(typeof(CS.UnityEngine.Animator)) 
end

function _lua_ClubHouseController:Init()
	GameLog("------------------------------_lua_ClubHouseController Init------------------------------")
	foreach(this.STNpcs, function(x) x = x.current   return x:SetUp()  end) 
	this.ClubHeader:SetUp() 
	this.ClubBestTeamer:SetUp() 
end

function _lua_ClubHouseController:FreshFriendMsg()
	GameLog("------------------------------_lua_ClubHouseController FreshFriendMsg------------------------------")
	local action; action = CS.EightGame.Data.Server.ServerService.MyfriendsMethod();
	CS.Eight.Framework.EIFrameWork.GetComponent(CS.EightGame.Component.NetworkClient):NetworkRequest(action, (function(returnCode, response)
	end), true, false) 
end

function _lua_ClubHouseController:ReloadHeaders()
	GameLog("------------------------------_lua_ClubHouseController ReloadHeaders------------------------------")
	this.ClubHeader:SetUp() 
	this.ClubBestTeamer:SetUp() 
end

function _lua_ClubHouseController:OnCameraLeft()
	GameLog("------------------------------_lua_ClubHouseController OnCameraLeft------------------------------")
	GameLog(((("starttime :" .. this.starttime) + " , nowtime :") + CS.UnityEngine.Time.time)) 
	local isAni; isAni = this.ClubCameraAni:GetBool("left");
	GameLog(((("Left isAni :" .. isAni) + " , CurSencePage :") + this.CurSencePage)) 
	if ((this.CurSencePage == 0) and (not isAni)) then
		GameLog("Left set") 
		this.CurSencePage = 1 
		this.ClubCameraAni:SetBool("left", true) 
	end 
end

function _lua_ClubHouseController:OnCameraRight()
	GameLog("------------------------------_lua_ClubHouseController OnCameraRight------------------------------")
	local isAni; isAni = this.ClubCameraAni:GetBool("right");
	if ((this.CurSencePage == 0) and (not isAni)) then
		GameLog("Right set") 
		this.CurSencePage = 2 
		this.ClubCameraAni:SetBool("right", true) 
	end 
end

function _lua_ClubHouseController:OnCameraBack()
	GameLog("------------------------------_lua_ClubHouseController OnCameraBack------------------------------")
	local isAni; isAni = this.ClubCameraAni:GetBool("back");
	GameLog(((("Back isAni :" .. isAni) + " , CurSencePage :") + this.CurSencePage)) 
	if ((this.CurSencePage ~= 0) and (not isAni)) then
		GameLog("Main set") 
		this.CurSencePage = 0 
		this.ClubCameraAni:SetBool("back", true) 
	end 
end

function _lua_ClubHouseController:TouchFunction()
	GameLog("------------------------------_lua_ClubHouseController TouchFunction------------------------------")
	if (isnil(this.ClubCamera) and (not this:IsCameraStay())) then
		return  
	end 
	if (CS.UnityEngine.Input.GetMouseButtonDown(0) and this.TstartPos == CS.UnityEngine.Vector2.zero) then
		this.TstartPos = not isnil(CS.UnityEngine.Input.mousePosition) 
	elseif (not isnil(this.TstartPos) and CS.UnityEngine.Input.GetMouseButtonUp(0)) then
		local movepos; movepos = not isnil(CS.UnityEngine.Input.mousePosition);
		this:TouchTurnFunction(movepos) 
	end 
end

function _lua_ClubHouseController:TouchTurnFunction( endPos)
	GameLog("------------------------------_lua_ClubHouseController TouchTurnFunction------------------------------")
	if (not this:IsCameraStay()) then
		this.TstartPos = CS.UnityEngine.Vector2.zero 
		return  
	end 
	if ((endPos.x >= (this.TstartPos.x + this.distance)) and this:IsCameraStay()) then
		if ((this.CurSencePage == 0) and (not this.ClubCameraAni:GetBool("left"))) then
			this.CurSencePage = 1 
			this.ClubCameraAni:SetBool("left", true) 
		elseif ((this.CurSencePage == 2) and (not this.ClubCameraAni:GetBool("back"))) then
			this.CurSencePage = 0 
			this.ClubCameraAni:SetBool("back", true) 
		end 
	elseif ((endPos.x <= (this.TstartPos.x - this.distance)) and this:IsCameraStay()) then
		if (((this.CurSencePage == 0) and (this.CurSencePage ~= 2)) and (not this.ClubCameraAni:GetBool("right"))) then
			this.CurSencePage = 2 
			this.ClubCameraAni:SetBool("right", true) 
		elseif ((this.CurSencePage == 1) and (not this.ClubCameraAni:GetBool("back"))) then
			this.CurSencePage = 0 
			this.ClubCameraAni:SetBool("back", true) 
		end 
	end 
	this.TstartPos = CS.UnityEngine.Vector2.zero 
	if (this.isFirst and (PlayerPrefs_Ex.GetInt__System_String__System_Int32__System_Boolean("ClubFirstTip", 0, false) == 0)) then
		this.isFirst = false 
		CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("SET_CLUB_FIRST_TIP_OVER",nil,nil,0.00) ) 
	end 
end

function _lua_ClubHouseController:IsCameraStay()
	GameLog("------------------------------_lua_ClubHouseController IsCameraStay------------------------------")
	return (((not this.ClubCameraAni:GetBool("left")) and (not this.ClubCameraAni:GetBool("right"))) and (not this.ClubCameraAni:GetBool("back"))) 
end

function _lua_ClubHouseController:ResetCameraStay()
	GameLog("------------------------------_lua_ClubHouseController ResetCameraStay------------------------------")
	this.ClubCameraAni:SetBool("left", false) 
	this.ClubCameraAni:SetBool("right", false) 
	this.ClubCameraAni:SetBool("back", false) 
end

function _lua_ClubHouseController:FixedUpdate()
	GameLog("------------------------------_lua_ClubHouseController FixedUpdate------------------------------")
	if (not ClubUtility.HaveMask) then
		if this:IsCameraStay() then
			if CS.UnityEngine.Input.GetKey(276) then
				this.starttime = CS.UnityEngine.Time.time 
				this:OnCameraLeft() 
				if (this.isFirst and (PlayerPrefs_Ex.GetInt__System_String__System_Int32__System_Boolean("ClubFirstTip", 0, false) == 0)) then
					this.isFirst = false 
					CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("SET_CLUB_FIRST_TIP_OVER",nil,nil,0.00) ) 
				end 
			elseif CS.UnityEngine.Input.GetKey(275) then
				this.starttime = CS.UnityEngine.Time.time 
				this:OnCameraRight() 
				if (this.isFirst and (PlayerPrefs_Ex.GetInt__System_String__System_Int32__System_Boolean("ClubFirstTip", 0, false) == 0)) then
					this.isFirst = false 
					CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("SET_CLUB_FIRST_TIP_OVER",nil,nil,0.00) ) 
				end 
			elseif CS.UnityEngine.Input.GetKey(274) then
				this.starttime = CS.UnityEngine.Time.time 
				this:OnCameraBack() 
				if (this.isFirst and (PlayerPrefs_Ex.GetInt__System_String__System_Int32__System_Boolean("ClubFirstTip", 0, false) == 0)) then
					this.isFirst = false 
					CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("SET_CLUB_FIRST_TIP_OVER",nil,nil,0.00) ) 
				end 
			end 
			this:TouchFunction() 
		end 
		if CS.UnityEngine.Input.GetMouseButtonDown(0) then
			local ray; ray = this.ClubCamera:ScreenPointToRay(CS.UnityEngine.Input.mousePosition);
			local hitInfo;
			if (function() local __compiler_invoke_279  __compiler_invoke_279, hitInfo = CS.UnityEngine.Physics.Raycast(ray, 1000000.00)  return __compiler_invoke_279  end)() then
				GameLog(("hitInfo : " .. hitInfo.collider.transform:tostring())) 
				local objname; objname = hitInfo.collider.gameObject.name;
				if (((Contains(objname, "mount_npc00") or Contains(objname, "_quest")) or Contains(objname, "_door")) or Contains(objname, "mount_player00")) then
					local typeid; typeid = hitInfo.collider.gameObject:GetComponent("SingleNpc").Data.PageType;
					CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("GO_NPC_PAGE",nil,typeid,0.00) ) 
				end 
			end 
		end 
	end 
end

function _lua_ClubHouseController:hotfix()
	xlua.hotfix(ClubHouseController, {
       ['Init'] = function(this)
           _lua_ClubHouseController:Ref(this)
           return _lua_ClubHouseController:Init()
       end,
       ['FreshFriendMsg'] = function(this)
           _lua_ClubHouseController:Ref(this)
           return _lua_ClubHouseController:FreshFriendMsg()
       end,
       ['ReloadHeaders'] = function(this)
           _lua_ClubHouseController:Ref(this)
           return _lua_ClubHouseController:ReloadHeaders()
       end,
       ['OnCameraLeft'] = function(this)
           _lua_ClubHouseController:Ref(this)
           return _lua_ClubHouseController:OnCameraLeft()
       end,
       ['OnCameraRight'] = function(this)
           _lua_ClubHouseController:Ref(this)
           return _lua_ClubHouseController:OnCameraRight()
       end,
       ['OnCameraBack'] = function(this)
           _lua_ClubHouseController:Ref(this)
           return _lua_ClubHouseController:OnCameraBack()
       end,
       ['TouchFunction'] = function(this)
           _lua_ClubHouseController:Ref(this)
           return _lua_ClubHouseController:TouchFunction()
       end,
       ['TouchTurnFunction'] = function(this, endPos)
           _lua_ClubHouseController:Ref(this)
           return _lua_ClubHouseController:TouchTurnFunction( endPos)
       end,
       ['IsCameraStay'] = function(this)
           _lua_ClubHouseController:Ref(this)
           return _lua_ClubHouseController:IsCameraStay()
       end,
       ['ResetCameraStay'] = function(this)
           _lua_ClubHouseController:Ref(this)
           return _lua_ClubHouseController:ResetCameraStay()
       end,
       ['FixedUpdate'] = function(this)
           _lua_ClubHouseController:Ref(this)
           return _lua_ClubHouseController:FixedUpdate()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubHouseController)