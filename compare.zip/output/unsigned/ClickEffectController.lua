
local this = nil
_lua_ClickEffectController = BaseCom:New('_lua_ClickEffectController')
function _lua_ClickEffectController:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClickEffectController:GetLayerFromMask( mask)
	GameLog("------------------------------_lua_ClickEffectController GetLayerFromMask------------------------------")
	if (CS.System.Convert.ToInt32(mask) == 0) then
		return 0 
	end 
	local times; times = 0;
	repeat
		mask = mask>>1  
	until not (((mask ~= 0) and (( (function() times = times+1   return times  end)() ) > 0))) 
	return times 
end

function _lua_ClickEffectController:OnEnable()
	GameLog("------------------------------_lua_ClickEffectController OnEnable------------------------------")
end

function _lua_ClickEffectController:OnDisable()
	GameLog("------------------------------_lua_ClickEffectController OnDisable------------------------------")
	this:CancelHideTimer() 
	this:StopParticleSystem() 
end

function _lua_ClickEffectController:UpdateTouch()
	GameLog("------------------------------_lua_ClickEffectController UpdateTouch------------------------------")
	this._touch.touchValid = CS.UnityEngine.Input.GetMouseButton(0) 
	if this._touch.touchValid then
		this._touch.pos = not isnil(CS.UnityEngine.Input.mousePosition) 
	end 
end

function _lua_ClickEffectController:WaitingForHideWhenTouchUp()
	GameLog("------------------------------_lua_ClickEffectController WaitingForHideWhenTouchUp------------------------------")
	coroutine.yield(CS.UnityEngine.WaitForSeconds(1.00)) 
	this.effect:SetActive(false) 
	this:StopParticleSystem() 
	this._hideTimer = nil 
end

function _lua_ClickEffectController:CancelHideTimer()
	GameLog("------------------------------_lua_ClickEffectController CancelHideTimer------------------------------")
	if (this._hideTimer ~= nil) then
		this:StopCoroutine(this._hideTimer) 
		this._hideTimer = nil 
	end 
end

function _lua_ClickEffectController:StartHideTimer()
	GameLog("------------------------------_lua_ClickEffectController StartHideTimer------------------------------")
	if (this._hideTimer == nil) then
		this._hideTimer = this:WaitingForHideWhenTouchUp() 
		this:StartCoroutine(this._hideTimer) 
	end 
end

function _lua_ClickEffectController:PlayerParticleSystem()
	GameLog("------------------------------_lua_ClickEffectController PlayerParticleSystem------------------------------")
	if (not this.effect.activeSelf) then
		this.effect:SetActive(true) 
	end 
	local ps; ps = nil;
	local i; i = 0;
	local imax; imax = obj_len(this.particleSystems);
	while (i < imax) do
		ps = DictGetValue(this.particleSystems, i + 1) 
		ps:Clear(true) 
		ps:Play(true) 
	i = i+1  
	end 
end

function _lua_ClickEffectController:StopParticleSystem()
	GameLog("------------------------------_lua_ClickEffectController StopParticleSystem------------------------------")
	local ps; ps = nil;
	local i; i = 0;
	local imax; imax = obj_len(this.particleSystems);
	while (i < imax) do
		ps = DictGetValue(this.particleSystems, i + 1) 
		ps:Clear(true) 
		ps:Stop(true) 
	i = i+1  
	end 
	if this.effect.activeSelf then
		this.effect:SetActive(false) 
	end 
end

function _lua_ClickEffectController:hotfix()
	xlua.hotfix(ClickEffectController, {
       ['GetLayerFromMask'] = function(this, mask)
           _lua_ClickEffectController:Ref(this)
           return _lua_ClickEffectController:GetLayerFromMask( mask)
       end,
       ['OnEnable'] = function(this)
           _lua_ClickEffectController:Ref(this)
           return _lua_ClickEffectController:OnEnable()
       end,
       ['OnDisable'] = function(this)
           _lua_ClickEffectController:Ref(this)
           return _lua_ClickEffectController:OnDisable()
       end,
       ['UpdateTouch'] = function(this)
           _lua_ClickEffectController:Ref(this)
           return _lua_ClickEffectController:UpdateTouch()
       end,
       ['WaitingForHideWhenTouchUp'] = function(this)
           _lua_ClickEffectController:Ref(this)
           return util.cs_generator(function()
               _lua_ClickEffectController:WaitingForHideWhenTouchUp()
           end)
       end,
       ['CancelHideTimer'] = function(this)
           _lua_ClickEffectController:Ref(this)
           return _lua_ClickEffectController:CancelHideTimer()
       end,
       ['StartHideTimer'] = function(this)
           _lua_ClickEffectController:Ref(this)
           return _lua_ClickEffectController:StartHideTimer()
       end,
       ['PlayerParticleSystem'] = function(this)
           _lua_ClickEffectController:Ref(this)
           return _lua_ClickEffectController:PlayerParticleSystem()
       end,
       ['StopParticleSystem'] = function(this)
           _lua_ClickEffectController:Ref(this)
           return _lua_ClickEffectController:StopParticleSystem()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClickEffectController)