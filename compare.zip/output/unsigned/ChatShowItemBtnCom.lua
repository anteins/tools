
local this = nil
_lua_ChatShowItemBtnCom = BaseCom:New('_lua_ChatShowItemBtnCom')
function _lua_ChatShowItemBtnCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatShowItemBtnCom:SetData( cEnum, callbackClick)
	GameLog("------------------------------_lua_ChatShowItemBtnCom SetData------------------------------")
	this._enum = cEnum 
	this._callbackClick = callbackClick 
	this:SetLbl() 
end

function _lua_ChatShowItemBtnCom:OnClick()
	GameLog("------------------------------_lua_ChatShowItemBtnCom OnClick------------------------------")
	if this ~= "_callbackClick" then
		this._callbackClick(this) 
	end 
end

function _lua_ChatShowItemBtnCom:SetLbl()
	GameLog("------------------------------_lua_ChatShowItemBtnCom SetLbl------------------------------")
	local str; str = "";
	local __compiler_switch_38 = this._enum;
	if __compiler_switch_38 == 0 then
		str = "物品" 
	elseif __compiler_switch_38 == 1 then
		str = "装备" 
	elseif __compiler_switch_38 == 2 then
		str = "伙伴" 
	elseif __compiler_switch_38 == 3 then
		str = "表情" 
	end 
	if isnil(this._btnLbl) then
		return  
	end 
	this._btnLbl.text = str 
end

function _lua_ChatShowItemBtnCom:SetBtnSprite( b)
	GameLog("------------------------------_lua_ChatShowItemBtnCom SetBtnSprite------------------------------")
	if (isnil(this._btn) or isnil(this._btnLbl)) then
		return  
	end 
	this._btnLbl.color = b and (function() return CS.UnityEngine.Color(0.37,0.26,0.12)  end) or CS.UnityEngine.Color.white  
	this._btnLbl.effectStyle = b and 0 or 2 
	local _bgsprite; _bgsprite = this._btn:GetComponentInChildren(UISprite);
	if isnil(_bgsprite) then
		return  
	end 
	_bgsprite:SetDimensions(b and 46 or 42, _bgsprite.height) 
	_bgsprite.spriteName = b and "1234" or "124" 
end

function _lua_ChatShowItemBtnCom:hotfix()
	xlua.hotfix(ChatShowItemBtnCom, {
       ['SetData'] = function(this, cEnum, callbackClick)
           _lua_ChatShowItemBtnCom:Ref(this)
           return _lua_ChatShowItemBtnCom:SetData( cEnum, callbackClick)
       end,
       ['OnClick'] = function(this)
           _lua_ChatShowItemBtnCom:Ref(this)
           return _lua_ChatShowItemBtnCom:OnClick()
       end,
       ['SetLbl'] = function(this)
           _lua_ChatShowItemBtnCom:Ref(this)
           return _lua_ChatShowItemBtnCom:SetLbl()
       end,
       ['SetBtnSprite'] = function(this, b)
           _lua_ChatShowItemBtnCom:Ref(this)
           return _lua_ChatShowItemBtnCom:SetBtnSprite( b)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatShowItemBtnCom)