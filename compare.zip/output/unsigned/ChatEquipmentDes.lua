
local this = nil
_lua_ChatEquipmentDes = BaseCom:New('_lua_ChatEquipmentDes')
function _lua_ChatEquipmentDes:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatEquipmentDes:AnalysSendStr( obj)
	GameLog("------------------------------_lua_ChatEquipmentDes AnalysSendStr------------------------------")
	local itemContent; itemContent = obj;
	local contentArray; contentArray = Split(itemContent, wraparray{"itemtype=",",itemstaticid=",",itemgid=",},1);
	local itemtype; itemtype = "";
	local itemstiticid; itemstiticid = 0;
	local itemGid; itemGid = 0;
	local extraObj; extraObj = "";
	if (obj_len(contentArray) > 2) then
		itemtype = DictGetValue(contentArray, 1) 
		itemstiticid = tonumber(DictGetValue(contentArray, 2)) 
		itemGid = CS.System.Int64.Parse(DictGetValue(contentArray, 3)) 
	end 
	local t; t = ChatMsgURLContent(itemtype,itemstiticid,itemGid,"",itemContent,"") ;
	return t 
end

function _lua_ChatEquipmentDes:AnalysisExtraStr( str)
	GameLog("------------------------------_lua_ChatEquipmentDes AnalysisExtraStr------------------------------")
	if CS.System.String.IsNullOrEmpty(str) then
		return nil 
	end 
	local id; id = 0;
	local breakskill; breakskill = "";
	local randattr; randattr = "";
	local rankuplv; rankuplv = 0;
	local wearfighter; wearfighter = 0;
	local staticId; staticId = 0;
	local contentArray; contentArray = Split(str, wraparray{"id=",",breakskill=",",randattr=",",rankuplv=",",wearfighter=",",staticid=",},1);
	if (obj_len(contentArray) > 5) then
		id = CS.System.Int64.Parse(DictGetValue(contentArray, 1)) 
		breakskill = DictGetValue(contentArray, 2) 
		randattr = DictGetValue(contentArray, 3) 
		rankuplv = tonumber(DictGetValue(contentArray, 4)) 
		wearfighter = CS.System.Int64.Parse(DictGetValue(contentArray, 5)) 
		staticId = tonumber(DictGetValue(contentArray, 6)) 
	end 
	local serdata; serdata = CS.EightGame.Data.Server.EquipmentSerData();
	serdata.id = id 
	serdata.breakskill = breakskill 
	serdata.randattr = randattr 
	serdata.rankuplv = rankuplv 
	serdata.wearfighter = wearfighter 
	serdata.staticid = staticId 
	return serdata 
end

function _lua_ChatEquipmentDes:hotfix()
	xlua.hotfix(ChatEquipmentDes, {
       ['AnalysSendStr'] = function(this, obj)
           _lua_ChatEquipmentDes:Ref(this)
           return _lua_ChatEquipmentDes:AnalysSendStr( obj)
       end,
       ['AnalysisExtraStr'] = function(this, str)
           _lua_ChatEquipmentDes:Ref(this)
           return _lua_ChatEquipmentDes:AnalysisExtraStr( str)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatEquipmentDes)