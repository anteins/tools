
local this = nil
_lua_ChatManager = BaseCom:New('_lua_ChatManager')
function _lua_ChatManager:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatManager:Awake()
	GameLog("------------------------------_lua_ChatManager Awake------------------------------")
	ChatManager.instance = this 
end

function _lua_ChatManager:OnDestroy()
	GameLog("------------------------------_lua_ChatManager OnDestroy------------------------------")
	ChatManager.instance = nil 
end

function _lua_ChatManager:AddParticipant( participant)
	GameLog("------------------------------_lua_ChatManager AddParticipant------------------------------")
	this.mParticipants:Add(participant) 
end

function _lua_ChatManager:ProgressChat()
	GameLog("------------------------------_lua_ChatManager ProgressChat------------------------------")
	this.mDisplay = true 
	local ct; ct = DictGetValue(this.mParticipants, this.mCurrentChatter).hudText;
	if not isnil(ct) then
		ct:Add(Replace(DictGetValue(this.chatMessages, this.mCurrentMessage + 1), "\\n","\n"), CS.UnityEngine.Color.white, 2.00, "") 
		this.cameraLookAt.target = DictGetValue(this.mParticipants, this.mCurrentChatter).lookAt 
	end 
	coroutine.yield(CS.UnityEngine.WaitForSeconds(4.00)) 
	this.mCurrentChatter = this.mCurrentChatter+1  
	this.mCurrentMessage = this.mCurrentMessage+1  
	if (this.mCurrentChatter >= obj_len(this.mParticipants)) then
		this.mCurrentChatter = 0 
	end 
	if (this.mCurrentMessage >= obj_len(this.chatMessages)) then
		this.mCurrentMessage = 0 
		coroutine.yield(CS.UnityEngine.WaitForSeconds(5.00)) 
	end 
	this.mDisplay = false 
end

function _lua_ChatManager:hotfix()
	xlua.hotfix(ChatManager, {
       ['Awake'] = function(this)
           _lua_ChatManager:Ref(this)
           return _lua_ChatManager:Awake()
       end,
       ['OnDestroy'] = function(this)
           _lua_ChatManager:Ref(this)
           return _lua_ChatManager:OnDestroy()
       end,
       ['AddParticipant'] = function(this, participant)
           _lua_ChatManager:Ref(this)
           return _lua_ChatManager:AddParticipant( participant)
       end,
       ['ProgressChat'] = function(this)
           _lua_ChatManager:Ref(this)
           return util.cs_generator(function()
               _lua_ChatManager:ProgressChat()
           end)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatManager)