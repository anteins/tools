
local this = nil
_lua_ClubDonataPartyUI = BaseCom:New('_lua_ClubDonataPartyUI')
function _lua_ClubDonataPartyUI:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ClubDonataPartyUI:Init()
	GameLog("------------------------------_lua_ClubDonataPartyUI Init------------------------------")
	EventDelegate.Add(this.DonataBt.onClick, function() this:OnDonata() end) 
end

function _lua_ClubDonataPartyUI:SetReward( guilddonation)
	GameLog("------------------------------_lua_ClubDonataPartyUI SetReward------------------------------")
	local rewardstr; rewardstr = "";
	if (guilddonation.getmoney ~= 0) then
		local rstr; rstr = ShowRewardUtil.GetTypeWords(10, 1);
		rewardstr = rewardstr + CS.System.String.Format("{0} {1}    ", rstr, guilddonation.getmoney) 
	end 
	if (guilddonation.getstone ~= 0) then
		local rstr; rstr = ShowRewardUtil.GetTypeWords(10, 2);
		rewardstr = rewardstr + CS.System.String.Format("{0} {1}    ", rstr, guilddonation.getstone) 
	end 
	if (guilddonation.getwood ~= 0) then
		local rstr; rstr = ShowRewardUtil.GetTypeWords(10, 3);
		rewardstr = rewardstr + CS.System.String.Format("{0} {1}    ", rstr, guilddonation.getwood) 
	end 
	if (guilddonation.getmana ~= 0) then
		local rstr; rstr = ShowRewardUtil.GetTypeWords(10, 4);
		rewardstr = rewardstr + CS.System.String.Format("{0} {1}    ", rstr, guilddonation.getmana) 
	end 
	if (guilddonation.getprestige ~= 0) then
		local rstr; rstr = ShowRewardUtil.GetTypeWords(10, 5);
		rewardstr = rewardstr + CS.System.String.Format("{0} {1}    ", rstr, guilddonation.getprestige) 
	end 
	if (guilddonation.getprosperity ~= 0) then
		local rstr; rstr = ShowRewardUtil.GetTypeWords(10, 6);
		rewardstr = rewardstr + CS.System.String.Format("{0} {1}    ", rstr, guilddonation.getprosperity) 
	end 
	this.AllRewardValLab.text = rewardstr 
	if (guilddonation.getcontribution ~= 0) then
		this.MyRewardValLab.gameObject:SetActive(true) 
		local rstr; rstr = ShowRewardUtil.GetTypeWords(11, 0);
		this.MyRewardValLab.text = CS.System.String.Format("{0} {1}", rstr, guilddonation.getcontribution) 
	else
		this.MyRewardValLab.gameObject:SetActive(false) 
	end 
end

function _lua_ClubDonataPartyUI:OnDonata()
	GameLog("------------------------------_lua_ClubDonataPartyUI OnDonata------------------------------")
	if (this.curcount >= this.daymax) then
		local _tipstr; _tipstr = "已到达今日捐献上限";
		local param; param = CS.EightGame.Logic.TipStruct(_tipstr,0.20) ;
		CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_FLOATING_TIPS",nil,param,0.00) ) 
	else
		local _tippath; _tippath = "ClubUI/ClubTipsUI/DonataTips";
		CS.Eight.Framework.EIFrameWork.StartCoroutine(RoleInfoUtil.LoadAsynUIPrefab(nil, _tippath, (function(obj)
			local _tipui; _tipui = obj:GetComponent("ClubDonataTipsUI");
			_tipui:SetUp(this.AllRewardValLab.text, this.MyRewardValLab.text, this.DiamonCost) 
			local tipsDialogParam; tipsDialogParam = CS.EightGame.Logic.TipsDialogParam("DoDonataTips","捐献",obj,"确定",(function() 
				this:OnDonataMsg() 
				return true 
			end), "返回", function() return this:OnCancel() end, 5, 0) 
			delegationset(false, false, "CS.EightGame.Logic.TipsDialogParam:ondismiss", tipsDialogParam, nil, "ondismiss", (function()
				if not isnil(obj) then
					CS.UnityEngine.Object.Destroy(obj) 
				end 
			end)) 
			CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_COMMONT_TIPS_DIALOG",nil,tipsDialogParam,0.00) ) 
		end)), false) 
	end 
end

function _lua_ClubDonataPartyUI:OnCancel()
	GameLog("------------------------------_lua_ClubDonataPartyUI OnCancel------------------------------")
	return true 
end

function _lua_ClubDonataPartyUI:OnDonataMsg()
	GameLog("------------------------------_lua_ClubDonataPartyUI OnDonataMsg------------------------------")
	if this.IsRequst then
		return  
	end 
	this.IsRequst = true 
	local srv; srv = XLuaScriptUtils.ServiceCenter():GetService(typeof(CS.EightGame.Component.ClubService));
	local request; request = CS.EightGame.Data.Server.SendDonation();
	srv:SendDonation(request, (function(arg1)
		local errorc; errorc = arg1;
		if (errorc ~= 200) then
			local _tipstr; _tipstr = CS.EightGame.Component.NetCode.GetDesc(errorc);
			local param; param = CS.EightGame.Logic.TipStruct(_tipstr,0.20) ;
			CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("UI_FLOATING_TIPS",nil,param,0.00) ) 
		else
			CS.EightGame.Logic.FloatingTextTipUIRoot.SetFloattingTip("捐献成功", 0.00) 
			this:SetUp() 
			CS.Eight.Framework.EIFrameWork.Instance:DispatchEvent(CS.Eight.Framework.EIEvent("FRESH_CLUB_PARTYINFO",nil,nil,0.00) ) 
		end 
		this.IsRequst = false 
	end), nil) 
end

function _lua_ClubDonataPartyUI:hotfix()
	xlua.hotfix(ClubDonataPartyUI, {
       ['Init'] = function(this)
           _lua_ClubDonataPartyUI:Ref(this)
           return _lua_ClubDonataPartyUI:Init()
       end,
       ['SetReward'] = function(this, guilddonation)
           _lua_ClubDonataPartyUI:Ref(this)
           return _lua_ClubDonataPartyUI:SetReward( guilddonation)
       end,
       ['OnDonata'] = function(this)
           _lua_ClubDonataPartyUI:Ref(this)
           return _lua_ClubDonataPartyUI:OnDonata()
       end,
       ['OnCancel'] = function(this)
           _lua_ClubDonataPartyUI:Ref(this)
           return _lua_ClubDonataPartyUI:OnCancel()
       end,
       ['OnDonataMsg'] = function(this)
           _lua_ClubDonataPartyUI:Ref(this)
           return _lua_ClubDonataPartyUI:OnDonataMsg()
       end,
   })
end

table.insert(g_tbHotfix, _lua_ClubDonataPartyUI)