
local this = nil
_lua_ChatEmojiDes = BaseCom:New('_lua_ChatEmojiDes')
function _lua_ChatEmojiDes:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatEmojiDes:JoinSendStr( obj)
	GameLog("------------------------------_lua_ChatEmojiDes JoinSendStr------------------------------")
	local str; str = "";
	local chatemoji; chatemoji = obj;
	if (chatemoji == nil) then
		return str 
	end 
	str = CS.System.String.Format("itemtype=emoji,itemstaticid={0},itemgid={1}", chatemoji.id, 0) 
	return str 
end

function _lua_ChatEmojiDes:AnalysSendStr( obj)
	GameLog("------------------------------_lua_ChatEmojiDes AnalysSendStr------------------------------")
	local itemContent; itemContent = obj;
	local contentArray; contentArray = Split(itemContent, wraparray{"itemtype=",",itemstaticid=",",itemgid=",},1);
	local itemtype; itemtype = "";
	local itemstiticid; itemstiticid = 0;
	local itemGid; itemGid = 0;
	local extraObj; extraObj = "";
	if (obj_len(contentArray) > 2) then
		itemtype = DictGetValue(contentArray, 1) 
		itemstiticid = tonumber(DictGetValue(contentArray, 2)) 
		itemGid = CS.System.Int64.Parse(DictGetValue(contentArray, 3)) 
	end 
	local t; t = ChatMsgURLContent(itemtype,itemstiticid,itemGid,"",itemContent,"") ;
	return t 
end

function _lua_ChatEmojiDes:hotfix()
	xlua.hotfix(ChatEmojiDes, {
       ['JoinSendStr'] = function(this, obj)
           _lua_ChatEmojiDes:Ref(this)
           return _lua_ChatEmojiDes:JoinSendStr( obj)
       end,
       ['AnalysSendStr'] = function(this, obj)
           _lua_ChatEmojiDes:Ref(this)
           return _lua_ChatEmojiDes:AnalysSendStr( obj)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatEmojiDes)