
local this = nil
_lua_LotteryController = BaseCom:New('_lua_LotteryController')
function _lua_LotteryController:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LotteryController:Init( pageCount)
	GameLog("------------------------------_lua_LotteryController Init------------------------------")
	local isShow; isShow = (pageCount > 1);
	this.LeftBtn.gameObject:SetActive(isShow) 
	this.RightBtn.gameObject:SetActive(isShow) 
end

function _lua_LotteryController:hotfix()
	xlua.hotfix(LotteryController, {
       ['Init'] = function(this, pageCount)
           _lua_LotteryController:Ref(this)
           return _lua_LotteryController:Init( pageCount)
       end,
   })
end

table.insert(g_tbHotfix, _lua_LotteryController)