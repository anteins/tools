
local this = nil
_lua_LoginDoorCom = BaseCom:New('_lua_LoginDoorCom')
function _lua_LoginDoorCom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LoginDoorCom:OnAnimHandler()
	GameLog("------------------------------_lua_LoginDoorCom OnAnimHandler------------------------------")
end

function _lua_LoginDoorCom:OnAnimHandleString( str)
	GameLog("------------------------------_lua_LoginDoorCom OnAnimHandleString------------------------------")
end

function _lua_LoginDoorCom:OnAnimHandleInt( i)
	GameLog("------------------------------_lua_LoginDoorCom OnAnimHandleInt------------------------------")
end

function _lua_LoginDoorCom:OnAnimName( animName)
	GameLog("------------------------------_lua_LoginDoorCom OnAnimName------------------------------")
	if not isnil(this.AnimControl) then
		this.AnimControl:Play(animName) 
	end 
	if (animName == "opendoor") then
		this.entity:DispatchEvent(CS.Eight.Framework.EIEvent("AUDIO_PLAY_SOUND",nil,GameAudioSoundParam(GameAudioName.SoundOpenDoor) ,0.00) ) 
	end 
end

function _lua_LoginDoorCom:Awake()
	GameLog("------------------------------_lua_LoginDoorCom Awake------------------------------")
	if isnil(this.AnimControl) then
		this.AnimControl = this.gameObject:GetComponent(typeof(CS.UnityEngine.Animator)) 
	end 
end

function _lua_LoginDoorCom:Reset()
	GameLog("------------------------------_lua_LoginDoorCom Reset------------------------------")
	if not isnil(this.AnimControl) then
		this.AnimControl:Play("none") 
	end 
end

function _lua_LoginDoorCom:hotfix()
	xlua.hotfix(LoginDoorCom, {
       ['OnAnimHandler'] = function(this)
           _lua_LoginDoorCom:Ref(this)
           return _lua_LoginDoorCom:OnAnimHandler()
       end,
       ['OnAnimHandleString'] = function(this, str)
           _lua_LoginDoorCom:Ref(this)
           return _lua_LoginDoorCom:OnAnimHandleString( str)
       end,
       ['OnAnimHandleInt'] = function(this, i)
           _lua_LoginDoorCom:Ref(this)
           return _lua_LoginDoorCom:OnAnimHandleInt( i)
       end,
       ['OnAnimName'] = function(this, animName)
           _lua_LoginDoorCom:Ref(this)
           return _lua_LoginDoorCom:OnAnimName( animName)
       end,
       ['Awake'] = function(this)
           _lua_LoginDoorCom:Ref(this)
           return _lua_LoginDoorCom:Awake()
       end,
       ['Reset'] = function(this)
           _lua_LoginDoorCom:Ref(this)
           return _lua_LoginDoorCom:Reset()
       end,
   })
end

table.insert(g_tbHotfix, _lua_LoginDoorCom)