
local this = nil
_lua_LoginCloseTipsUICom = BaseCom:New('_lua_LoginCloseTipsUICom')
function _lua_LoginCloseTipsUICom:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_LoginCloseTipsUICom:SetUpData( _msg)
	GameLog("------------------------------_lua_LoginCloseTipsUICom SetUpData------------------------------")
	this.MsgLab.text = _msg 
end

function _lua_LoginCloseTipsUICom:hotfix()
	xlua.hotfix(LoginCloseTipsUICom, {
       ['SetUpData'] = function(this, _msg)
           _lua_LoginCloseTipsUICom:Ref(this)
           return _lua_LoginCloseTipsUICom:SetUpData( _msg)
       end,
   })
end

table.insert(g_tbHotfix, _lua_LoginCloseTipsUICom)