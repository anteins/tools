
local this = nil
_lua_ChatBaseDes = BaseCom:New('_lua_ChatBaseDes')
function _lua_ChatBaseDes:Ref(ref)
   if ref then
       this = ref
   end
   return this
end

function _lua_ChatBaseDes:JoinSendStr( obj)
	GameLog("------------------------------_lua_ChatBaseDes JoinSendStr------------------------------")
	return "" 
end

function _lua_ChatBaseDes:AnalysSendStr( obj)
	GameLog("------------------------------_lua_ChatBaseDes AnalysSendStr------------------------------")
	return nil 
end

function _lua_ChatBaseDes:JoinURLStr( obj)
	GameLog("------------------------------_lua_ChatBaseDes JoinURLStr------------------------------")
	return "" 
end

function _lua_ChatBaseDes:AnalysisExtraStr( str)
	GameLog("------------------------------_lua_ChatBaseDes AnalysisExtraStr------------------------------")
	if CS.System.String.IsNullOrEmpty(str) then
		return nil 
	end 
	return nil 
end

function _lua_ChatBaseDes:hotfix()
	xlua.hotfix(ChatBaseDes, {
       ['JoinSendStr'] = function(this, obj)
           _lua_ChatBaseDes:Ref(this)
           return _lua_ChatBaseDes:JoinSendStr( obj)
       end,
       ['AnalysSendStr'] = function(this, obj)
           _lua_ChatBaseDes:Ref(this)
           return _lua_ChatBaseDes:AnalysSendStr( obj)
       end,
       ['JoinURLStr'] = function(this, obj)
           _lua_ChatBaseDes:Ref(this)
           return _lua_ChatBaseDes:JoinURLStr( obj)
       end,
       ['AnalysisExtraStr'] = function(this, str)
           _lua_ChatBaseDes:Ref(this)
           return _lua_ChatBaseDes:AnalysisExtraStr( str)
       end,
   })
end

table.insert(g_tbHotfix, _lua_ChatBaseDes)